'use strict';
const { app, BrowserWindow, ipcMain, screen, dialog, shell, powerSaveBlocker, Menu, clipboard, ClipboardItem, net } = require('electron');
const fs = require('fs');
const path = require('path');
const E = require('./src/engine.js');
const { chooseTvDisplay } = require('./src/displays.js');
const { createRemote } = require('./src/remote.js');
const Report = require('./src/report.js');
const Xlsx = require('./src/xlsx.js');
const { createUpdater } = require('./src/updater.js');
const PKG = require('./package.json');
const VERSION = PKG.version;
let updater = null;

const IS_TEST = !!process.env.POKER_TEST;
const IS_MAC = process.platform === 'darwin';
// Tests and screenshots can load sample players and results.
if (IS_TEST && process.env.POKER_SEED) E.useSeed(require(process.env.POKER_SEED));
const BACKUPS_TO_KEEP = 30;

let db;
let controlWin = null;
let tvWin = null;
let tvMode = 'closed'; // 'closed' | 'screen' | 'window'
let tvDisplayId = null;
let dataDir;
let dataFile;
let backupDir;
let startupNotice = null;
let saveTimer = null;
let lastPeriodicSave = 0;
let blockerId = null;
let awakeId = null;
let remote = null;
let quitting = false;

/* ---------- Saving ---------- */

function setupPaths() {
  // On a Mac, Documents needs a permission prompt, so the data stays in the app's own support folder.
  const home = IS_MAC ? app.getPath('userData') : app.getPath('documents');
  dataDir = process.env.POKER_DATA_DIR || path.join(home, 'Poker Night Data');
  dataFile = path.join(dataDir, 'poker-night.json');
  backupDir = path.join(dataDir, 'Backups');
  fs.mkdirSync(backupDir, { recursive: true });
}

function writeAtomic(file, text) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, text);
  try {
    fs.renameSync(tmp, file);
  } catch (_) {
    // Windows can briefly lock a file (antivirus, OneDrive). Fall back to a direct copy.
    fs.copyFileSync(tmp, file);
    fs.rmSync(tmp, { force: true });
  }
}

function saveNow() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  try {
    writeAtomic(dataFile, JSON.stringify(E.prepareForSave(db), null, 1));
    lastPeriodicSave = Date.now();
    dailyBackup();
  } catch (err) {
    send('events', [{ type: 'saveError', message: `Couldn't save to ${dataDir}. ${err.message}` }]);
  }
}
function saveSoon() {
  if (saveTimer) return;
  saveTimer = setTimeout(saveNow, 300);
}

function backup(tag) {
  const stamp = new Date().toISOString().slice(0, 10);
  const name = `poker-night-${stamp}${tag ? `-${tag}` : ''}.json`;
  const file = path.join(backupDir, name);
  if (fs.existsSync(dataFile)) fs.copyFileSync(dataFile, file);
  const all = fs.readdirSync(backupDir).filter((f) => f.endsWith('.json')).sort();
  while (all.length > BACKUPS_TO_KEEP) fs.rmSync(path.join(backupDir, all.shift()), { force: true });
}
function dailyBackup() {
  const stamp = new Date().toISOString().slice(0, 10);
  if (!fs.existsSync(path.join(backupDir, `poker-night-${stamp}.json`))) backup();
}

function loadDb() {
  if (fs.existsSync(dataFile)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
      if (!E.isValidDb(parsed)) throw new Error('not a Poker Night file');
      if ((parsed.leagueVersion || 0) < E.LEAGUE_VERSION) backup('before-league-update');
      return E.normalizeAfterLoad(parsed);
    } catch (err) {
      // Keep the damaged file and fall back to the newest good backup.
      fs.copyFileSync(dataFile, path.join(dataDir, `damaged-${Date.now()}.json`));
      const backups = fs.readdirSync(backupDir).filter((f) => f.endsWith('.json')).sort().reverse();
      for (const f of backups) {
        try {
          const parsed = JSON.parse(fs.readFileSync(path.join(backupDir, f), 'utf8'));
          if (E.isValidDb(parsed)) {
            startupNotice = `The save file couldn't be read, so Poker Night opened the backup ${f}. The damaged file was kept in the data folder.`;
            return E.normalizeAfterLoad(parsed);
          }
        } catch (_) { /* try the next backup */ }
      }
      startupNotice = 'The save file couldn’t be read and no backup worked, so Poker Night started over with an empty season. The damaged file was kept in the data folder.';
    }
  }
  return E.normalizeAfterLoad(E.emptyDb());
}

/* ---------- Sending state to the screens ---------- */

function tvStatus() {
  const primary = screen.getPrimaryDisplay();
  const displays = screen.getAllDisplays();
  return {
    mode: tvMode,
    displayId: tvDisplayId,
    displays: displays.filter((d) => d.id !== primary.id).map((d, i) => ({ id: d.id, label: `Screen ${i + 2} (${d.size.width} by ${d.size.height})` })),
    hasSecondScreen: displays.length > 1,
  };
}

function snapshot() {
  return {
    rev: db.rev,
    testData: db.testData,
    settings: db.settings,
    players: db.players,
    seasons: db.seasons,
    activeSeasonId: db.activeSeasonId,
    view: E.derive(db),
    tv: tvStatus(),
    dataDir,
    notice: startupNotice,
    remote: remote ? remote.status() : null,
    version: VERSION,
    update: updater ? updater.status() : null,
    platform: process.platform,
  };
}

function send(channel, payload) {
  [controlWin, tvWin].forEach((w) => { if (w && !w.isDestroyed()) w.webContents.send(channel, payload); });
  if (remote) remote.send(channel, payload);
}
function broadcast() { send('state', snapshot()); updatePowerBlock(); }

function updatePowerBlock() {
  const t = db && E.current(db);
  const needed = !!tvWin || (t && t.status === 'running');
  if (needed && blockerId === null) blockerId = powerSaveBlocker.start('prevent-display-sleep');
  if (!needed && blockerId !== null) { powerSaveBlocker.stop(blockerId); blockerId = null; }
  // While an iPad can run the game, the computer must not go to sleep, or the iPad loses it. The screen may still turn off.
  const awake = !!(remote && remote.status().running);
  if (awake && awakeId === null) awakeId = powerSaveBlocker.start('prevent-app-suspension');
  if (!awake && awakeId !== null) { powerSaveBlocker.stop(awakeId); awakeId = null; }
}

/* ---------- Windows ---------- */

const webPrefs = (extra = {}) => ({
  preload: path.join(__dirname, 'preload.js'),
  contextIsolation: true,
  nodeIntegration: false,
  sandbox: true,
  backgroundThrottling: false,
  ...extra,
});

function lockDown(win) {
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e) => e.preventDefault());
}

function createControl() {
  controlWin = new BrowserWindow({
    width: 1366, height: 800, minWidth: 1100, minHeight: 680,
    title: 'Poker Night',
    backgroundColor: '#e8eeea',
    ...(IS_MAC ? {} : { icon: path.join(__dirname, 'assets', 'icon.ico') }),
    autoHideMenuBar: true,
    show: false,
    webPreferences: webPrefs({ autoplayPolicy: 'no-user-gesture-required' }),
  });
  lockDown(controlWin);
  controlWin.loadFile(path.join(__dirname, 'ui', 'control.html'));
  controlWin.once('ready-to-show', () => { if (!IS_TEST) controlWin.maximize(); controlWin.show(); });
  controlWin.on('close', (e) => {
    if (quitting || IS_TEST) return;
    const t = E.current(db);
    if (t && t.status === 'running') {
      const choice = dialog.showMessageBoxSync(controlWin, {
        type: 'question', buttons: ['Keep playing', 'Close Poker Night'], defaultId: 0, cancelId: 0,
        title: 'Close Poker Night?',
        message: 'A game is in progress.',
        detail: 'Everything is saved. The clock will be paused when you open Poker Night again.',
      });
      if (choice === 0) { e.preventDefault(); return; }
    }
    quitting = true;
  });
  controlWin.on('closed', () => {
    controlWin = null;
    saveNow();
    if (tvWin && !tvWin.isDestroyed()) tvWin.destroy();
    app.quit();
  });
}

function openTv(mode, displayId) {
  closeTv(false);
  let tvBounds = null;
  const base = {
    title: 'Poker Night TV',
    backgroundColor: '#0d3d2f',
    ...(IS_MAC ? {} : { icon: path.join(__dirname, 'assets', 'icon.ico') }),
    autoHideMenuBar: true,
    show: false,
    webPreferences: webPrefs(),
  };
  if (mode === 'screen') {
    const primary = screen.getPrimaryDisplay();
    const d = screen.getAllDisplays().find((x) => x.id === displayId) || chooseTvDisplay(screen.getAllDisplays(), primary.id, displayId);
    if (!d) return false;
    tvDisplayId = d.id;
    tvBounds = d.bounds;
    tvWin = new BrowserWindow({ ...base, x: d.bounds.x, y: d.bounds.y, width: d.bounds.width, height: d.bounds.height, frame: false, fullscreenable: true });
  } else {
    tvDisplayId = null;
    tvWin = new BrowserWindow({ ...base, width: 1120, height: 630, useContentSize: true });
  }
  tvMode = mode;
  lockDown(tvWin);
  tvWin.loadFile(path.join(__dirname, 'ui', 'tv.html'));
  const thisWin = tvWin;
  thisWin.once('ready-to-show', () => {
    if (thisWin.isDestroyed()) return;
    if (IS_MAC && tvBounds) {
      // A Mac window has to be visible on the TV before it can go full screen there.
      thisWin.setBounds(tvBounds);
      thisWin.showInactive();
      thisWin.once('enter-full-screen', () => { if (controlWin) controlWin.focus(); });
      thisWin.setFullScreen(true);
      return;
    }
    if (tvBounds) { thisWin.setBounds(tvBounds); thisWin.setFullScreen(true); }
    thisWin.showInactive();
    if (controlWin) controlWin.focus();
  });
  thisWin.on('closed', () => {
    if (tvWin !== thisWin) return;
    tvWin = null; tvMode = 'closed'; tvDisplayId = null;
    broadcast();
  });
  broadcast();
  return true;
}

function closeTv(notify = true) {
  if (tvWin && !tvWin.isDestroyed()) {
    const w = tvWin;
    tvWin = null; tvMode = 'closed'; tvDisplayId = null;
    w.destroy();
  }
  if (notify) broadcast();
}

function autoOpenTv() {
  if (tvMode === 'window') return;
  const primary = screen.getPrimaryDisplay();
  const target = chooseTvDisplay(screen.getAllDisplays(), primary.id, tvDisplayId);
  const tvStillThere = screen.getAllDisplays().some((d) => d.id === tvDisplayId);
  if (target && (tvMode !== 'screen' || !tvStillThere)) openTv('screen', target.id);
  if (!target && tvMode === 'screen') closeTv();
  broadcast();
}

/* ---------- Commands from the screens ---------- */

const commands = {
  async backupNow() {
    saveNow();
    const res = await dialog.showSaveDialog(controlWin, {
      title: 'Save a backup', defaultPath: `Poker Night backup ${new Date().toISOString().slice(0, 10)}.json`,
      filters: [{ name: 'Poker Night backup', extensions: ['json'] }],
    });
    if (res.canceled || !res.filePath) return { canceled: true };
    fs.copyFileSync(dataFile, res.filePath);
    return { message: 'Backup saved.' };
  },
  async restore() {
    const res = await dialog.showOpenDialog(controlWin, {
      title: 'Choose a backup to restore', defaultPath: backupDir, properties: ['openFile'],
      filters: [{ name: 'Poker Night backup', extensions: ['json'] }],
    });
    if (res.canceled || !res.filePaths.length) return { canceled: true };
    let parsed;
    try { parsed = JSON.parse(fs.readFileSync(res.filePaths[0], 'utf8')); } catch (_) { throw new Error('That file isn’t a Poker Night backup.'); }
    if (!E.isValidDb(parsed)) throw new Error('That file isn’t a Poker Night backup.');
    backup('before-restore');
    db = E.normalizeAfterLoad(parsed);
    saveNow();
    return { message: 'Backup restored.' };
  },
  async exportCsv() {
    const res = await dialog.showSaveDialog(controlWin, {
      title: 'Save the standings', defaultPath: 'Season standings.csv', filters: [{ name: 'Spreadsheet (CSV)', extensions: ['csv'] }],
    });
    if (res.canceled || !res.filePath) return { canceled: true };
    fs.writeFileSync(res.filePath, `﻿${E.standingsCsv(db)}`);
    return { message: 'Standings saved.' };
  },
  recap(id) { return { html: Report.recapHtml(E.nightReport(db, id)) }; },
  async copyRecap(id) {
    const r = E.nightReport(db, id);
    // Both kinds, so an email keeps the tables and a plain-text box still gets something readable.
    await clipboard.write([new ClipboardItem({ 'text/plain': Report.recapText(r), 'text/html': Report.recapHtml(r) })]);
    return { message: 'Copied. Start a new email and paste it in.' };
  },
  async saveRecapPdf(id) {
    const r = E.nightReport(db, id);
    const res = await askSavePath({
      title: 'Save the results as a PDF', defaultPath: path.join(app.getPath('documents'), safeName(`${r.league} - ${r.name} results.pdf`)), filters: [{ name: 'PDF', extensions: ['pdf'] }],
    });
    if (res.canceled || !res.filePath) return { canceled: true };
    const win = new BrowserWindow({ show: false, webPreferences: { sandbox: true, contextIsolation: true, javascript: false } });
    try {
      await win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(Report.recapPage(r))}`);
      const pdf = await win.webContents.printToPDF({ pageSize: 'Letter', printBackground: true, margins: { marginType: 'custom', top: 0.6, bottom: 0.6, left: 0.6, right: 0.6 } });
      fs.writeFileSync(res.filePath, pdf);
    } finally { win.destroy(); }
    return { message: 'PDF saved. You can attach it to an email.' };
  },
  async exportExcel() {
    const season = E.seasonReport(db);
    const res = await askSavePath({
      title: 'Save the season to Excel', defaultPath: path.join(app.getPath('documents'), safeName(`${season.league} ${season.seasonName}.xlsx`)), filters: [{ name: 'Excel workbook', extensions: ['xlsx'] }],
    });
    if (res.canceled || !res.filePath) return { canceled: true };
    const today = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    try {
      fs.writeFileSync(res.filePath, Xlsx.workbook(Report.seasonSheets(season, today)));
    } catch (err) {
      if (err.code === 'EBUSY' || err.code === 'EPERM') throw new Error('That file is open in Excel. Close it there, then save again.');
      throw err;
    }
    if (!process.env.POKER_SAVE_DIR) shell.openPath(res.filePath);
    return { message: 'Saved. Opening it in Excel now.' };
  },
  openDataFolder() { shell.openPath(dataDir); return {}; },
  async updateCheck() {
    const s = await updater.check();
    if (s.phase === 'error') throw new Error(s.error);
    return { message: s.phase === 'available' ? `Version ${s.latest.version} is available.` : 'You have the newest version.' };
  },
  async updateInstall() {
    await updater.download();
    return { message: 'The update is downloaded. Restart Poker Night to finish.' };
  },
  updateRestart() {
    saveNow();
    app.relaunch();
    setTimeout(() => app.exit(0), 100);
    return {};
  },
  updateAuto(on) { updater.setAuto(on); return {}; },
  openReleasePage() {
    const s = updater.status();
    const url = (s.latest && s.latest.page) || `https://github.com/${PKG.pokerNight.releasesRepo}/releases/latest`;
    if (/^https:\/\/github\.com\//.test(url)) shell.openExternal(url);
    return {};
  },
  openGuide() { shell.openPath(path.join(__dirname, 'Poker Night Guide.pdf')); return {}; },
  tvOpenScreen(id) {
    if (!openTv('screen', id)) throw new Error(IS_MAC ? 'No second screen is connected. In System Settings, open Displays and set the TV to Extended display.' : 'No second screen is connected. Press the Windows key and P, then choose Extend.');
    return {};
  },
  tvOpenWindow() { openTv('window'); return {}; },
  tvClose() { closeTv(); return {}; },
  dismissNotice() { startupNotice = null; return {}; },
  remoteSet(on) { return new Promise((resolve, reject) => remote.setEnabled(!!on, () => { const e = remote.status().error; if (on && e) reject(new Error(e)); else resolve({}); })); },
  remoteNewPin() { remote.newPin(); return { message: 'New PIN made. Devices will need to enter it.' }; },
};

/* The save box. Tests skip it and save straight into a folder. */
function askSavePath(opts) {
  if (process.env.POKER_SAVE_DIR) return Promise.resolve({ filePath: path.join(process.env.POKER_SAVE_DIR, path.basename(opts.defaultPath)) });
  return dialog.showSaveDialog(controlWin, opts);
}

/* Characters Windows and Macs don't allow in file names. */
function safeName(name) { return name.replace(/[\\/:*?"<>|]/g, '-'); }

/* One place that applies a change, whether it came from this computer or from an iPad. */
function doAct(type, payload) {
  try {
    if (type === 't.close') { saveNow(); backup('night-closed'); }
    const events = E.dispatch(db, type, payload || {}, Date.now());
    saveNow();
    broadcast();
    if (events.length) send('events', events);
    return { ok: true };
  } catch (err) {
    if (err instanceof E.GameError) return { ok: false, error: err.message };
    console.error(err);
    return { ok: false, error: `Something went wrong: ${err.message}` };
  }
}

function startUpdater() {
  const boot = global.pokerBoot || {};
  updater = createUpdater({
    fetch: (url, opts) => net.fetch(url, opts),
    currentVersion: VERSION,
    electronVersion: process.versions.electron,
    updatesDir: boot.updatesDir || path.join(app.getPath('userData'), 'Updates'),
    repo: PKG.pokerNight.releasesRepo,
    feedUrl: IS_TEST ? process.env.POKER_UPDATE_FEED : undefined,
    configFile: path.join(app.getPath('userData'), 'update-settings.json'),
    onChange: () => { if (controlWin && !controlWin.isDestroyed()) broadcast(); },
    log: (err) => console.error('update:', err.message),
  });
  if (!IS_TEST || process.env.POKER_UPDATE_FEED) updater.start();
}

function startRemote() {
  remote = createRemote({
    uiDir: path.join(__dirname, 'ui'),
    assetsDir: path.join(__dirname, 'assets'),
    guideFile: path.join(__dirname, 'Poker Night Guide.pdf'),
    configFile: path.join(dataDir, 'ipad-access.json'),
    defaultEnabled: IS_MAC,
    getState: snapshot,
    act: async (type, payload) => doAct(type, payload),
    notice: () => { startupNotice = null; broadcast(); },
    csv: () => E.standingsCsv(db),
    excel: () => Xlsx.workbook(Report.seasonSheets(E.seasonReport(db), new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }))),
    backupFile: () => { saveNow(); return fs.readFileSync(dataFile); },
    onClientsChanged: () => { if (controlWin && !controlWin.isDestroyed()) broadcast(); },
  });
  remote.start(() => broadcast());
}

function registerIpc() {
  ipcMain.handle('state:get', () => snapshot());
  ipcMain.handle('act', (_e, type, payload) => doAct(type, payload));
  ipcMain.handle('command', async (_e, name, arg) => {
    try {
      if (!Object.prototype.hasOwnProperty.call(commands, name)) throw new Error('Unknown command.');
      const result = await commands[name](arg);
      broadcast();
      return { ok: true, ...result };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });
}

function startClockLoop() {
  setInterval(() => {
    const events = E.tick(db, Date.now());
    if (events.length) {
      saveNow();
      broadcast();
      send('events', events);
    } else if (E.current(db) && E.current(db).clock.running && Date.now() - lastPeriodicSave > 10000) {
      saveSoon();
    }
  }, 250);
}

/* ---------- Start up ---------- */

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (controlWin) { if (controlWin.isMinimized()) controlWin.restore(); controlWin.focus(); }
  });
  app.whenReady().then(() => {
    // A Mac needs its menu for Quit, and for copy and paste in text boxes.
    Menu.setApplicationMenu(IS_MAC ? Menu.buildFromTemplate([{ role: 'appMenu' }, { role: 'editMenu' }, { role: 'windowMenu' }]) : null);
    setupPaths();
    db = loadDb();
    saveNow();
    registerIpc();
    startRemote();
    startUpdater();
    createControl();
    // This copy started properly, so the launcher can trust it next time.
    controlWin.webContents.once('did-finish-load', () => { try { fs.rmSync(path.join(__dirname, '.starting'), { force: true }); } catch (_) { /* fine */ } });
    startClockLoop();
    if (!IS_TEST) {
      controlWin.webContents.once('did-finish-load', autoOpenTv);
      screen.on('display-added', autoOpenTv);
      screen.on('display-removed', autoOpenTv);
    }
  });
  app.on('before-quit', () => { quitting = true; if (remote) remote.shutdown(); if (updater) updater.stop(); });
  app.on('window-all-closed', () => app.quit());
}
