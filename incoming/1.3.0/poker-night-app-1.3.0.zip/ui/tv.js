'use strict';
/* The TV only shows information; everything is controlled from the Dell. */
(() => {
  const { esc, money, num, ordinal, remaining, clockText, timeAt, blinds } = window.pk;
  const sceneEl = document.getElementById('scene');
  const bannerEl = document.getElementById('banner');
  let S = null;
  let lastScene = null;
  let bannerTimer = null;
  let flashIds = new Set();
  let prevPositions = new Map();
  const startedAt = Date.now();

  function effectiveScene() {
    const t = S.view.tournament;
    if (t && t.status === 'running' && t.redrawNotice) return 'redraw';
    const chosen = S.settings.tv.scene;
    if (chosen && chosen !== 'auto') {
      if (chosen === 'clock' && (!t || t.status === 'setup')) return 'standings';
      if ((chosen === 'payouts' || chosen === 'seating') && !t) return 'standings';
      return chosen === 'clock' ? playScene() : chosen;
    }
    if (!t || t.status === 'setup') return 'standings';
    if (t.status === 'finished') return 'winner';
    return playScene();
  }

  function playScene() {
    if (S.settings.tv.duringPlay === 'alternate') {
      const secs = Math.max(5, S.settings.tv.alternateSeconds || 20);
      return Math.floor((Date.now() - startedAt) / 1000 / secs) % 2 === 0 ? 'clock' : 'standings';
    }
    return 'clock';
  }

  const header = () => {
    const t = S.view.tournament;
    const season = S.view.season ? S.view.season.name : '';
    const right = t && t.status !== 'setup' ? t.name : season;
    return `<div class="head"><div class="league">${esc(S.settings.leagueName)}</div><div class="sub">${esc(right)}</div></div>`;
  };

  function mvHtml(r) {
    if (!r.movement) return '';
    return r.movement > 0 ? `<span class="mv">▲${r.movement}</span>` : `<span class="mv down">▼${-r.movement}</span>`;
  }

  function compactStandings() {
    const rowsMax = Math.max(3, S.settings.tv.standingsRows || 10);
    const list = S.view.standings;
    const shown = list.slice(0, rowsMax);
    const rows = shown.map((r) => {
      const isOut = r.tonight && r.tonight.status === 'out';
      const tonight = r.tonight && r.tonight.points ? `+${num(r.tonight.points)}` : '';
      return `<div class="st-row ${isOut ? 'isOut' : ''} ${flashIds.has(r.playerId) ? 'flash' : ''}" data-key="${esc(r.playerId)}">
        <div class="rank">${r.rank}</div>
        <div class="nm">${esc(r.name)}${mvHtml(r)}</div>
        <div class="tonight r">${tonight}</div>
        <div class="pts r">${num(r.points)}</div>
      </div>`;
    }).join('');
    return `<section class="standings compact">
      <h2>Season standings</h2>
      <div class="st-head"><div></div><div>Player</div><div class="r">Tonight</div><div class="r">Points</div></div>
      <div class="st-rows">${rows || '<div class="more">No results yet</div>'}</div>
      <div class="more" data-more="${list.length}">${list.length > shown.length ? `${list.length - shown.length} more on the list` : ''}</div>
    </section>`;
  }

  function fullRows(list) {
    return `<div class="full">
      <div class="st-head"><div></div><div>Player</div><div class="r">Points</div><div class="r">KOs</div><div class="r">Nights</div><div class="r">Wins</div></div>
      <div class="st-rows">${list.map((r) => `<div class="st-row ${r.rank === 1 ? 'leader' : ''} ${flashIds.has(r.playerId) ? 'flash' : ''}" data-key="${esc(r.playerId)}">
        <div class="rank">${r.rank}</div>
        <div class="nm">${esc(r.name)}${mvHtml(r)}</div>
        <div class="pts r">${num(r.points)}</div>
        <div class="r">${r.kos}</div><div class="r">${r.nights}</div><div class="r">${r.wins}</div>
      </div>`).join('')}</div>
    </div>`;
  }

  function standingsScene() {
    const list = S.view.standings.slice(0, 36);
    const v = S.view;
    const count = v.nightsPlayed === 1 ? '1 night played' : `${v.nightsPlayed} nights played`;
    let body;
    if (!list.length) body = '<div class="emptybig">The standings will appear after the first knockout of the season.</div>';
    else if (list.length > 10) {
      const half = Math.ceil(list.length / 2);
      body = `<div class="cols two ${list.length > 20 ? 'many' : ''}">${fullRows(list.slice(0, half))}${fullRows(list.slice(half))}</div>`;
    } else body = `<div class="cols">${fullRows(list)}</div>`;
    const pot = v.seasonPot ? `, ${money(v.seasonPot)} in the TOC pot` : '';
    return `${header()}<div class="bigstand"><h1>Season standings</h1><div class="sub">${esc(count)}${esc(pot)}</div>${body}</div>`;
  }

  function highHandBox(t) {
    const hh = t.highHand;
    return `<section class="hhbox"><div class="hhhead"><h2>High hand</h2><span class="hhpay">${money(t.highHandPayout)}</span></div>${hh && hh.hand
      ? `<div class="hhcards">${esc(hh.hand)}</div><div class="hhwho">${esc(hh.name)}</div>`
      : '<div class="hhnone">None yet</div>'}</section>`;
  }

  function prizeBox(t) {
    return `<section class="prizebox">
      <div class="prizehead"><h2>Prize pool</h2><div class="pool">${money(t.pool)}</div></div>
      <div class="prizerows ${t.payouts.length > 5 ? 'twoup' : ''}">${t.payouts.map((p) => `<div class="pz"><span class="k">${ordinal(p.place)}</span><span class="v">${money(p.amount)}</span></div>`).join('')}</div>
    </section>`;
  }

  function highHandLine(t) {
    const hh = t.highHand;
    if (!hh || !hh.hand) return '';
    return `<div class="hhline">High hand: <b>${esc(hh.name)}</b>, ${esc(hh.hand)}${hh.amount ? `, ${money(hh.amount)}` : ''}</div>`;
  }

  function clockBlock(t) {
    const lvl = t.level;
    const isBreak = lvl.kind === 'break';
    const next = t.nextLevel;
    let upnext;
    if (!next) upnext = '<span class="quiet">Last round on the schedule</span>';
    else if (next.kind === 'break') upnext = `Next: <b>${next.minutes} minute break</b>`;
    else upnext = `Next: <b>${esc(blinds(next))}</b>`;
    return `<div class="clockside">
      <div class="roundname"><span>${isBreak ? 'Break' : `Round ${t.round}`}</span>${t.clock.running ? '' : '<span class="paused">Paused</span>'}<span class="breaktime" data-break></span></div>
      <div class="timer" data-timer></div>
      ${isBreak ? `<div class="cells"><div class="cell wide"><div class="k">On break</div><div class="v">${t.nextRoundLevel ? `Next ${esc(blinds(t.nextRoundLevel))}` : 'Back soon'}</div></div></div>` : `<div class="cells">
        <div class="cell"><div class="k">Small blind</div><div class="v">${num(lvl.sb)}</div></div>
        <div class="cell"><div class="k">Big blind</div><div class="v">${num(lvl.bb)}</div></div>
        ${lvl.ante ? `<div class="cell"><div class="k">Ante</div><div class="v">${num(lvl.ante)}</div></div>` : ''}
      </div>`}
      <div class="upnext">${upnext}<span class="quiet" data-when></span></div>
      <div class="spacer"></div>
      <div class="bottomline"><span>${t.aliveCount} of ${t.entryCount} players left</span>${t.rebuysOpen ? `<span class="notice-rebuy">Rebuys open through round ${t.config.rebuy.lastRound}</span>` : ''}</div>
    </div>`;
  }

  function winnerScene(t) {
    const winner = t.entries.find((e) => e.place === 1);
    const pays = t.payouts.map((p) => `<div class="payrow"><div>${ordinal(p.place)}</div><div class="who">${esc(p.name || '')}</div><div class="amt">${money(p.amount)}</div></div>`).join('');
    return `${header()}<div class="winner">
      <div class="say">
        <div class="name">${esc(winner ? winner.name : '')}</div>
        <div class="wins">wins ${esc(t.name)}</div>
        <div class="payrows ${t.payouts.length > 5 ? 'tight' : ''}">${pays}</div>
        ${highHandLine(t)}
      </div>
      ${compactStandings()}
    </div>`;
  }

  function payoutScene(t) {
    const pays = t.payouts.map((p) => `<div class="payrow"><div>${ordinal(p.place)}</div><div class="who">${esc(p.name || '')}</div><div class="amt">${money(p.amount)}</div></div>`).join('');
    return `${header()}<div class="payscene"><h1>Payouts</h1><div class="pool">Prize pool ${money(t.pool)}</div><div class="payrows">${pays}</div></div>`;
  }

  function seatingScene(t) {
    const seated = t.entries.filter((e) => e.table && e.status === 'in');
    if (!seated.length) return `${header()}<div class="emptybig">Seats haven’t been drawn yet.</div>`;
    const tables = [...new Set(seated.map((e) => e.table))].sort((a, b) => a - b);
    const cols = Math.min(tables.length, 4);
    const html = tables.map((tb) => `<div class="tb"><h2>Table ${tb}</h2>${seated.filter((e) => e.table === tb).sort((a, b) => a.seat - b.seat)
      .map((e) => `<div class="seat"><div class="n">${e.seat}</div><div>${esc(e.name)}</div>${e.startChips ? `<div class="chips">${num(e.startChips)}</div>` : ''}</div>`).join('')}</div>`).join('');
    return `${header()}<div class="seatscene"><h1>Tables</h1><div class="tables" style="grid-template-columns: repeat(${cols}, minmax(0, 1fr))">${html}</div></div>`;
  }

  /* After the redraw at 16 players: the same tables, with the announcement and a small clock. */
  function redrawScene(t) {
    const rn = t.redrawNotice;
    const one = rn.tables === 1;
    const sub = `${rn.players} players left. ${one ? 'Seats' : 'Tables'} were drawn again at random. Find your new seat.`;
    const body = seatingScene(t).replace('<h1>Tables</h1>', `<div class="redrawhead"><div><h1>${one ? 'Seats redrawn' : 'Tables redrawn'}</h1><div class="redrawsub">${sub}</div></div><div class="redrawclock"><div class="timer small" data-timer></div>${t.clock.running ? '' : '<span class="paused">Paused</span>'}</div></div>`);
    return body;
  }

  function render() {
    if (!S) return;
    const t = S.view.tournament;
    const scene = effectiveScene();
    lastScene = scene;
    document.body.style.cursor = S.tv.mode === 'window' ? 'default' : 'none';
    capturePositions();
    let html;
    if (scene === 'standings') html = standingsScene();
    else if (scene === 'winner' && t) html = winnerScene(t);
    else if (scene === 'payouts' && t) html = payoutScene(t);
    else if (scene === 'seating' && t) html = seatingScene(t);
    else if (scene === 'redraw' && t) html = redrawScene(t);
    else if (scene === 'clock' && t) html = `${header()}<div class="play">${clockBlock(t)}<div class="rightcol">${t.highHandEnabled ? highHandBox(t) : ''}${prizeBox(t)}</div></div>`;
    else html = standingsScene();
    sceneEl.innerHTML = html;
    playMoves();
    updateClock();
  }

  /* Rows glide to their new place when a knockout changes the standings. */
  function capturePositions() {
    prevPositions = new Map();
    sceneEl.querySelectorAll('.st-row[data-key]').forEach((el) => prevPositions.set(el.dataset.key, el.getBoundingClientRect().top));
  }
  function playMoves() {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    sceneEl.querySelectorAll('.st-row[data-key]').forEach((el) => {
      const before = prevPositions.get(el.dataset.key);
      if (before === undefined) return;
      const dy = before - el.getBoundingClientRect().top;
      if (Math.abs(dy) > 2) el.animate([{ transform: `translateY(${dy}px)` }, { transform: 'none' }], { duration: 650, easing: 'cubic-bezier(.2,.8,.3,1)' });
    });
  }

  function updateClock() {
    if (!S) return;
    const t = S.view.tournament;
    if (S.settings.tv.duringPlay === 'alternate' && t && t.status === 'running' && (!S.settings.tv.scene || S.settings.tv.scene === 'auto' || S.settings.tv.scene === 'clock')) {
      if (effectiveScene() !== lastScene) { render(); return; }
    }
    const timer = sceneEl.querySelector('[data-timer]');
    if (!timer || !t) return;
    const ms = remaining(t.clock);
    const text = clockText(ms);
    if (timer.textContent !== text) timer.textContent = text;
    timer.classList.toggle('lastminute', ms <= 60000 && t.clock.running);
    timer.classList.toggle('isPaused', !t.clock.running);
    const when = sceneEl.querySelector('[data-when]');
    if (when) when.textContent = t.nextLevel && t.clock.running ? ` at ${timeAt(ms)}` : '';
    const brk = sceneEl.querySelector('[data-break]');
    if (brk) {
      if (t.level.kind === 'break') brk.textContent = '';
      else if (t.msAfterCurrentToBreak === null) brk.textContent = 'No more breaks';
      else brk.textContent = `Next break ${clockText(ms + t.msAfterCurrentToBreak)}`;
    }
  }

  function showBanner(text, calm) {
    bannerEl.textContent = text;
    bannerEl.classList.toggle('calm', !!calm);
    bannerEl.classList.add('show');
    clearTimeout(bannerTimer);
    bannerTimer = setTimeout(() => bannerEl.classList.remove('show'), 7000);
  }

  window.poker.onEvents((events) => {
    events.forEach((e) => {
      if (e.type === 'knockout') {
        const by = e.by ? `, knocked out by ${e.by}` : '';
        if (e.rebought) showBanner(`${e.victim} rebuys${e.by ? `, knockout for ${e.by}` : ''}`);
        else showBanner(`${e.victim} out in ${e.placeLabel}${by}`);
        const hits = S ? S.view.standings.filter((r) => (e.byNames || []).includes(r.name)) : [];
        flashIds = new Set(hits.map((r) => r.playerId));
        setTimeout(() => { flashIds = new Set(); }, 2500);
        render();
      } else if (e.type === 'highHand') {
        showBanner(`New high hand: ${e.name}, ${e.hand}`, true);
      } else if (e.type === 'tablesRedrawn') {
        bannerEl.classList.remove('show');
      } else if (e.type === 'undo') {
        showBanner(`Corrected: ${e.label}`, true);
      } else if (e.type === 'rebuysClosed') {
        showBanner('Rebuys are now closed', true);
      } else if (e.type === 'rebuy') {
        showBanner(`${e.name} rebuys`, true);
      }
    });
  });

  window.poker.onState((s) => { S = s; render(); });
  window.poker.getState().then((s) => { S = s; render(); });
  setInterval(updateClock, 200);
})();
