'use strict';
/* Small helpers shared by the Dell screen and the TV screen. */
window.pk = {
  esc(v) {
    return String(v === null || v === undefined ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  },
  money(n) {
    const v = Number(n) || 0;
    return `$${v.toLocaleString('en-US', { minimumFractionDigits: Number.isInteger(v) ? 0 : 2, maximumFractionDigits: 2 })}`;
  },
  num(n) { return (Number(n) || 0).toLocaleString('en-US'); },
  ordinal(n) {
    const s = ['th', 'st', 'nd', 'rd'];
    const v = n % 100;
    return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`;
  },
  remaining(clock) {
    return clock.running ? clock.remainingMs - (Date.now() - clock.anchor) : clock.remainingMs;
  },
  clockText(ms) {
    const total = Math.max(0, Math.ceil(ms / 1000));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    const ss = String(s).padStart(2, '0');
    return h ? `${h}:${String(m).padStart(2, '0')}:${ss}` : `${String(m).padStart(2, '0')}:${ss}`;
  },
  timeAt(ms) {
    return new Date(Date.now() + ms).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
  },
  dateText(iso) {
    if (!iso) return '';
    const d = new Date(`${iso}T12:00:00`);
    return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  },
  blinds(level) {
    if (!level || level.kind !== 'round') return '';
    return `${pk.num(level.sb)} / ${pk.num(level.bb)}${level.ante ? ` + ${pk.num(level.ante)} ante` : ''}`;
  },
};
