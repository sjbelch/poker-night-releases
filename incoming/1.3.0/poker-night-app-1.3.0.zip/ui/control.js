'use strict';
/* The Dell screen. Screens are redrawn from the state the app sends after each change. */
(() => {
  const { esc, money, num, ordinal, remaining, clockText, timeAt, dateText, blinds } = window.pk;
  const app = document.getElementById('app');
  const modalEl = document.getElementById('modal');
  const toastEl = document.getElementById('toast');

  let S = null;
  let tab = 'game';
  let sideTab = 'in';
  let chartN = 17;
  let modal = null; // what dialog is open, and its step
  let toastTimer = null;
  const openNights = new Set();
  const scrollMemo = {};
  const REMOTE = !!window.poker.remote; // running in a web browser on an iPad or another device
  const store = {
    get(k) { try { return window.localStorage.getItem(k); } catch (_) { return null; } },
    set(k, v) { try { window.localStorage.setItem(k, v); } catch (_) { /* private browsing */ } },
  };
  const soundsHere = () => store.get('pn-sounds-here') !== 'off';

  /* ---------- Talking to the app ---------- */

  async function act(type, payload) {
    const res = await window.poker.act(type, payload);
    if (!res.ok) toast(res.error, true);
    return res.ok;
  }
  async function command(name, arg) {
    const res = await window.poker.command(name, arg);
    if (!res.ok) toast(res.error, true);
    else if (res.message) toast(res.message);
    return res;
  }
  function toast(text, isError) {
    toastEl.textContent = text;
    toastEl.className = `show${isError ? ' err' : ''}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.className = ''; }, isError ? 6000 : 4500);
  }

  /* ---------- Small builders ---------- */

  function field(label, set, path, value, opts = {}) {
    const id = `f-${set}-${path}`;
    const type = opts.type || 'number';
    const attrs = type === 'number' ? `min="${opts.min === undefined ? 0 : opts.min}" step="${opts.step || 'any'}" data-num="1"` : '';
    return `<label class="f" for="${id}">${esc(label)}<input id="${id}" type="${type}" value="${esc(value)}" ${attrs} data-set="${set}" data-path="${esc(path)}"></label>`;
  }
  function check(label, set, path, on, extra = '') {
    const id = `c-${set}-${path}`;
    return `<label class="check" for="${id}"><input id="${id}" type="checkbox" ${on ? 'checked' : ''} data-set="${set}" data-path="${esc(path)}" ${extra}>${esc(label)}</label>`;
  }
  function select(label, set, path, value, options) {
    const id = `s-${set}-${path}`;
    return `<label class="f" for="${id}">${esc(label)}<select id="${id}" data-set="${set}" data-path="${esc(path)}">${options.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(value) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>`;
  }

  const sceneSelect = () => {
    const opts = [['auto', 'Automatic'], ['clock', 'Clock'], ['standings', 'Season standings'], ['payouts', 'Payouts'], ['seating', 'Tables']];
    return `<label for="tv-scene">TV shows</label> <select id="tv-scene" data-set="settings.set" data-path="tv.scene">${opts.map(([v, l]) => `<option value="${v}" ${S.settings.tv.scene === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
  };

  /* ---------- Frame ---------- */

  function topbar() {
    const tv = S.tv;
    let tvHtml;
    if (REMOTE) tvHtml = `<span><span class="dot on"></span>Connected</span>`;
    else if (tv.mode === 'screen') tvHtml = `<span><span class="dot on"></span>TV is on</span><button class="btn ghost" data-do="tvClose">Turn off</button>`;
    else if (tv.mode === 'window') tvHtml = `<span><span class="dot on"></span>TV preview window is open</span><button class="btn ghost" data-do="tvClose">Close</button>`;
    else if (tv.hasSecondScreen) tvHtml = `<span><span class="dot"></span>TV is off</span><button class="btn ghost" data-do="tvOpenScreen">Show on TV</button>`;
    else tvHtml = `<span title="${S.platform === 'darwin' ? 'To use the TV, open Displays in System Settings and set the TV to Extended display.' : 'To use the TV, press the Windows key and P, then choose Extend.'}"><span class="dot"></span>No TV found</span><button class="btn ghost" data-do="tvOpenWindow">Preview TV</button>`;
    const tabs = [['game', 'Game night'], ['standings', 'Season standings'], ['players', 'Players'], ['past', 'Past nights'], ['settings', 'Settings']];
    return `<header class="topbar">
      <div class="brand">${esc(S.settings.leagueName)}</div>
      <nav class="tabs">${tabs.map(([k, l]) => `<button class="tab ${tab === k ? 'on' : ''}" data-do="tab" data-tab="${k}">${l}</button>`).join('')}</nav>
      <div class="tvstate">${tvHtml}</div>
    </header>
    ${S.notice ? `<div class="noticebar"><span>${esc(S.notice)}</span><button class="linkbtn" data-do="dismissNotice">Dismiss</button></div>` : ''}
`;
  }

  /* ---------- Game night ---------- */

  function updateNote() {
    const u = S.update;
    if (REMOTE || !u) return '';
    if (u.phase === 'ready') return `<div class="updatenote"><span>Version ${esc(u.readyVersion)} is ready.</span><button class="btn small primary" data-do="updateRestart">Restart to finish</button></div>`;
    if (u.phase === 'available' && u.latest) return `<div class="updatenote"><span>Version ${esc(u.latest.version)} of Poker Night is available.</span><button class="btn small" data-do="goSettings">See what’s new</button></div>`;
    if (u.phase === 'downloading') return '<div class="updatenote"><span>Downloading the update…</span></div>';
    return '';
  }

  function updatePanel() {
    const u = S.update;
    if (REMOTE || !u) return '';
    const notes = (u.latest && u.latest.notes && u.latest.notes.length) ? `<ul class="notes">${u.latest.notes.map((n) => `<li>${esc(n)}</li>`).join('')}</ul>` : '';
    let body;
    if (u.phase === 'ready') {
      body = `<p><b>Version ${esc(u.readyVersion)} is downloaded.</b> Restart Poker Night to start using it. Your records are kept, and a game in progress comes back with the clock paused.</p>
        ${notes}<div class="row"><button class="btn primary" data-do="updateRestart">Restart Poker Night</button></div>`;
    } else if (u.phase === 'downloading') {
      body = '<p>Downloading the update. This takes a moment.</p>';
    } else if (u.phase === 'available' && u.latest) {
      body = `<p><b>Version ${esc(u.latest.version)} is available.</b> You have version ${esc(u.current)}.</p>${notes}
        ${u.latest.needsInstaller
          ? '<p class="hint">This one needs the full installer, because it changes the parts Poker Night runs on.</p><div class="row"><button class="btn primary" data-do="openReleasePage">Download the installer</button></div>'
          : '<div class="row"><button class="btn primary" data-do="updateInstall">Install the update</button></div>'}
        ${u.error ? `<p class="hint" style="color:var(--chip-deep)">${esc(u.error)}</p>` : ''}`;
    } else if (u.phase === 'checking') {
      body = '<p>Checking for updates…</p>';
    } else if (u.phase === 'error') {
      body = `<p class="hint" style="color:var(--chip-deep)">${esc(u.error)}</p>`;
    } else if (u.phase === 'current') {
      body = `<p>You have the newest version, ${esc(u.current)}.</p>`;
    } else {
      body = `<p>You have version ${esc(u.current)}.</p>`;
    }
    return `<section class="panel"><h2>Updates</h2>${body}
      <div class="row" style="margin-top:10px"><button class="btn small" data-do="updateCheck" ${u.phase === 'checking' || u.phase === 'downloading' ? 'disabled' : ''}>Check for updates</button></div>
      <label class="check" for="update-auto" style="margin-top:10px"><input id="update-auto" type="checkbox" ${u.auto ? 'checked' : ''} data-update-auto="1">Check for updates automatically when this computer is online</label>
    </section>`;
  }

  function ipadHint() {
    const r = S.remote;
    if (REMOTE || !r || !r.running || !r.urls.length) return '';
    return `<p class="hint ipadhint">To run the game from an iPad, open Safari on it and go to <b>${esc(r.urls[0])}</b>, then enter PIN <b>${esc(r.pin)}</b>.</p>`;
  }

  function ipadPanel() {
    const r = S.remote;
    // Only the Mac version offers this for now.
    if (!r || (S.platform !== 'darwin' && !r.enabled)) return '';
    if (REMOTE) {
      return `<section class="panel"><h2>This device</h2>
        <p class="hint" style="margin-top:0">You’re running Poker Night from the computer over Wi-Fi. Everything is saved on the computer, which needs to stay on with Poker Night open.</p>
        ${check('Play sounds on this device', 'local', 'soundsHere', soundsHere())}
        ${r.urls.length ? `<p class="hint">To show the game on a TV in this room, open <b>${esc(r.urls[0])}/tv</b> in the TV’s web browser.</p>` : ''}
      </section>`;
    }
    const on = r.enabled;
    let body = '';
    if (on && r.running) {
      body = `<table class="grid ipadgrid"><tbody>
        <tr><td>Address</td><td><b>${esc(r.urls[0] || '')}</b>${r.urls.length > 1 ? `<div class="hint" style="margin:2px 0 0">If that doesn’t open, try ${r.urls.slice(1).map((u) => esc(u)).join(' or ')}</div>` : ''}</td></tr>
        <tr><td>PIN</td><td><b class="pin">${esc(r.pin)}</b> <button class="btn small" data-do="remoteNewPin">Make a new PIN</button></td></tr>
        <tr><td>Connected now</td><td>${r.clients === 1 ? '1 device' : `${r.clients} devices`}${r.tvClients ? `, plus ${r.tvClients === 1 ? '1 TV screen' : `${r.tvClients} TV screens`}` : ''}</td></tr>
        <tr><td>TV in another room</td><td>${esc(r.urls[0] || '')}/tv <span class="hint">(no PIN needed, it can only watch)</span></td></tr>
      </tbody></table>
      <p class="hint" style="margin-bottom:0">Open the address in Safari on the iPad and enter the PIN. To keep it handy, tap the Share button, then <b>Add to Home Screen</b>. This computer stays awake while Poker Night is open, so the iPad can always reach it.</p>`;
    } else if (on && r.error) {
      body = `<p class="hint" style="color:var(--chip-deep)">${esc(r.error)}</p>`;
    } else {
      body = '<p class="hint" style="margin-bottom:0">Turn this on to knock players out, run the clock, and do everything else from an iPad or phone in another room.</p>';
    }
    return `<section class="panel"><h2>iPad and other devices</h2>
      <label class="check" for="remote-on"><input id="remote-on" type="checkbox" ${on ? 'checked' : ''} data-remote="1">Let devices on this Wi-Fi run Poker Night</label>
      ${body}
    </section>`;
  }

  function gamePage() {
    const t = S.view.tournament;
    if (!t) {
      return `<main class="page"><div class="panel empty"><h2>No tournament is set up</h2><p>Start a new night to check players in and set the buy-in and blinds.</p><div class="row" style="justify-content:center"><button class="btn primary huge" data-do="newNight">Set up a new night</button><button class="btn huge" data-do="newToc">Set up the Tournament of Champions</button></div>${updateNote()}${ipadHint()}</div></main>`;
    }
    if (t.status === 'setup') return setupPage(t);
    if (t.status === 'finished') return finishedPage(t);
    return playPage(t);
  }

  function setupPage(t) {
    const c = t.config;
    const active = S.players.filter((p) => p.active);
    const inIds = new Set(t.entries.map((e) => e.playerId));
    const pool = t.pool;
    const isToc = t.kind === 'toc';
    const rounds = c.levels.filter((l) => l.kind === 'round');
    const breaks = c.levels.length - rounds.length;
    const seated = t.seated;
    return `<main class="page" data-scroll="setup">
      <div class="startbar">
        <div><div class="sum">${t.entryCount} ${t.entryCount === 1 ? 'player' : 'players'} checked in, ${money(pool)} prize pool</div>
        <div class="hint">${isToc ? `${money(t.tocPot)} TOC pot plus ${money(t.tocFees)} in entry fees. Pays ${t.payouts.length} places.` : `${rounds.length} rounds, starting at ${esc(blinds(rounds[0]))}`}</div></div>
        <button class="btn" data-do="askCancelNight">Cancel this night</button>
        <div class="ml row"><button class="btn primary huge" data-do="start" ${t.entryCount < 2 ? 'disabled' : ''}>Start the tournament</button></div>
      </div>
      <div class="setup">
        <div class="stack">
          ${isToc ? tocCheckIn(t) : `<section class="panel">
            <div class="row" style="justify-content:space-between;margin-bottom:10px"><h2 style="font-size:16.5px">Who’s playing tonight?</h2>
              <div class="row"><button class="btn small" data-do="checkAll" data-on="1">Check in everyone</button><button class="btn small" data-do="checkAll" data-on="">Clear</button></div></div>
            ${active.length ? `<div class="checkgrid">${active.map((p) => `<button class="pcheck ${inIds.has(p.id) ? 'on' : ''}" aria-pressed="${inIds.has(p.id)}" data-do="checkin" data-id="${esc(p.id)}" data-on="${inIds.has(p.id) ? '' : '1'}"><span class="box">${inIds.has(p.id) ? '✓' : ''}</span><span>${esc(p.name)}</span></button>`).join('')}</div>` : '<p class="hint">Add your first player below.</p>'}
            <form class="addline" data-form="addPlayerCheck"><input id="add-player-check" name="name" placeholder="Add a new player" autocomplete="off"><button class="btn">Add and check in</button></form>
          </section>`}
          <section class="panel">
            <div class="row" style="justify-content:space-between"><h2 style="font-size:16.5px">Seats and tables</h2>
              <div class="row">${seated ? '<button class="btn small" data-do="clearSeats">Clear seats</button>' : ''}<button class="btn small" data-do="drawSeats" ${t.entryCount < 2 ? 'disabled' : ''}>${seated ? 'Draw again' : isToc ? 'Seat by standings' : 'Draw seats'}</button></div></div>
            ${seatingHtml(t) || (isToc ? '<p class="hint">Seats follow the season standings in snake order. On 3 tables, that’s 1, 2, 3, then 3, 2, 1. If you don’t draw them first, this happens when the tournament starts.</p>' : '<p class="hint">Optional. Drawing seats splits players across tables at random. Set “TV shows” to Tables to put the draw on the TV.</p>')}
            <div class="fields" style="margin-top:10px">
              ${field('Start on 2 tables at (players)', 't.config', 'startTwoAt', c.startTwoAt === undefined ? 10 : c.startTwoAt, { step: 1 })}
              ${field('Start on 3 tables at (players)', 't.config', 'startThreeAt', c.startThreeAt === undefined ? 20 : c.startThreeAt, { step: 1 })}
              ${field('Move to 2 tables at (players)', 't.config', 'breakToTwo', c.breakToTwo === undefined ? 16 : c.breakToTwo, { step: 1 })}
              ${field('Move to 1 table at (players)', 't.config', 'breakToOne', c.breakToOne === undefined ? 9 : c.breakToOne, { step: 1 })}
            </div>
            ${tableLimitNote(c)}
            ${seated ? `<div class="undo-inline row" style="margin-top:10px">${sceneSelect()}</div>` : ''}
          </section>
        </div>
        <div class="stack">
          <section class="panel"><h2>Tonight’s tournament</h2>
            <div class="fields">
              ${field('Name', 't.set', 'name', t.name, { type: 'text' })}
              ${field('Date', 't.set', 'date', t.date, { type: 'date' })}
              ${isToc ? '' : field('Buy-in to the pool ($)', 't.config', 'buyIn', c.buyIn)}
              ${isToc ? '' : field('Starting chips', 't.config', 'startingChips', c.startingChips)}
              ${field('Most players per table', 't.config', 'seatsPerTable', c.seatsPerTable, { min: 2, step: 1 })}
              ${isToc ? '' : field('Share to the TOC pot (%)', 't.config', 'rakePercent', c.rakePercent)}
            </div>
            ${isToc ? '' : `<p class="hint" style="margin:10px 0 0">Each player pays ${money(c.buyIn + S.settings.highHandPerPlayer)} in total, including ${money(S.settings.highHandPerPlayer)} for the high hand.</p>`}
            ${isToc && t.highHandEnabled ? `<p class="hint" style="margin:10px 0 0">Each player also pays ${money(S.settings.highHandPerPlayer)} for the high hand, on top of the entry fee.</p>` : ''}
            ${isToc ? '' : `<div style="margin-top:12px">${check('Count this night toward the season standings', 't.set', 'countsTowardSeason', t.countsTowardSeason)}</div>`}
          </section>
          <section class="panel"><div class="row" style="justify-content:space-between;margin-bottom:8px"><h2 style="font-size:16.5px">Blinds</h2><button class="btn small" data-do="openBlinds">Edit rounds and breaks</button></div>
            <p class="hint" style="margin:0">${rounds.length} rounds of ${rounds[0] ? rounds[0].minutes : 0} minutes, ${breaks} ${breaks === 1 ? 'break' : 'breaks'}. Ends at ${esc(blinds(rounds[rounds.length - 1]))}.</p>
          </section>
          <section class="panel"><h2>Rebuys</h2>
            ${check('Allow rebuys', 't.config', 'rebuy.enabled', c.rebuy.enabled)}
            ${c.rebuy.enabled ? `<div class="fields" style="margin-top:10px">
              ${field('Last round for rebuys', 't.config', 'rebuy.lastRound', c.rebuy.lastRound, { min: 1, step: 1 })}
              ${field('Cost ($)', 't.config', 'rebuy.cost', c.rebuy.cost)}
              ${field('Chips', 't.config', 'rebuy.chips', c.rebuy.chips)}
              ${field('Limit per player (0 = none)', 't.config', 'rebuy.maxPerPlayer', c.rebuy.maxPerPlayer, { step: 1 })}
            </div>` : ''}
          </section>
          <section class="panel"><h2>Add-ons</h2>
            ${check('Allow one add-on per player', 't.config', 'addon.enabled', c.addon.enabled)}
            ${c.addon.enabled ? `<div class="fields" style="margin-top:10px">
              ${field('Last round for add-ons', 't.config', 'addon.lastRound', c.addon.lastRound, { min: 1, step: 1 })}
              ${field('Cost ($)', 't.config', 'addon.cost', c.addon.cost)}
              ${field('Chips', 't.config', 'addon.chips', c.addon.chips)}
            </div>` : ''}
          </section>
        </div>
      </div>
    </main>`;
  }

  function tocCheckIn(t) {
    const inIds = new Set(t.entries.map((e) => e.playerId));
    const toc = S.settings.toc;
    const rows = S.view.standings.slice();
    S.players.filter((p) => p.active && !rows.some((r) => r.playerId === p.id)).forEach((p) => rows.push({ playerId: p.id, name: p.name, rank: '', points: 0, nights: 0 }));
    const minNights = toc.minNights;
    const feeFor = (nights) => (toc.fees.slice().sort((a, b) => b.minNights - a.minNights).find((f) => nights >= f.minNights) || { fee: null }).fee;
    return `<section class="panel">
      <div class="row" style="justify-content:space-between;margin-bottom:10px"><h2 style="font-size:16.5px">Who’s playing in the TOC?</h2>
        <div class="row"><button class="btn small" data-do="checkQualified">Check in everyone with ${minNights}+ nights</button><button class="btn small" data-do="checkAll" data-on="">Clear</button></div></div>
      <table class="grid tocgrid"><thead><tr><th></th><th class="r"></th><th>Player</th><th class="r">Points</th><th class="r">Nights</th><th class="r">Entry fee</th><th class="r">Starting chips</th></tr></thead>
      <tbody>${rows.map((r) => {
    const on = inIds.has(r.playerId);
    const fee = feeFor(r.nights);
    const ok = r.nights >= minNights;
    return `<tr class="${on ? 'on' : ''} ${ok ? '' : 'noq'}"><td>${ok ? `<button class="tocbox ${on ? 'on' : ''}" aria-pressed="${on}" aria-label="Check in ${esc(r.name)}" data-do="tocCheck" data-id="${esc(r.playerId)}" data-on="${on ? '' : '1'}">${on ? '✓' : ''}</button>` : ''}</td><td class="r">${r.rank}</td><td class="nm">${esc(r.name)}</td><td class="r">${num(r.points)}</td><td class="r">${r.nights}</td><td class="r">${ok ? money(fee) : `<span class="warnfee">Needs ${minNights} nights</span>`}</td><td class="r">${ok ? num(toc.baseChips + toc.chipsPerPoint * r.points) : ''}</td></tr>`;
  }).join('')}</tbody></table>
    </section>`;
  }

  function tableLimitNote(c) {
    const get = (k, d) => (c[k] === undefined ? d : c[k]);
    const clash = get('startThreeAt', 20) <= get('breakToTwo', 16) || get('startTwoAt', 10) <= get('breakToOne', 9);
    const text = clash
      ? 'These limits overlap, so a night could start on more tables and consolidate after the first knockout. Set each “Start on” number above the matching “Move to” number.'
      : `A table holds up to ${esc(String(c.seatsPerTable))} players. A bigger field adds a table even if these numbers don’t call for one.`;
    return `<p class="hint" style="margin:10px 0 0">${text}</p>`;
  }

  function seatingHtml(t) {
    const seated = t.entries.filter((e) => e.table && e.status === 'in');
    if (!seated.length) return '';
    const tables = [...new Set(seated.map((e) => e.table))].sort((a, b) => a - b);
    return `<div class="seatgrid">${tables.map((tb) => `<div><h3>Table ${tb}</h3>${seated.filter((e) => e.table === tb).sort((a, b) => a.seat - b.seat).map((e) => `<div class="s">${e.seat}. ${esc(e.name)}${e.startChips ? ` <span class="hint">${num(e.startChips)}</span>` : ''}</div>`).join('')}</div>`).join('')}</div>`;
  }

  function playPage(t) {
    const lvl = t.level;
    const isBreak = lvl.kind === 'break';
    const alive = t.entries.filter((e) => e.status === 'in').sort((a, b) => (a.table || 0) - (b.table || 0) || (a.seat || 0) - (b.seat || 0) || a.name.localeCompare(b.name));
    const out = t.entries.filter((e) => e.status === 'out').sort((a, b) => a.place - b.place);
    const next = t.nextLevel;
    const nextText = !next ? 'Last round on the schedule' : next.kind === 'break' ? `Next: ${next.minutes} minute break` : `Next: ${blinds(next)}`;
    const others = S.players.filter((p) => p.active && !t.entries.some((e) => e.playerId === p.id));

    const rows = alive.map((e) => {
      const bits = [];
      if (e.table) bits.push(`Table ${e.table}, seat ${e.seat}`);
      if (e.knockouts) bits.push(`${e.knockouts} ${e.knockouts === 1 ? 'KO' : 'KOs'}`);
      if (e.rebuys) bits.push(`${e.rebuys} ${e.rebuys === 1 ? 'rebuy' : 'rebuys'}`);
      const showAddon = t.addonsOpen && !e.addons;
      return `<div class="tile">
        <button class="main" data-do="ko" data-id="${esc(e.playerId)}" aria-label="Knock out ${esc(e.name)}">
          <span class="pn">${esc(e.name)}</span>
          ${bits.length ? `<span class="ps">${esc(bits.join(', '))}</span>` : ''}
        </button>
        <div class="acts">
          ${e.canRebuy ? `<button class="btn small" data-do="rebuy" data-id="${esc(e.playerId)}">Rebuy</button>` : ''}
          ${showAddon ? `<button class="btn small" data-do="addon" data-id="${esc(e.playerId)}">Add-on</button>` : ''}
          <button class="btn small koBtn" data-do="ko" data-id="${esc(e.playerId)}" tabindex="-1" aria-hidden="true">Out</button>
        </div>
      </div>`;
    }).join('');

    let sideBody;
    if (sideTab === 'out') {
      sideBody = out.length ? out.map((e) => `<div class="outline"><span>${ordinal(e.place)}</span><span class="who">${esc(e.name)}<span class="sub">${e.knockedOutBy ? `by ${esc(e.knockedOutBy)}` : 'no knockout credit'}</span></span>${e.canRebuy ? `<button class="btn small" data-do="rebuy" data-id="${esc(e.playerId)}">Rebuy</button>` : '<span></span>'}</div>`).join('') : '<p class="hint">Nobody is out yet.</p>';
    } else {
      sideBody = `<div class="tiles">${rows}</div>`;
    }
    const sideTabs = [['in', `Still in: ${t.aliveCount} of ${t.entryCount}`], ['out', `Out: ${out.length}`]];

    return `
    ${t.restartedPaused ? `<div class="noticebar"><span>Poker Night was closed during the game, so the clock is paused. Press Resume when everyone is ready.</span></div>` : ''}
    <main class="play">
      <div class="leftcol">
        <section class="hero">
          <div class="rd"><span>${isBreak ? 'Break' : `Round ${t.round}`}</span>${t.clock.running ? '' : '<span class="pausedtag">Paused</span>'}<span class="breakchip" data-break></span></div>
          <div class="time" data-time></div>
          ${isBreak ? `<div class="cells breakcell"><div class="cell"><span class="k">On break</span><span class="v">${t.nextRoundLevel ? `Next ${esc(blinds(t.nextRoundLevel))}` : 'Back soon'}</span></div></div>` : `<div class="cells">
            <div class="cell"><span class="k">Small blind</span><span class="v">${num(lvl.sb)}</span></div>
            <div class="cell"><span class="k">Big blind</span><span class="v">${num(lvl.bb)}</span></div>
            ${lvl.ante ? `<div class="cell"><span class="k">Ante</span><span class="v">${num(lvl.ante)}</span></div>` : ''}
          </div>`}
          <div class="nxt">${esc(nextText)}<span data-when></span></div>
          <div class="heronote"><span>${t.aliveCount} of ${t.entryCount} players left</span><span>${t.rebuysOpen ? `Rebuys open through round ${t.config.rebuy.lastRound}` : t.config.rebuy.enabled ? 'Rebuys closed' : ''}</span></div>
          <div class="clockctl">
            <button class="btn go ${t.clock.running ? '' : 'isPaused'}" data-do="clockToggle">${t.clock.running ? 'Pause' : 'Resume'}</button>
            <button class="btn ghost" data-do="clockPrev" ${t.levelIndex === 0 ? 'disabled' : ''} title="Go back one round">Back</button>
            <button class="btn ghost" data-do="clockNext" ${t.levelIndex >= t.levelCount - 1 ? 'disabled' : ''} title="Skip to the next round">Skip</button>
            <button class="btn ghost" data-do="clockAdd" data-s="60">+1 min</button>
            <button class="btn ghost" data-do="clockAdd" data-s="-60">−1 min</button>
            <label class="check" for="pause-after"><input id="pause-after" type="checkbox" ${t.clock.pauseAfter ? 'checked' : ''} data-set="clock.pauseAfter" data-field="on">Pause after this round</label>
          </div>
        </section>
        <div class="livebar">
          ${sceneSelect()}
          <button class="btn small" data-do="openBlinds">Edit blinds</button>
          ${others.length ? `<select id="late-player" data-set="late" aria-label="Add a late player"><option value="">Add a late player</option>${others.map((p) => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join('')}</select>` : ''}
          <button class="btn small" data-do="drawSeats" title="Assign seats and tables at random">${t.seated ? 'Redraw seats' : 'Draw seats'}</button>
          <button class="btn small" data-do="askCancelNight">Cancel night</button>
        </div>
      </div>
      <aside class="side">
        ${t.moves.length ? `<section class="panel moves"><div class="moveshead"><h2>Table moves</h2>${t.moves.length > 1 ? '<button class="btn small" data-do="applyAllMoves">All moved</button>' : ''}</div><p class="hint" style="margin:0 0 4px">${esc(t.moves[0].reason)}.</p>${t.moves.map((m) => `<div class="moveline"><span><b>${esc(m.name)}</b>: table ${m.from} to ${m.to}</span><button class="btn small" data-do="applyMove" data-id="${esc(m.playerId)}" data-to="${m.to}">Done</button></div>`).join('')}</section>` : ''}
        <section class="panel sidepanel">
          <div class="sidetabs">${sideTabs.map(([k, l]) => `<button class="sidetab ${sideTab === k ? 'on' : ''}" data-do="sideTab" data-tab="${k}">${esc(l)}</button>`).join('')}</div>
          ${t.undoLabel ? `<button class="btn small undo" data-do="undo">Undo: ${esc(t.undoLabel)}</button>` : ''}
          ${sideTab === 'in' ? '<p class="hint sidehint">Click a player when they’re knocked out.</p>' : ''}
          <div class="sidebody" data-scroll="side-${sideTab}">${sideBody}</div>
        </section>
        <section class="panel prizebox">
          <div class="prizehead"><span>Prize pool</span><b>${money(t.pool)}</b></div>
          <div class="hint prizesub">${t.rebuys} ${t.rebuys === 1 ? 'rebuy' : 'rebuys'}${t.addons ? `, ${t.addons} ${t.addons === 1 ? 'add-on' : 'add-ons'}` : ''}</div>
          <div class="prizerows">${t.payouts.map((p) => `<div class="prizerow"><span>${ordinal(p.place)}${p.name ? ` ${esc(p.name)}` : ''}</span><b>${money(p.amount)}</b></div>`).join('')}</div>
          ${t.highHandEnabled ? `<div class="hhrow"><span>${t.highHand ? `<b>High hand:</b> ${highHandText(t.highHand)}` : `<b>High hand:</b> none yet, pays ${money(t.highHandPayout)}`}</span><button class="btn small" data-do="highHand">${t.highHand ? 'Change' : 'Set'}</button></div>` : ''}
        </section>
      </aside>
    </main>`;
  }

  function finishedPage(t) {
    const winner = t.entries.find((e) => e.place === 1);
    const seasonRows = S.view.standings.slice(0, 12);
    const results = t.entries.slice().sort((a, b) => a.place - b.place);
    const payFor = (place) => (t.payouts.find((p) => p.place === place) || {}).amount;
    return `<main class="page" data-scroll="finished">
      <div class="done">
        <div class="bigwin"><div><div class="w">${esc(winner ? winner.name : '')} wins</div><div>${esc(t.name)}, ${money(t.pool)} prize pool</div></div>
          <div class="ml"><button class="btn ghost" data-do="share" data-id="${esc(t.id)}">Share results</button><button class="btn ghost" data-do="undo" ${t.undoLabel ? '' : 'disabled'}>${t.undoLabel ? 'Undo the last knockout' : 'Nothing to undo'}</button><button class="btn huge" data-do="closeNight">Save and finish the night</button></div></div>
        <section class="panel"><h2>Tonight’s results</h2>
          <table class="grid"><thead><tr><th>Place</th><th>Player</th><th class="r">Knockouts</th><th class="r">Rebuys</th><th class="r">Paid</th></tr></thead>
          <tbody>${results.map((e) => `<tr><td>${ordinal(e.place)}</td><td class="nm">${esc(e.name)}</td><td class="r">${e.knockouts}</td><td class="r">${e.rebuys}</td><td class="r">${payFor(e.place) ? money(payFor(e.place)) : ''}</td></tr>`).join('')}</tbody></table>
          ${t.highHandEnabled ? `<div class="hhrow" style="margin-top:10px"><span>${t.highHand ? `<b>High hand:</b> ${highHandText(t.highHand)}` : '<b>High hand:</b> none recorded'}</span><button class="btn small" data-do="highHand">${t.highHand ? 'Change' : 'Set'}</button></div>` : ''}
        </section>
        <section class="panel"><h2>Season standings</h2>${standingsTable(seasonRows, true)}</section>
      </div>
    </main>`;
  }

  /* ---------- Dialogs ---------- */

  /* The night the high hand dialog is working on: tonight, or a past night. */
  function highHandNight() {
    if (modal.nightId) {
      const n = S.view.past.find((x) => x.id === modal.nightId);
      return n ? { payout: n.highHandPayout, highHand: n.highHand, players: n.results.map((r) => ({ playerId: r.playerId, name: r.name })) } : null;
    }
    const t = S.view.tournament;
    return t ? { payout: t.highHandPayout, highHand: t.highHand, players: t.entries.map((e) => ({ playerId: e.playerId, name: e.name })) } : null;
  }

  function highHandDialog() {
    const night = highHandNight();
    if (!night) return '';
    const v = modal.values;
    const players = night.players.slice().sort((a, b) => a.name.localeCompare(b.name));
    const spec = v.type ? Hands.TYPES[v.type] : null;
    const problem = !v.playerId ? 'Choose a player.' : Hands.validate(v.type, v.cards);
    const slots = spec ? spec.slots.map((slot) => `<div class="hhslot"><div class="hhlabel">${esc(slot.label)}${slot.optional ? ' <span class="hint">(if any)</span>' : ''}</div>
      <div class="rankrow">${(slot.ranks || Hands.RANKS).map((r) => {
    const on = v.cards[slot.key] === r;
    const ok = on || Hands.allowed(v.type, slot.key, r, v.cards);
    return `<button type="button" class="rank ${on ? 'on' : ''}" aria-pressed="${on}" aria-label="${esc(slot.label)} ${r}" data-do="hhCard" data-slot="${slot.key}" data-rank="${r}" ${ok ? '' : 'disabled'}>${r}</button>`;
  }).join('')}</div></div>`).join('') : '';
    const preview = !spec ? '' : Hands.validate(v.type, v.cards) ? '' : Hands.describe(v.type, v.cards);
    return `<form class="dialog hhdialog" data-form="highHand"><h2>High hand</h2>
      <div class="hhtop">
        <label class="f" for="hh-player">Player<select id="hh-player" name="playerId"><option value="">Choose a player</option>${players.map((e) => `<option value="${esc(e.playerId)}" ${v.playerId === e.playerId ? 'selected' : ''}>${esc(e.name)}</option>`).join('')}</select></label>
        <div class="hhpays"><span class="k">Pays</span><span class="v">${money(night.payout)}</span><span class="hint">${money(S.settings.highHandPerPlayer)} × ${night.players.length} players</span></div>
      </div>
      <div class="body">
        <div class="hhlabel">Hand</div>
        <div class="typegrid">${Object.entries(Hands.TYPES).map(([k, t]) => `<button type="button" class="handtype ${v.type === k ? 'on' : ''}" aria-pressed="${v.type === k}" data-do="hhType" data-type="${k}">${esc(t.label)}</button>`).join('')}</div>
        ${slots}
      </div>
      <div class="hhpreview">${preview ? esc(preview) : `<span class="hint">${esc(problem || '')}</span>`}</div>
      <div class="foot">${night.highHand ? '<button type="button" class="btn" data-do="highHandClear" style="margin-right:auto">Clear</button>' : ''}<button type="button" class="btn" data-do="closeModal">Cancel</button><button class="btn primary" ${problem ? 'disabled' : ''}>Save high hand</button></div></form>`;
  }

  function highHandText(hh) {
    if (!hh) return '';
    return `${esc(hh.name)}${hh.name && hh.hand ? ', ' : ''}${esc(hh.hand)}${hh.amount ? `, ${money(hh.amount)}` : ''}`;
  }

  function renderModal() {
    if (!modal) { modalEl.innerHTML = ''; return; }
    if (modal.kind === 'hh') {
      const open = modalEl.querySelector('form[data-form="highHand"]');
      if (open) {
        const data = new FormData(open);
        modal.values = { ...modal.values, playerId: data.get('playerId') };
      }
    }
    const t = S.view.tournament;
    let html = '';
    if (modal.kind === 'ko' && t) {
      const victim = t.entries.find((e) => e.playerId === modal.victimId);
      if (!victim) { modal = null; modalEl.innerHTML = ''; return; }
      if (modal.step === 'by') {
        const others = t.entries.filter((e) => e.status === 'in' && e.playerId !== modal.victimId).sort((a, b) => a.name.localeCompare(b.name));
        const picked = modal.byIds || [];
        html = modal.split ? `<div class="dialog"><h2>Who split the pot that knocked out ${esc(victim.name)}?</h2>
          <p class="hint">Click everyone who split it. Each player gets full knockout credit.</p>
          <div class="body"><div class="choicegrid">
            ${others.map((e) => `<button class="choice ${picked.includes(e.playerId) ? 'picked' : ''}" aria-pressed="${picked.includes(e.playerId)}" data-do="koToggle" data-id="${esc(e.playerId)}">${esc(e.name)}</button>`).join('')}
          </div></div>
          <div class="foot"><button class="btn" data-do="koSplit" data-on="" style="margin-right:auto">One player won it</button><button class="btn" data-do="closeModal">Cancel</button><button class="btn primary" data-do="koSplitDone" ${picked.length ? '' : 'disabled'}>Give credit to ${picked.length} ${picked.length === 1 ? 'player' : 'players'}</button></div></div>` : `<div class="dialog"><h2>Who knocked out ${esc(victim.name)}?</h2>
          <div class="body"><div class="choicegrid">
            ${others.map((e) => `<button class="choice" data-do="koBy" data-id="${esc(e.playerId)}">${esc(e.name)}</button>`).join('')}
            <button class="choice none" data-do="koBy" data-id="">No one gets credit</button>
          </div></div>
          <div class="foot">${others.length > 1 ? '<button class="btn" data-do="koSplit" data-on="1" style="margin-right:auto">Split pot: credit more than one</button>' : ''}<button class="btn" data-do="closeModal">Cancel</button></div></div>`;
      } else {
        const c = t.config.rebuy;
        html = `<div class="dialog narrow"><h2>Is ${esc(victim.name)} rebuying?</h2>
          <p class="hint">Rebuys are open through round ${c.lastRound}.</p>
          <div class="body"><div class="bigchoice">
            <button class="btn primary" data-do="koFinish" data-rebuy="1">Yes, rebuy<small>${money(c.cost)} for ${num(c.chips)} chips</small></button>
            <button class="btn danger" data-do="koFinish" data-rebuy="">No, they’re out<small>Finishes in ${ordinal(t.aliveCount)} place</small></button>
          </div></div>
          <div class="foot"><button class="btn" data-do="closeModal">Cancel</button></div></div>`;
      }
    } else if (modal.kind === 'hh') {
      html = highHandDialog();
    } else if (modal.kind === 'redraw' && t) {
      const rn = t.redrawNotice || {};
      const one = rn.tables === 1;
      html = `<div class="dialog wide"><h2>${one ? 'Seats redrawn' : 'Tables redrawn'}</h2>
        <p>${rn.players || ''} players left, so ${one ? 'all seats' : 'all tables'} were drawn again at random. The TV is showing the new ${one ? 'seats' : 'tables'}.${rn.pausedClock ? ' The clock is paused.' : ''}</p>
        <div class="body">${seatingHtml(t)}</div>
        <div class="foot"><button class="btn" data-do="undo" style="margin-right:auto">Undo the knockout</button><button class="btn primary" data-do="redrawDone">${rn.pausedClock ? 'Everyone’s seated: restart the clock' : 'Everyone’s seated: show the clock'}</button></div></div>`;
    } else if (modal.kind === 'blinds' && t) {
      html = blindsDialog(t);
    } else if (modal.kind === 'share') {
      html = `<div class="dialog wide sharebox"><h2>Share results</h2>
        <p class="hint" style="margin:0">Copy it, then paste it into a new email in Gmail or Outlook. The tables come along. Or save a PDF to attach or print.</p>
        <div class="body"><div class="recap">${modal.html}</div></div>
        <div class="foot"><button class="btn" data-do="closeModal">Close</button><button class="btn" data-do="recapPdf">Save as PDF</button><button class="btn primary" data-do="recapCopy">Copy for email</button></div></div>`;
    } else if (modal.kind === 'confirm') {
      html = `<div class="dialog narrow"><h2>${esc(modal.title)}</h2><p>${esc(modal.text)}</p>
        <div class="foot"><button class="btn" data-do="closeModal">${esc(modal.no || 'Cancel')}</button><button class="btn ${modal.danger ? 'danger' : 'primary'}" data-do="confirmYes">${esc(modal.yes)}</button></div></div>`;
    } else if (modal.kind === 'newSeason') {
      html = `<form class="dialog narrow" data-form="newSeason"><h2>Start a new season</h2>
        <p class="hint">The new season starts at zero and uses the same rules. Older seasons stay saved.</p>
        <label class="f" for="season-name">Season name<input id="season-name" name="name" autocomplete="off" required></label>
        <div class="foot" style="margin-top:14px"><button type="button" class="btn" data-do="closeModal">Cancel</button><button class="btn primary">Start the season</button></div></form>`;
    } else { modal = null; }
    modalEl.innerHTML = html ? `<div class="overlay">${html}</div>` : '';
  }

  function blindsDialog(t) {
    let round = 0;
    const locked = (i) => t.status === 'running' && i <= t.levelIndex;
    const rows = t.config.levels.map((l, i) => {
      if (l.kind === 'round') round++;
      const dis = locked(i) ? 'disabled' : '';
      const cell = (key) => `<td><input id="lv-${i}-${key}" type="number" min="0" value="${l[key]}" ${dis} data-set="level.set" data-index="${i}" data-key="${key}"></td>`;
      return `<tr>
        <td style="white-space:nowrap">${l.kind === 'round' ? `Round ${round}` : '<b>Break</b>'}${i === t.levelIndex && t.status === 'running' ? ' (now)' : ''}</td>
        ${l.kind === 'round' ? `${cell('sb')}${cell('bb')}${cell('ante')}` : '<td></td><td></td><td></td>'}
        ${cell('minutes')}
        <td class="r" style="white-space:nowrap">
          <button class="btn small" data-do="levelMove" data-i="${i}" data-d="-1" ${dis} aria-label="Move up">▲</button>
          <button class="btn small" data-do="levelMove" data-i="${i}" data-d="1" ${dis} aria-label="Move down">▼</button>
          <button class="btn small" data-do="levelRemove" data-i="${i}" ${dis}>Remove</button>
        </td></tr>`;
    }).join('');
    return `<div class="dialog wide"><h2>Rounds and breaks</h2>
      <div class="row hint">Changes save right away and carry over to your next night.
        <span style="margin-left:auto" class="row"><label for="all-min">Set all rounds to</label><input id="all-min" type="number" min="1" style="width:70px;padding:5px;border:1px solid #a9b8b1;border-radius:6px" data-set="level.setAllMinutes" data-field="minutes" data-num="1"> minutes</span></div>
      <div class="body" data-scroll="blinds"><table class="grid"><thead><tr><th></th><th>Small blind</th><th>Big blind</th><th>Ante</th><th>Minutes</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
      <div class="foot"><button class="btn" data-do="levelAdd" data-kind="round">Add a round</button><button class="btn" data-do="levelAdd" data-kind="break">Add a break</button><button class="btn primary" data-do="closeModal">Done</button></div></div>`;
  }

  /* ---------- Standings ---------- */

  function standingsTable(rows, compact) {
    if (!rows.length) return '<p class="hint">No results yet. The table fills in as soon as a night starts.</p>';
    const showTonight = S.view.tournament && S.view.tournament.status !== 'setup';
    return `<table class="grid"><thead><tr><th class="r"></th><th>Player</th><th class="r">Points</th>${showTonight ? '<th class="r">Tonight</th>' : ''}<th class="r">KOs</th>${compact ? '' : '<th class="r">Nights</th><th class="r">Wins</th><th class="r">Best</th><th class="r">Won</th>'}</tr></thead>
      <tbody>${rows.map((r) => {
    const mv = r.movement ? (r.movement > 0 ? `<span class="mv">▲${r.movement}</span>` : `<span class="mv down">▼${-r.movement}</span>`) : '';
    return `<tr><td class="r">${r.rank}</td><td class="nm">${esc(r.name)}${mv}</td><td class="r"><b>${num(r.points)}</b></td>${showTonight ? `<td class="r">${r.tonight && r.tonight.points ? `+${num(r.tonight.points)}` : ''}</td>` : ''}<td class="r">${r.kos}</td>${compact ? '' : `<td class="r">${r.nights}</td><td class="r">${r.wins}</td><td class="r">${r.best ? ordinal(r.best) : ''}</td><td class="r">${r.won ? money(r.won) : ''}</td>`}</tr>`;
  }).join('')}</tbody></table>`;
  }

  function chartEditor(r) {
    const sizes = Object.keys(r.pointChart).map(Number).sort((a, b) => a - b);
    const col = r.pointChart[chartN] || r.pointChart[sizes[0]];
    return `<div style="margin-top:12px">
      <label class="f" for="chart-n" style="max-width:190px">Show points for this many players<select id="chart-n" data-local="chart">${sizes.map((n) => `<option value="${n}" ${n === chartN ? 'selected' : ''}>${n} players</option>`).join('')}</select></label>
      <div class="finishgrid" style="margin-top:8px">${col.map((v, i) => `<label for="cp-${chartN}-${i}">${ordinal(i + 1)}<input id="cp-${chartN}-${i}" type="number" min="0" value="${v}" data-set="season.setChartPoint" data-players="${chartN}" data-place="${i + 1}"></label>`).join('')}</div>
    </div>`;
  }

  function standingsPage() {
    const season = S.view.season;
    const r = season.rules;
    const active = S.players.filter((p) => p.active);
    const carry = season.carry || {};
    return `<main class="page" data-scroll="standings"><div class="twocol">
      <section class="panel">
        <div class="row" style="justify-content:space-between;margin-bottom:10px"><h2 style="font-size:18px">${esc(season.name)}</h2>
          <div class="row"><button class="btn small" data-do="exportExcel">Save to Excel</button><button class="btn small" data-do="showStandingsOnTv">Show on TV</button></div></div>
        ${standingsTable(S.view.standings)}
        
      </section>
      <div class="stack">
        <section class="panel"><h2>How points work</h2>
          <p class="hint" style="margin-top:0">Rule changes apply to the whole season, including nights already played.</p>
          <div class="fields">
            ${field('Points per knockout', 'season.set', 'rules.pointsPerKnockout', r.pointsPerKnockout)}
            ${field('Points for showing up', 'season.set', 'rules.attendancePoints', r.attendancePoints)}
            ${select('Finish points', 'season.set', 'rules.finishMode', r.finishMode, [['chart', 'League chart by player count'], ['table', 'Set points per place'], ['field', 'Points per player beaten']])}
            ${r.finishMode === 'field' ? field('Points per place from last', 'season.set', 'rules.fieldMultiplier', r.fieldMultiplier) : ''}
          </div>
          ${r.finishMode === 'chart' ? chartEditor(r) : ''}
          ${r.finishMode === 'table' ? `<div style="margin-top:12px"><div class="row" style="justify-content:space-between;margin-bottom:6px"><b style="font-size:14px">Points by finishing place</b><div class="row"><button class="btn small" data-do="finishAdd">Add a place</button><button class="btn small" data-do="finishRemove">Remove last</button></div></div>
            <div class="finishgrid">${r.finishTable.map((v, i) => `<label for="fp-${i}">${ordinal(i + 1)}<input id="fp-${i}" type="number" min="0" value="${v}" data-set="season.setFinishTable" data-place="${i + 1}"></label>`).join('')}</div></div>` : ''}
          <div class="fields" style="margin-top:12px">
            ${field('Worst nights to drop', 'season.set', 'rules.dropWorst', r.dropWorst, { step: 1 })}
            ${select('Break ties by', 'season.set', 'rules.tieBreak', r.tieBreak, [['knockouts', 'Most knockouts'], ['wins', 'Most wins'], ['nights', 'Most nights played']])}
          </div>
          <div style="margin-top:12px">${check('A knockout counts even if the player rebuys', 'season.set', 'rules.rebuyKnockoutsCount', r.rebuyKnockoutsCount)}</div>
        </section>
        <section class="panel"><h2>Season details</h2>
          <div class="fields">
            ${field('Season name', 'season.set', 'name', season.name, { type: 'text' })}
            ${field('Starts', 'season.set', 'startDate', season.startDate, { type: 'date' })}
            ${field('Ends', 'season.set', 'endDate', season.endDate, { type: 'date' })}
            ${field('Adjust the TOC pot ($)', 'season.set', 'potAdjust', season.potAdjust || 0, { min: -1000000 })}
          </div>
          <p class="hint">TOC pot now: ${money(S.view.seasonPot)}. Use the adjustment for money from before this app, prizes or expenses. Enter expenses as a negative number.</p>
          <div class="row" style="margin-top:12px">
            ${S.seasons.length > 1 ? `<select id="season-pick" data-set="season.activate" data-field="id" aria-label="Choose a season" style="padding:8px;border:1px solid #a9b8b1;border-radius:6px">${S.seasons.map((s) => `<option value="${esc(s.id)}" ${s.id === S.activeSeasonId ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>` : ''}
            <button class="btn small" data-do="newSeason">Start a new season</button>
          </div>
        </section>
        <section class="panel"><h2>Starting totals</h2>
          <p class="hint" style="margin-top:0">Use these to bring in results from before Poker Night was used. Nights played sets the TOC entry fee.</p>
          ${active.length ? `<table class="grid"><thead><tr><th>Player</th><th>Points</th><th>Knockouts</th><th>Nights</th></tr></thead><tbody>${active.map((p) => {
    const c = carry[p.id] || {};
    return `<tr><td class="nm">${esc(p.name)}</td><td><input class="tiny" id="cp-${esc(p.id)}" type="number" min="0" value="${c.points || 0}" data-set="season.setCarry" data-player-id="${esc(p.id)}" data-field="points"></td><td><input class="tiny" id="ck-${esc(p.id)}" type="number" min="0" value="${c.knockouts || 0}" data-set="season.setCarry" data-player-id="${esc(p.id)}" data-field="knockouts"></td><td><input class="tiny" id="cn-${esc(p.id)}" type="number" min="0" value="${c.nights || 0}" data-set="season.setCarry" data-player-id="${esc(p.id)}" data-field="nights"></td></tr>`;
  }).join('')}</tbody></table>` : '<p class="hint">Add players first.</p>'}
        </section>
      </div>
    </div></main>`;
  }

  /* ---------- Players ---------- */

  function playersPage() {
    const active = S.players.filter((p) => p.active);
    const inactive = S.players.filter((p) => !p.active);
    return `<main class="page" data-scroll="players"><div style="max-width:760px" class="stack">
      <section class="panel"><h2>Players (${active.length})</h2>
        <form class="addline" style="margin:0 0 12px" data-form="addPlayer"><input id="add-player" name="name" placeholder="New player’s name" autocomplete="off"><button class="btn primary">Add player</button></form>
        ${active.length ? `<table class="grid"><tbody>${active.map((p) => `<tr><td><input id="pn-${esc(p.id)}" type="text" value="${esc(p.name)}" aria-label="Name" data-set="player.rename" data-id="${esc(p.id)}" data-field="name"></td><td class="r"><button class="btn small" data-do="playerHide" data-id="${esc(p.id)}">Remove from list</button></td></tr>`).join('')}</tbody></table>` : '<p class="hint">Add everyone who plays. You’ll only need to do this once.</p>'}
        <p class="hint">Removing a player only hides them from check-in. Their season results stay.</p>
      </section>
      ${inactive.length ? `<section class="panel"><h2>Removed players</h2><table class="grid"><tbody>${inactive.map((p) => `<tr><td class="nm">${esc(p.name)}</td><td class="r"><button class="btn small" data-do="playerShow" data-id="${esc(p.id)}">Bring back</button></td></tr>`).join('')}</tbody></table></section>` : ''}
    </div></main>`;
  }

  /* ---------- Past nights ---------- */

  function pastPage() {
    const list = S.view.past.filter((n) => n.status === 'closed');
    if (!list.length) return '<main class="page"><div class="panel empty"><h2>No past nights yet</h2><p>Finished nights appear here. You can correct results if something was entered wrong.</p></div></main>';
    return `<main class="page" data-scroll="past"><div style="max-width:980px">
      <div class="row" style="justify-content:space-between;margin-bottom:12px"><p class="hint" style="margin:0">Open a night to correct it or share its results.</p><button class="btn small" data-do="exportExcel">Save every night to Excel</button></div>
      ${list.map((n) => `<details class="panel nightcard" ${openNights.has(n.id) ? 'open' : ''} data-night="${esc(n.id)}">
        <summary><span>${esc(n.name)}</span><span class="hint">${esc(n.monthOnly ? new Date(`${n.date}T12:00:00`).getFullYear() : dateText(n.date))}</span><span>Winner: ${esc(n.winner || 'none')}</span>${n.highHandEnabled ? `<span class="hhsum">${n.highHand ? `High hand: ${highHandText(n.highHand)}` : 'High hand: not recorded'}</span>` : ''}<span class="ml">${esc(n.seasonName)}, ${money(n.pool)} prize pool${n.importedRebuys !== undefined ? `, ${n.importedRebuys} rebuys` : ''}${n.countsTowardSeason ? '' : ', not counted'}</span></summary>
        ${n.highHandEnabled ? `<div class="hhrow" style="margin-top:12px"><span><b>High hand:</b> ${n.highHand ? highHandText(n.highHand) : 'not recorded'}</span><button class="btn small" data-do="highHand" data-id="${esc(n.id)}">${n.highHand ? 'Change' : 'Add'}</button></div>` : ''}
        <table class="grid" style="margin-top:12px"><thead><tr><th>Place</th><th>Player</th><th>Knockouts</th><th class="r">Rebuys</th><th class="r">Points</th><th class="r">Paid</th></tr></thead>
        <tbody>${n.results.map((r) => `<tr>
          <td><input class="tiny" id="pp-${esc(n.id)}-${esc(r.playerId)}" type="number" min="1" value="${r.place || ''}" aria-label="Place for ${esc(r.name)}" data-set="past.setEntry" data-id="${esc(n.id)}" data-player-id="${esc(r.playerId)}" data-field="place"></td>
          <td class="nm">${esc(r.name)}</td>
          <td><input class="tiny" id="pk-${esc(n.id)}-${esc(r.playerId)}" type="number" min="0" value="${r.knockouts}" aria-label="Knockouts for ${esc(r.name)}" data-set="past.setEntry" data-id="${esc(n.id)}" data-player-id="${esc(r.playerId)}" data-field="knockouts"></td>
          <td class="r">${r.rebuys === null ? '' : r.rebuys}</td><td class="r"><b>${num(r.points)}</b></td><td class="r">${r.paid ? money(r.paid) : ''}</td></tr>`).join('')}</tbody></table>
        <div class="row" style="margin-top:12px;justify-content:space-between">
          <label class="check" for="pc-${esc(n.id)}"><input id="pc-${esc(n.id)}" type="checkbox" ${n.countsTowardSeason ? 'checked' : ''} data-set="past.setCounts" data-id="${esc(n.id)}" data-field="on">Count toward the season standings</label>
          <div class="row"><button class="btn small primary" data-do="share" data-id="${esc(n.id)}">Share results</button><button class="btn small" data-do="askDeleteNight" data-id="${esc(n.id)}">Delete this night</button></div>
        </div>
      </details>`).join('')}
    </div></main>`;
  }

  /* ---------- Settings ---------- */

  function settingsPage() {
    const st = S.settings;
    const tv = S.tv;
    return `<main class="page" data-scroll="settings"><div class="twocol">
      <div class="stack">
        <section class="panel"><h2>League</h2><div class="fields">${field('League name', 'settings.set', 'leagueName', st.leagueName, { type: 'text' })}</div></section>
        ${ipadPanel()}
        <section class="panel"><h2>TV</h2>
          <div class="fields">
            ${select('While the clock is running', 'settings.set', 'tv.duringPlay', st.tv.duringPlay === 'alternate' ? 'alternate' : 'clock', [['clock', 'Show the clock'], ['alternate', 'Switch between clock and standings']])}
            ${st.tv.duringPlay === 'alternate' ? field('Seconds on each', 'settings.set', 'tv.alternateSeconds', st.tv.alternateSeconds, { min: 5, step: 1 }) : ''}
          </div>
          ${REMOTE ? '' : tv.displays.length ? `<div class="row" style="margin-top:12px">${tv.displays.map((d) => `<button class="btn small" data-do="tvOpenScreen" data-id="${d.id}">Show on ${esc(d.label)}</button>`).join('')}</div>` : `<p class="hint">No second screen is connected. Connect the TV, ${S.platform === 'darwin' ? 'open Displays in System Settings, and set the TV to Extended display' : 'press the Windows key and P, then choose Extend'}. Poker Night will fill the TV automatically.</p>`}
        </section>
        <section class="panel"><h2>Tables</h2>
          <div class="stack" style="gap:8px">
            ${check('Pause the clock during a table redraw', 'settings.set', 'tables.pauseOnRedraw', st.tables.pauseOnRedraw !== false)}
            ${check('Redraw seats at random when moving to one table', 'settings.set', 'tables.redrawAtOne', !!st.tables.redrawAtOne)}
          </div>
          <p class="hint" style="margin-bottom:0">When the second one is off, only the players who need to move are listed.</p>
        </section>
        <section class="panel"><h2>High hand</h2>
          <div class="fields">${field('Payout per player ($)', 'settings.set', 'highHandPerPlayer', st.highHandPerPlayer)}</div>
          <p class="hint">This is part of each player’s buy-in and stays out of the prize pool and TOC pot.</p>
          ${check('Include a high hand in the Tournament of Champions', 'settings.set', 'highHandInToc', !!st.highHandInToc)}
        </section>
        <section class="panel"><h2>Sounds</h2>
          <p class="hint" style="margin-top:0">${REMOTE ? 'These apply everywhere Poker Night is open. Turn sounds on or off for just this device under This device.' : 'Sounds play through the computer’s selected speakers, and on any iPad running the game.'}</p>
          ${REMOTE ? '' : check('Play sounds on this computer', 'local', 'soundsHere', soundsHere())}
          <div class="stack" style="gap:8px">
            ${check('Horn when a round ends', 'settings.set', 'sounds.roundEnd', st.sounds.roundEnd)}
            ${check('Beep with one minute left', 'settings.set', 'sounds.oneMinute', st.sounds.oneMinute)}
            ${check('Read the new blinds aloud', 'settings.set', 'sounds.voice', st.sounds.voice)}
          </div>
          <div class="fields" style="margin-top:10px">${field('Volume (0 to 100)', 'settings.set', 'sounds.volume', st.sounds.volume, { step: 5 })}</div>
          <div class="row" style="margin-top:10px"><button class="btn small" data-do="testSound" data-s="horn">Test horn</button><button class="btn small" data-do="testSound" data-s="beep">Test beep</button><button class="btn small" data-do="testSound" data-s="voice">Test voice</button></div>
        </section>
      </div>
      <div class="stack">
        <section class="panel"><h2>Payouts</h2>
          <p class="hint" style="margin-top:0">The amounts grow with every rebuy. Each row applies from that count up, and percents go in place order. When rounding leaves a few dollars over, they aren’t paid out.</p>
          <div class="fields" style="margin-bottom:10px">${select('Choose the row using', 'settings.set', 'payout.basis', st.payout.basis || 'players', [['players', 'Number of players'], ['buyins', 'Players plus rebuys']])}</div>
          <table class="grid"><thead><tr><th style="width:130px">${st.payout.basis === 'buyins' ? 'From this many buy-ins' : 'From this many players'}</th><th>Percents (1st, 2nd, 3rd…)</th><th></th></tr></thead>
          <tbody>${st.payout.brackets.map((b, i) => `<tr><td><input id="pb-m-${i}" type="number" min="1" value="${b.minPlayers}" aria-label="From this many players" data-set="payout.setBracket" data-index="${i}" data-field="minPlayers"></td><td><input id="pb-s-${i}" type="text" value="${esc(b.splits.join(', '))}" aria-label="Percents" data-set="payout.setBracket" data-index="${i}" data-field="splits"></td><td class="r"><button class="btn small" data-do="payoutRemove" data-i="${i}">Remove</button></td></tr>`).join('')}</tbody></table>
          <div class="row" style="margin-top:10px;justify-content:space-between"><button class="btn small" data-do="payoutAdd">Add a row</button>
          ${select('Round payouts to the nearest', 'settings.set', 'payout.roundTo', st.payout.roundTo, [[1, '$1'], [5, '$5'], [10, '$10'], [0.01, 'Exact cents']])}</div>
        </section>
        <section class="panel"><h2>Tournament of Champions</h2>
          <div class="fields">
            <label class="f" for="toc8" style="grid-column:1/-1">TOC8 payout (the default, percents)<input id="toc8" type="text" value="${esc(st.toc.toc8.join(', '))}" data-set="toc.setSplits" data-which="toc8"></label>
            <label class="f" for="toc6" style="grid-column:1/-1">TOC6 payout (percents)<input id="toc6" type="text" value="${esc(st.toc.toc6.join(', '))}" data-set="toc.setSplits" data-which="toc6"></label>
            ${field('Nights needed to qualify', 'settings.set', 'toc.minNights', st.toc.minNights, { step: 1 })}
            ${field('Use TOC6 at this many players or fewer', 'settings.set', 'toc.toc6MaxPlayers', st.toc.toc6MaxPlayers, { step: 1 })}
            ${field('Base chips', 'settings.set', 'toc.baseChips', st.toc.baseChips)}
            ${field('Extra chips per season point', 'settings.set', 'toc.chipsPerPoint', st.toc.chipsPerPoint)}
            ${field('Rebuy cost ($)', 'settings.set', 'toc.rebuyCost', st.toc.rebuyCost)}
            ${field('Rebuy chips', 'settings.set', 'toc.rebuyChips', st.toc.rebuyChips)}
            ${select('Round TOC payouts to the nearest', 'settings.set', 'toc.roundTo', st.toc.roundTo, [[0.01, 'Exact cents'], [1, '$1'], [5, '$5']])}
          </div>
          <table class="grid" style="margin-top:10px"><thead><tr><th>Nights played, at least</th><th>Entry fee ($)</th></tr></thead><tbody>${st.toc.fees.map((f, i) => `<tr><td><input id="tf-n-${i}" type="number" min="0" value="${f.minNights}" aria-label="Nights played" data-set="toc.setFee" data-index="${i}" data-field="minNights"></td><td><input id="tf-f-${i}" type="number" min="0" value="${f.fee}" aria-label="Entry fee" data-set="toc.setFee" data-index="${i}" data-field="fee"></td></tr>`).join('')}</tbody></table>
        </section>
        <section class="panel"><h2>Your data</h2>
          ${REMOTE ? `<p class="hint" style="margin-top:0">Everything is saved on the computer running Poker Night, with automatic daily backups. You can download a copy here. Restoring a backup is done on the computer.</p>
          <div class="row"><button class="btn small" data-do="backupNow">Download a backup</button></div>` : `<p class="hint" style="margin-top:0">Everything saves by itself to ${esc(S.dataDir)}, with automatic daily backups.</p>
          <div class="row"><button class="btn small" data-do="backupNow">Save a backup</button><button class="btn small" data-do="askRestore">Restore a backup</button><button class="btn small" data-do="openDataFolder">Open the data folder</button></div>`}
        </section>
        ${updatePanel()}
        <div class="row"><button class="btn small" data-do="openGuide">Open the guide</button><span class="hint">Poker Night version ${esc(S.version)}</span></div>
      </div>
    </div></main>`;
  }

  /* ---------- Drawing ---------- */

  function render() {
    if (!S) return;
    const active = document.activeElement;
    const focusId = active && active.id ? active.id : null;
    const focusVal = focusId && (active.tagName === 'INPUT') && active.type !== 'checkbox' ? active.value : null;
    let selStart = null;
    try { selStart = focusVal !== null ? active.selectionStart : null; } catch (_) { selStart = null; }
    document.querySelectorAll('[data-scroll]').forEach((el) => { scrollMemo[el.dataset.scroll] = el.scrollTop; });

    const pages = { game: gamePage, standings: standingsPage, players: playersPage, past: pastPage, settings: settingsPage };
    app.innerHTML = topbar() + pages[tab]();
    const liveT = S.view.tournament;
    if (liveT && liveT.status === 'running' && liveT.redrawNotice) { if (!modal || modal.kind !== 'redraw') modal = { kind: 'redraw' }; } else if (modal && modal.kind === 'redraw') modal = null;
    renderModal();

    document.querySelectorAll('[data-scroll]').forEach((el) => { if (scrollMemo[el.dataset.scroll]) el.scrollTop = scrollMemo[el.dataset.scroll]; });
    if (focusId) {
      const again = document.getElementById(focusId);
      if (again) {
        again.focus();
        if (focusVal !== null && again.value !== focusVal) again.value = focusVal;
        try { if (selStart !== null) again.setSelectionRange(selStart, selStart); } catch (_) { /* number inputs have no selection */ }
      }
    }
    updateClock();
  }

  function updateClock() {
    const t = S && S.view.tournament;
    if (!t || t.status !== 'running') return;
    const el = app.querySelector('[data-time]');
    if (!el) return;
    const ms = remaining(t.clock);
    const text = clockText(ms);
    if (el.textContent !== text) el.textContent = text;
    el.classList.toggle('lastminute', ms <= 60000 && t.clock.running);
    el.classList.toggle('isPaused', !t.clock.running);
    const when = app.querySelector('[data-when]');
    if (when) when.textContent = t.nextLevel && t.clock.running ? ` at ${timeAt(ms)}` : '';
    const brk = app.querySelector('[data-break]');
    if (brk) brk.textContent = t.level.kind === 'break' ? '' : t.msAfterCurrentToBreak === null ? 'No more breaks' : `Next break ${clockText(ms + t.msAfterCurrentToBreak)}`;
  }

  /* ---------- Sounds, made on the fly so there are no audio files to lose ---------- */

  let audio = null;
  function tone(freqs, duration, type, peak) {
    audio = audio || new AudioContext();
    if (audio.state === 'suspended') audio.resume();
    const vol = Math.min(1, Math.max(0, (S.settings.sounds.volume || 0) / 100)) * peak;
    const start = audio.currentTime + 0.02;
    const gain = audio.createGain();
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(Math.max(vol, 0.0002), start + 0.05);
    gain.gain.setValueAtTime(Math.max(vol, 0.0002), start + Math.max(0.06, duration - 0.15));
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    gain.connect(audio.destination);
    freqs.forEach((f) => {
      const o = audio.createOscillator();
      o.type = type;
      o.frequency.value = f;
      o.connect(gain);
      o.start(start);
      o.stop(start + duration + 0.05);
    });
  }
  const sounds = {
    horn() { tone([196, 247, 294], 1.5, 'sawtooth', 0.28); },
    beep() { tone([880], 0.28, 'sine', 0.5); setTimeout(() => tone([880], 0.28, 'sine', 0.5), 380); },
    voice(text = 'Round 3. Blinds are 100 and 200.') {
      if (!window.speechSynthesis) return;
      const u = new SpeechSynthesisUtterance(text);
      u.volume = Math.min(1, (S.settings.sounds.volume || 0) / 100);
      window.speechSynthesis.cancel();
      window.speechSynthesis.speak(u);
    },
  };

  function handleEvents(events) {
    const snd = S && soundsHere() ? S.settings.sounds : {};
    events.forEach((e) => {
      if (e.type === 'level' && !e.silent) {
        if (snd.roundEnd) sounds.horn();
        if (snd.voice && e.level) {
          const text = e.level.kind === 'break' ? `Break. ${e.level.minutes} minutes.` : `Round ${e.level.round}. Blinds are ${e.level.sb} and ${e.level.bb}.${e.level.ante ? ` Ante ${e.level.ante}.` : ''}`;
          setTimeout(() => sounds.voice(text), snd.roundEnd ? 1600 : 0);
        }
      } else if (e.type === 'oneMinute' && snd.oneMinute) {
        sounds.beep();
      } else if (e.type === 'knockout') {
        if (e.rebought) toast(`${e.victim} rebought.${e.by ? ` Knockout for ${e.by}.` : ''}`);
        else toast(`${e.victim} finished ${e.placeLabel}.${e.by ? ` Knockout for ${e.by}.` : ''}`);
      } else if (e.type === 'undo') {
        toast(`Undone: ${e.label}.`);
      } else if (e.type === 'highHand') {
        toast(`High hand: ${e.name}, ${e.hand}.`);
      } else if (e.type === 'rebuysClosed') {
        toast('Rebuys are now closed.');
      } else if (e.type === 'saveError') {
        toast(e.message, true);
      }
    });
  }

  /* ---------- Clicks ---------- */

  const handlers = {
    tab: (d) => { tab = d.tab; render(); },
    sideTab: (d) => { sideTab = d.tab; render(); },
    dismissNotice: () => command('dismissNotice'),
    tvClose: () => command('tvClose'),
    tvOpenWindow: () => command('tvOpenWindow'),
    tvOpenScreen: (d) => command('tvOpenScreen', d.id ? Number(d.id) : (S.tv.displays[0] && S.tv.displays[0].id)),
    newNight: () => act('t.new'),
    newToc: () => act('t.new', { kind: 'toc' }),
    checkQualified: () => act('t.checkAll', { on: true, qualified: true }),
    tocCheck: (d) => act('t.checkin', { playerId: d.id, on: !!d.on }),
    start: () => act('t.start'),
    closeNight: async () => { await act('t.close'); toast('Night saved to the season.'); },
    checkin: (d) => act('t.checkin', { playerId: d.id, on: !!d.on }),
    checkAll: (d) => act('t.checkAll', { on: !!d.on }),
    drawSeats: () => {
      const t = S.view.tournament;
      if (t.status === 'running' && t.seated) { confirmBox({ title: 'Draw seats again?', text: 'Everyone still in will get a new table and seat.', yes: 'Draw again', run: () => act('t.drawSeats') }); return; }
      act('t.drawSeats');
    },
    clearSeats: () => act('t.clearSeats'),
    applyMove: (d) => act('t.applyMove', { playerId: d.id, to: Number(d.to) }),
    applyAllMoves: () => act('t.applyAllMoves'),
    clockToggle: () => act('clock.toggle'),
    clockNext: () => act('clock.next'),
    clockPrev: () => act('clock.prev'),
    clockAdd: (d) => act('clock.addTime', { seconds: Number(d.s) }),
    undo: () => act('t.undo'),
    rebuy: (d) => act('t.rebuy', { playerId: d.id }),
    addon: (d) => act('t.addon', { playerId: d.id }),
    ko: (d) => { modal = { kind: 'ko', step: 'by', victimId: d.id, byIds: [], split: false }; renderModal(); },
    koBy: (d) => { modal.byIds = d.id ? [d.id] : []; koNext(); },
    koSplit: (d) => { modal.split = !!d.on; modal.byIds = []; renderModal(); },
    koToggle: (d) => {
      modal.byIds = modal.byIds.includes(d.id) ? modal.byIds.filter((x) => x !== d.id) : [...modal.byIds, d.id];
      renderModal();
    },
    koSplitDone: () => koNext(),
    highHand: (d) => {
      modal = { kind: 'hh', nightId: d.id || null, values: {} };
      const hh = highHandNight().highHand;
      const parsed = hh && hh.type ? { type: hh.type, cards: hh.cards || {} } : Hands.parse(hh ? hh.hand : '');
      modal.values = { playerId: hh ? hh.playerId : '', type: parsed.type, cards: { ...parsed.cards } };
      renderModal();
    },
    hhType: (d) => { modal.values.type = d.type; modal.values.cards = {}; renderModal(); },
    hhCard: (d) => {
      const c = modal.values.cards;
      if (c[d.slot] === d.rank) delete c[d.slot];
      else {
        c[d.slot] = d.rank;
        // A new first card can make the others impossible, so they clear.
        const spec = Hands.TYPES[modal.values.type];
        spec.slots.forEach((slot) => { if (slot.key !== d.slot && c[slot.key] && !Hands.allowed(modal.values.type, slot.key, c[slot.key], c)) delete c[slot.key]; });
      }
      renderModal();
    },
    highHandClear: async () => {
      const id = modal.nightId;
      modal = null;
      renderModal();
      await act('highHand.set', { id, playerId: '', hand: '' });
    },
    redrawDone: () => act('t.dismissRedraw'),
    koFinish: (d) => finishKo(!!d.rebuy),
    closeModal: () => { modal = null; renderModal(); },
    confirmYes: async () => { const run = modal.run; modal = null; renderModal(); await run(); },
    openBlinds: () => { modal = { kind: 'blinds' }; renderModal(); },
    levelMove: (d) => act('level.move', { index: Number(d.i), delta: Number(d.d) }),
    levelRemove: (d) => act('level.remove', { index: Number(d.i) }),
    levelAdd: (d) => act('level.add', { kind: d.kind }),
    finishAdd: () => act('season.addFinishPlace'),
    finishRemove: () => act('season.removeFinishPlace'),
    payoutAdd: () => act('payout.addBracket'),
    payoutRemove: (d) => act('payout.removeBracket', { index: Number(d.i) }),
    playerHide: (d) => act('player.setActive', { id: d.id, active: false }),
    playerShow: (d) => act('player.setActive', { id: d.id, active: true }),
    exportCsv: () => command('exportCsv'),
    exportExcel: () => command('exportExcel'),
    updateCheck: () => command('updateCheck'),
    updateInstall: () => command('updateInstall'),
    openReleasePage: () => command('openReleasePage'),
    goSettings: () => { tab = 'settings'; render(); },
    updateRestart: () => {
      const t = S.view && S.view.tournament;
      if (t && t.status === 'running') {
        return confirmBox({ title: 'Restart during the game?', text: 'Everything is saved. The game comes back with the clock paused, so press Resume when you’re ready.', yes: 'Restart now', run: () => command('updateRestart') });
      }
      return command('updateRestart');
    },
    share: async (d) => {
      const res = await command('recap', d.id);
      if (!res.ok) return;
      modal = { kind: 'share', nightId: d.id, html: res.html };
      renderModal();
    },
    recapCopy: () => command('copyRecap', modal.nightId),
    recapPdf: () => command('saveRecapPdf', modal.nightId),
    backupNow: () => command('backupNow'),
    openDataFolder: () => command('openDataFolder'),
    openGuide: () => command('openGuide'),
    showStandingsOnTv: () => act('settings.set', { path: 'tv.scene', value: 'standings' }),
    newSeason: () => { modal = { kind: 'newSeason' }; renderModal(); document.getElementById('season-name').focus(); },
    remoteNewPin: () => confirmBox({ title: 'Make a new PIN?', text: 'Any iPad or phone running Poker Night will need to enter the new PIN.', yes: 'Make a new PIN', run: () => command('remoteNewPin') }),
    testSound: (d) => { if (d.s === 'voice') sounds.voice(); else sounds[d.s](); },
    askCancelNight: () => confirmBox({ title: 'Cancel this night?', text: 'This removes the night and any knockouts entered for it. Season points from it will be gone.', yes: 'Cancel the night', no: 'Keep it', danger: true, run: () => act('t.cancel') }),
    askDeleteNight: (d) => confirmBox({ title: 'Delete this night?', text: 'Its points will be removed from the season standings.', yes: 'Delete the night', danger: true, run: () => act('past.delete', { id: d.id }) }),
    askRestore: () => confirmBox({ title: 'Restore a backup?', text: 'This replaces what’s in Poker Night now with the backup you choose. A copy of the current data is saved first.', yes: 'Choose a backup', run: () => command('restore') }),
  };

  function confirmBox(opts) { modal = { kind: 'confirm', ...opts }; renderModal(); }

  function koNext() {
    const t = S.view.tournament;
    const victim = t.entries.find((e) => e.playerId === modal.victimId);
    if (victim && victim.canRebuy && t.aliveCount > 1) { modal.step = 'rebuy'; renderModal(); return; }
    finishKo(false);
  }

  async function finishKo(rebuy) {
    const { victimId, byIds } = modal;
    modal = null;
    renderModal();
    await act('t.knockout', { victimId, byIds, rebuy });
  }

  document.addEventListener('click', (ev) => {
    const el = ev.target.closest('[data-do]');
    if (!el || el.disabled) return;
    const fn = handlers[el.dataset.do];
    if (fn) fn(el.dataset);
  });

  /* ---------- Fields ---------- */

  document.addEventListener('change', async (ev) => {
    const el = ev.target;
    const d = el.dataset;
    if (d && d.local === 'chart') { chartN = Number(el.value); render(); return; }
    if (d && d.set === 'local' && d.path === 'soundsHere') { store.set('pn-sounds-here', el.checked ? 'on' : 'off'); return; }
    if (d && d.remote) { await command('remoteSet', el.checked); return; }
    if (d && d.updateAuto) { await command('updateAuto', el.checked); return; }
    if (!d || !d.set) return;
    let value;
    if (el.type === 'checkbox') value = el.checked;
    else if (el.type === 'number' || d.num) value = el.value === '' ? 0 : Number(el.value);
    else value = el.value;
    if (d.set === 'late') {
      if (value) await act('t.lateEntry', { playerId: value });
      return;
    }
    if (d.path === 'payout.roundTo' || d.path === 'toc.roundTo') value = Number(value);
    const payload = {};
    if (d.path) payload.path = d.path;
    if (d.index !== undefined) payload.index = Number(d.index);
    if (d.key) payload.key = d.key;
    if (d.place) payload.place = Number(d.place);
    if (d.id) payload.id = d.id;
    if (d.playerId) payload.playerId = d.playerId;
    if (d.which) payload.which = d.which;
    if (d.players) payload.players = Number(d.players);
    payload[d.field || 'value'] = value;
    const ok = await act(d.set, payload);
    if (!ok) render();
    if (d.set === 'level.setAllMinutes') el.value = '';
  });

  document.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const form = ev.target;
    const name = new FormData(form).get('name');
    if (form.dataset.form === 'addPlayer' || form.dataset.form === 'addPlayerCheck') {
      const input = form.querySelector('input');
      const id = input.id;
      const ok = await act('player.add', { name, checkIn: form.dataset.form === 'addPlayerCheck' });
      if (ok) { const next = document.getElementById(id); if (next) { next.value = ''; next.focus(); } }
    } else if (form.dataset.form === 'newSeason') {
      const ok = await act('season.new', { name });
      if (ok) { modal = null; renderModal(); }
    } else if (form.dataset.form === 'highHand') {
      const data = new FormData(form);
      const payload = { id: modal.nightId, playerId: data.get('playerId'), type: modal.values.type, cards: modal.values.cards };
      modal = null;
      renderModal();
      await act('highHand.set', payload);
    }
  });

  document.addEventListener('toggle', (ev) => {
    const el = ev.target;
    if (el.dataset && el.dataset.night) {
      if (el.open) openNights.add(el.dataset.night); else openNights.delete(el.dataset.night);
    }
  }, true);

  /* Space bar pauses and resumes; Esc closes a dialog. */
  document.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape' && modal) { modal = null; renderModal(); return; }
    if (ev.code !== 'Space' || modal) return;
    const tag = document.activeElement && document.activeElement.tagName;
    if (['INPUT', 'SELECT', 'TEXTAREA', 'BUTTON', 'SUMMARY'].includes(tag)) return;
    const t = S && S.view.tournament;
    if (t && t.status === 'running' && tab === 'game') { ev.preventDefault(); act('clock.toggle'); }
  });

  // Safari on an iPad only allows sound after the first tap, so get it ready then.
  document.addEventListener('pointerdown', function unlockSound() {
    document.removeEventListener('pointerdown', unlockSound, true);
    try {
      audio = audio || new AudioContext();
      if (audio.state === 'suspended') audio.resume();
      if (REMOTE && window.speechSynthesis) { const u = new SpeechSynthesisUtterance(' '); u.volume = 0; window.speechSynthesis.speak(u); }
    } catch (_) { /* no sound on this device */ }
  }, true);

  window.poker.onState((s) => { S = s; render(); });
  window.poker.onEvents(handleEvents);
  window.poker.getState().then((s) => { S = s; render(); });
  setInterval(updateClock, 200);
})();
