'use strict';
/* Poker hand types for the high hand picker. Used by both the game logic and the Dell screen. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.Hands = factory();
}(this, () => {
  const RANKS = ['A', 'K', 'Q', 'J', '10', '9', '8', '7', '6', '5', '4', '3', '2'];
  const value = (r) => RANKS.length - RANKS.indexOf(r);
  const plural = (r) => `${r}'s`;
  const withKicker = (text, c) => (c.kicker ? `${text}, ${c.kicker} kicker` : text);

  const TYPES = {
    royal: { label: 'Royal flush', slots: [], text: () => 'Royal flush' },
    sflush: {
      label: 'Straight flush',
      slots: [{ key: 'a', label: 'High card', ranks: RANKS.slice(1, 10), optional: true }],
      text: (c) => (c.a ? `Straight flush, ${c.a} high` : 'Straight flush'),
    },
    quads: {
      label: 'Quads',
      slots: [{ key: 'a', label: 'Which quads' }, { key: 'kicker', label: 'Kicker', optional: true }],
      text: (c) => withKicker(`Quad ${plural(c.a)}`, c),
    },
    full: {
      label: 'Full house',
      slots: [{ key: 'a', label: 'Three of a kind' }, { key: 'b', label: 'Pair' }],
      text: (c) => `Full house, ${plural(c.a)} over ${plural(c.b)}`,
    },
    flush: {
      label: 'Flush',
      slots: [{ key: 'a', label: 'High card', ranks: RANKS.slice(0, 9) }, { key: 'kicker', label: 'Next card', optional: true }],
      text: (c) => (c.kicker ? `Flush, ${c.a} high with ${c.kicker}` : `Flush, ${c.a} high`),
    },
    straight: {
      label: 'Straight',
      slots: [{ key: 'a', label: 'High card', ranks: RANKS.slice(0, 10) }],
      text: (c) => `Straight, ${c.a} high`,
    },
    trips: {
      label: 'Three of a kind',
      slots: [{ key: 'a', label: 'Which three' }, { key: 'kicker', label: 'Kicker', optional: true }],
      text: (c) => withKicker(`Three ${plural(c.a)}`, c),
    },
    twopair: {
      label: 'Two pair',
      slots: [{ key: 'a', label: 'High pair' }, { key: 'b', label: 'Low pair' }, { key: 'kicker', label: 'Kicker', optional: true }],
      text: (c) => withKicker(`Two pair, ${plural(c.a)} and ${plural(c.b)}`, c),
    },
    pair: {
      label: 'Pair',
      slots: [{ key: 'a', label: 'Which pair' }, { key: 'kicker', label: 'Kicker', optional: true }],
      text: (c) => withKicker(`Pair of ${plural(c.a)}`, c),
    },
    high: {
      label: 'High card',
      slots: [{ key: 'a', label: 'High card' }, { key: 'kicker', label: 'Next card', optional: true }],
      text: (c) => (c.kicker ? `${c.a} high with ${c.kicker}` : `${c.a} high`),
    },
  };

  /* A card that can't go in this slot given what's already picked, such as a kicker matching the quads. */
  function allowed(type, slotKey, rank, cards) {
    const c = cards || {};
    if (slotKey === 'a' || !c.a) return true;
    if (rank === c.a) return false;
    if (slotKey === 'kicker' && rank === c.b) return false;
    if (type === 'twopair' && slotKey === 'b') return value(rank) < value(c.a);
    if ((type === 'flush' || type === 'high') && slotKey === 'kicker') return value(rank) < value(c.a);
    return true;
  }

  function validate(type, cards) {
    const spec = TYPES[type];
    if (!spec) return 'Choose a hand type.';
    const c = cards || {};
    for (const slot of spec.slots) {
      const rank = c[slot.key];
      if (!rank) {
        if (!slot.optional) return `Choose: ${slot.label.toLowerCase()}.`;
      } else {
        if (!(slot.ranks || RANKS).includes(rank)) return `${rank} can’t be the ${slot.label.toLowerCase()}.`;
        if (!allowed(type, slot.key, rank, c)) return `${rank} can’t be the ${slot.label.toLowerCase()} with this hand.`;
      }
    }
    return null;
  }

  /* Hands from his spreadsheet are plain text; this finds the hand type for editing them later. */
  function parse(text) {
    const t = String(text || '').trim();
    const quad = t.match(/^quad (A|K|Q|J|10|[2-9])'?s?\b/i);
    if (quad) return { type: 'quads', cards: { a: quad[1].toUpperCase() } };
    if (/^royal/i.test(t)) return { type: 'royal', cards: {} };
    if (/^straight flush/i.test(t)) return { type: 'sflush', cards: {} };
    return { type: null, cards: {} };
  }

  return {
    RANKS,
    TYPES,
    allowed,
    validate,
    parse,
    describe: (type, cards) => TYPES[type].text(cards || {}),
  };
}));
