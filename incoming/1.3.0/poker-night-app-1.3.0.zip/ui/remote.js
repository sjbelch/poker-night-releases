'use strict';
/* Used when Poker Night runs in a web browser on an iPad or another device.
   It stands in for the connection the computer's own windows use, and talks to the computer over Wi-Fi. */
(() => {
  const isTv = location.pathname.replace(/\/+$/, '') === '/tv';
  const q = isTv ? '?tv=1' : '';
  const stateFns = [];
  const eventFns = [];
  let source = null;
  let retry = null;
  let lost = false;

  /* The clock counts from a time on the computer. If this device's clock is a little off, shift it. */
  function fix(s) {
    if (s && typeof s.serverNow === 'number') {
      const offset = Date.now() - s.serverNow;
      const t = s.view && s.view.tournament;
      if (t && t.clock && t.clock.anchor) t.clock.anchor += offset;
    }
    return s;
  }

  const LOST = 'Lost touch with the computer. Check that it’s on, Poker Night is open, and both are on the same Wi-Fi.';

  function bar(show) {
    let el = document.getElementById('linkbar');
    if (!el) {
      el = document.createElement('div');
      el.id = 'linkbar';
      el.setAttribute('role', 'status');
      el.style.cssText = 'position:fixed;left:50%;top:10px;transform:translateX(-50%);z-index:9999;background:#a3271f;color:#fff;font:600 16px -apple-system,"Segoe UI",sans-serif;padding:10px 18px;border-radius:999px;box-shadow:0 4px 18px #0006;display:none;max-width:92vw;text-align:center';
      el.textContent = 'Reconnecting to the computer…';
      document.body.appendChild(el);
    }
    el.style.display = show ? 'block' : 'none';
  }

  async function signedOut() {
    if (isTv) return false;
    try { const r = await fetch('/api/state', { credentials: 'same-origin', cache: 'no-store' }); if (r.status === 401) { location.href = '/'; return true; } } catch (_) { /* offline */ }
    return false;
  }

  function connect() {
    clearTimeout(retry);
    if (source) { try { source.close(); } catch (_) { /* gone */ } }
    source = new EventSource(`/api/stream${q}`);
    source.addEventListener('state', (e) => { if (lost) { lost = false; bar(false); } const s = fix(JSON.parse(e.data)); stateFns.forEach((f) => f(s)); });
    source.addEventListener('events', (e) => { const ev = JSON.parse(e.data); eventFns.forEach((f) => f(ev)); });
    source.onerror = async () => {
      lost = true;
      setTimeout(() => { if (lost) bar(true); }, 1500);
      if (await signedOut()) return;
      // Safari sometimes gives up for good after the iPad sleeps, so start over.
      if (source.readyState === 2) retry = setTimeout(connect, 2000);
    };
  }

  async function post(url, body) {
    try {
      const r = await fetch(url, { method: 'POST', credentials: 'same-origin', cache: 'no-store', headers: { 'Content-Type': 'application/json', 'X-Poker': '1' }, body: JSON.stringify(body) });
      if (r.status === 401) { location.href = '/'; return { ok: false, error: 'Enter the PIN again.' }; }
      return await r.json();
    } catch (_) {
      return { ok: false, error: LOST };
    }
  }

  window.poker = {
    remote: true,
    getState: () => fetch(`/api/state${q}`, { credentials: 'same-origin', cache: 'no-store' })
      .then((r) => { if (r.status === 401) { location.href = '/'; throw new Error('signed out'); } return r.json(); })
      .then(fix),
    act: (type, payload) => post('/api/act', { type, payload }),
    async command(name, arg) {
      const res = await post('/api/command', { name, arg });
      if (res.ok && res.download) {
        const a = document.createElement('a');
        a.href = res.download;
        a.download = '';
        document.body.appendChild(a);
        a.click();
        a.remove();
      }
      if (res.ok && res.open) window.open(res.open, '_blank');
      return res;
    },
    onState: (fn) => stateFns.push(fn),
    onEvents: (fn) => eventFns.push(fn),
  };

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && (!source || source.readyState === 2)) connect();
  });
  window.addEventListener('pageshow', (e) => { if (e.persisted) connect(); });
  connect();
})();
