'use strict';
/* Checks GitHub for a newer version, downloads it into its own folder, and asks for a restart.
   Each release posts latest.json, which names the version, what's new, and the app files with their checksum. */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { unzip } = require('./unzip.js');

const parts = (v) => String(v || '0').split('.').map((n) => parseInt(n, 10) || 0);
function compare(a, b) {
  const x = parts(a);
  const y = parts(b);
  for (let i = 0; i < 3; i += 1) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0);
  return 0;
}

function createUpdater({ fetch, currentVersion, electronVersion, updatesDir, repo, configFile, feedUrl, onChange, log = () => {} }) {
  const feed = feedUrl || `https://github.com/${repo}/releases/latest/download/latest.json`;
  let config = { auto: true };
  try { Object.assign(config, JSON.parse(fs.readFileSync(configFile, 'utf8'))); } catch (_) { /* first run */ }
  const state = { phase: 'idle', latest: null, error: null, checkedAt: null, progress: 0 };
  let timer = null;

  const set = (patch) => { Object.assign(state, patch); onChange(); };
  const saveConfig = () => { try { fs.writeFileSync(configFile, JSON.stringify(config)); } catch (_) { /* not fatal */ } };

  function readyVersion() {
    try {
      return fs.readdirSync(updatesDir)
        .filter((d) => fs.existsSync(path.join(updatesDir, d, '.complete')) && !fs.existsSync(path.join(updatesDir, d, '.failed')))
        .sort(compare).pop() || null;
    } catch (_) { return null; }
  }

  function status() {
    const ready = readyVersion();
    return {
      current: currentVersion,
      auto: config.auto,
      phase: ready && compare(ready, currentVersion) > 0 ? 'ready' : state.phase,
      readyVersion: ready && compare(ready, currentVersion) > 0 ? ready : null,
      latest: state.latest ? { version: state.latest.version, notes: state.latest.notes || [], date: state.latest.date || null, page: state.latest.page || `https://github.com/${repo}/releases/latest`, needsInstaller: !!state.latest.needsInstaller } : null,
      error: state.error,
      checkedAt: state.checkedAt,
      progress: state.progress,
    };
  }

  async function check({ quiet = false } = {}) {
    if (state.phase === 'checking' || state.phase === 'downloading') return status();
    set({ phase: 'checking', error: null });
    try {
      const res = await fetch(feed, { cache: 'no-store' });
      if (!res.ok) throw new Error(res.status === 404 ? 'No updates have been posted yet.' : `GitHub answered ${res.status}.`);
      const latest = await res.json();
      if (!latest || !latest.version || !latest.app || !latest.app.url || !/^[a-f0-9]{64}$/.test(latest.app.sha256 || '')) throw new Error('The update information didn’t make sense.');
      latest.needsInstaller = !!(latest.minElectron && compare(electronVersion, latest.minElectron) < 0);
      const newer = compare(latest.version, currentVersion) > 0;
      set({ phase: newer ? 'available' : 'current', latest, checkedAt: Date.now() });
    } catch (err) {
      log(err);
      set({ phase: quiet ? 'idle' : 'error', error: quiet ? null : `Couldn’t check for updates. ${/fetch|network|ENOTFOUND|ERR_/i.test(err.message) ? 'This computer may not be online.' : err.message}`, checkedAt: Date.now() });
    }
    return status();
  }

  async function download() {
    const latest = state.latest;
    if (!latest || compare(latest.version, currentVersion) <= 0) throw new Error('There’s no update to install.');
    if (latest.needsInstaller) throw new Error('This update needs the full installer. Use the download link instead.');
    if (!/^\d+\.\d+\.\d+$/.test(latest.version)) throw new Error('The update information didn’t make sense.');
    set({ phase: 'downloading', error: null, progress: 0 });
    const dir = path.join(updatesDir, latest.version);
    const tmp = `${dir}.tmp`;
    try {
      const res = await fetch(latest.app.url, { cache: 'no-store' });
      if (!res.ok) throw new Error(`The download failed (${res.status}).`);
      const buf = Buffer.from(await res.arrayBuffer());
      const sum = crypto.createHash('sha256').update(buf).digest('hex');
      if (sum !== latest.app.sha256) throw new Error('The download was damaged. Try again.');
      fs.rmSync(tmp, { recursive: true, force: true });
      fs.mkdirSync(tmp, { recursive: true });
      unzip(buf, tmp);
      const pkg = JSON.parse(fs.readFileSync(path.join(tmp, 'package.json'), 'utf8'));
      if (pkg.version !== latest.version || !fs.existsSync(path.join(tmp, 'main.js'))) throw new Error('The download wasn’t the right version.');
      fs.writeFileSync(path.join(tmp, '.complete'), sum);
      fs.rmSync(dir, { recursive: true, force: true });
      fs.renameSync(tmp, dir);
      cleanup(latest.version);
      set({ phase: 'ready', progress: 1 });
    } catch (err) {
      log(err);
      fs.rmSync(tmp, { recursive: true, force: true });
      set({ phase: 'available', error: err.message });
      throw err;
    }
    return status();
  }

  /* Keeps the newest download and the one running now, so there's always something to go back to. */
  function cleanup(keep) {
    try {
      fs.readdirSync(updatesDir).forEach((d) => {
        if (d === keep || d === currentVersion) return;
        fs.rmSync(path.join(updatesDir, d), { recursive: true, force: true });
      });
    } catch (_) { /* nothing to clean */ }
  }

  function start() {
    try { fs.mkdirSync(updatesDir, { recursive: true }); } catch (_) { /* checked later */ }
    if (!config.auto) return;
    setTimeout(() => check({ quiet: true }), 15000);
    timer = setInterval(() => check({ quiet: true }), 6 * 60 * 60 * 1000);
  }

  return {
    status,
    check,
    download,
    start,
    stop() { clearInterval(timer); },
    setAuto(on) { config.auto = !!on; saveConfig(); if (on && !timer) start(); if (!on) { clearInterval(timer); timer = null; } onChange(); },
  };
}

module.exports = { createUpdater, compare };
