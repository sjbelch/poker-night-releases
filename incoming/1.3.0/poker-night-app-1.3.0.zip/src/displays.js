'use strict';
/* Picks which screen is the TV: the one he chose if it's still connected,
   otherwise the largest screen that isn't the Dell's main screen. */
function chooseTvDisplay(displays, primaryId, preferredId) {
  const others = displays.filter((d) => d.id !== primaryId);
  if (!others.length) return null;
  const preferred = others.find((d) => d.id === preferredId);
  if (preferred) return preferred;
  return others.slice().sort((a, b) => (b.size.width * b.size.height) - (a.size.width * a.size.height))[0];
}
module.exports = { chooseTvDisplay };
