'use strict';
/* Results to load into a new league's first season. Empty for a new install; tests fill it with sample data. */
module.exports = { POT_ADJUST: 0, MONTHS: [] };
