'use strict';
/* Turns a night's results into an email-ready recap, and the season into Excel sheets. */

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

const esc = (s) => String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => {
  const v = Math.round((Number(n) || 0) * 100) / 100;
  return `$${v.toLocaleString('en-US', { minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 })}`;
};
const ordinal = (n) => {
  if (!n) return '';
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`;
};
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

function dateLong(r) {
  const d = new Date(`${r.date}T12:00:00`);
  if (Number.isNaN(d.getTime())) return '';
  if (r.monthOnly) return `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
  return d.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
}

function hhText(r) {
  const h = r.highHand;
  if (!h || (!h.name && !h.hand)) return 'none recorded';
  return [h.name, h.hand, h.amount ? money(h.amount) : ''].filter(Boolean).join(', ');
}

function summaryLine(r) {
  const bits = [plural(r.players, 'player', 'players')];
  if (r.rebuys) bits.push(plural(r.rebuys, 'rebuy', 'rebuys'));
  let line = `${bits.join(', ')}. Prize pool ${money(r.pool)}`;
  if (r.toToc) line += `, with ${money(r.toToc)} to the TOC pot`;
  return `${line}.`;
}

const isToc = (r) => r.kind === 'toc';
const standingsTitle = (r) => (isToc(r) ? 'Final season standings' : `Season standings after ${r.name}`);

/* ---------- Email recap ---------- */

const TH = 'text-align:left;padding:6px 10px;background:#e3ede7;border-bottom:1px solid #9fb0a8;font-size:13px;';
const TD = 'padding:5px 10px;border-bottom:1px solid #dfe6e2;font-size:14px;';
const R = 'text-align:right;';

function table(head, rows) {
  return `<table cellpadding="0" cellspacing="0" style="border-collapse:collapse;margin:0 0 14px;min-width:420px">
<thead><tr>${head.map(([label, right]) => `<th style="${TH}${right ? R : ''}">${esc(label)}</th>`).join('')}</tr></thead>
<tbody>${rows.map((row) => `<tr>${row.cells.map(([v, right]) => `<td style="${TD}${right ? R : ''}${row.bold ? 'font-weight:bold;' : ''}">${esc(v)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
}

function recapHtml(r) {
  const toc = isToc(r);
  const resultHead = toc
    ? [['Place'], ['Player'], ['Knockouts', true], ['Paid', true]]
    : [['Place'], ['Player'], ['Knockouts', true], ['Points', true], ['Paid', true]];
  const resultRows = r.results.map((x) => ({
    bold: x.place === 1,
    cells: toc
      ? [[ordinal(x.place)], [x.name], [x.knockouts, true], [x.paid ? money(x.paid) : '', true]]
      : [[ordinal(x.place)], [x.name], [x.knockouts, true], [x.points, true], [x.paid ? money(x.paid) : '', true]],
  }));
  const stRows = r.standings.map((x) => ({ cells: [[x.rank], [x.name], [x.points, true], [x.nights, true], [x.kos, true], [x.won ? money(x.won) : '', true]] }));
  return `<div style="font-family:Arial,Helvetica,sans-serif;color:#17231e;font-size:14px;line-height:1.45">
<div style="font-size:22px;font-weight:bold;color:#0d3d2f;margin:0">${esc(r.league)}: ${esc(r.name)} results</div>
<div style="color:#52625b;margin:2px 0 12px">${esc(dateLong(r))}</div>
<p style="margin:0 0 12px"><b>Winner: ${esc(r.winner || 'not recorded')}</b><br>${esc(summaryLine(r))}${r.countsTowardSeason || toc ? '' : '<br>This night doesn’t count toward the season standings.'}</p>
${table(resultHead, resultRows)}
${r.highHandEnabled ? `<p style="margin:0 0 18px"><b>High hand:</b> ${esc(hhText(r))}</p>` : ''}
<div style="font-size:17px;font-weight:bold;color:#0d3d2f;margin:6px 0 6px">${esc(standingsTitle(r))}</div>
${table([['Rank'], ['Player'], ['Points', true], ['Nights', true], ['Knockouts', true], ['Winnings', true]], stRows)}
</div>`;
}

function textTable(head, rows) {
  const widths = head.map(([h], i) => Math.max(h.length, ...rows.map((row) => String(row[i][0]).length)));
  const line = (cells) => cells.map(([v, right], i) => (right ? String(v).padStart(widths[i]) : String(v).padEnd(widths[i]))).join('   ').trimEnd();
  return [line(head.map(([h, right]) => [h, right])), ...rows.map(line)].join('\n');
}

function recapText(r) {
  const toc = isToc(r);
  const head = toc ? [['Place'], ['Player'], ['KOs', true], ['Paid', true]] : [['Place'], ['Player'], ['KOs', true], ['Points', true], ['Paid', true]];
  const rows = r.results.map((x) => (toc
    ? [[ordinal(x.place)], [x.name], [x.knockouts, true], [x.paid ? money(x.paid) : '', true]]
    : [[ordinal(x.place)], [x.name], [x.knockouts, true], [x.points, true], [x.paid ? money(x.paid) : '', true]]));
  const st = r.standings.map((x) => [[x.rank], [x.name], [x.points, true], [x.nights, true], [x.kos, true], [x.won ? money(x.won) : '', true]]);
  return [
    `${r.league}: ${r.name} results`,
    dateLong(r),
    '',
    `Winner: ${r.winner || 'not recorded'}`,
    summaryLine(r),
    ...(r.countsTowardSeason || toc ? [] : ['This night doesn’t count toward the season standings.']),
    '',
    textTable(head, rows),
    ...(r.highHandEnabled ? ['', `High hand: ${hhText(r)}`] : []),
    '',
    standingsTitle(r),
    '',
    textTable([['Rank'], ['Player'], ['Points', true], ['Nights', true], ['KOs', true], ['Winnings', true]], st),
  ].join('\n');
}

/* A printable page for saving as a PDF. */
function recapPage(r) {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${esc(r.league)} - ${esc(r.name)}</title>
<style>@page{size:letter;margin:.6in}body{margin:0}table{page-break-inside:auto}tr{page-break-inside:avoid}</style></head>
<body>${recapHtml(r)}</body></html>`;
}

/* ---------- Excel ---------- */

function shortName(name) {
  const m = MONTHS.find((x) => x.toLowerCase() === String(name).trim().toLowerCase());
  return m ? m.slice(0, 3) : String(name);
}

function standingsSheet(season, asOf) {
  const counted = season.nights.filter((n) => n.countsTowardSeason && n.kind !== 'toc');
  const hasCarry = Object.keys(season.carry || {}).length > 0;
  const head = [{ v: 'Rank', s: 'header' }, { v: 'Player', s: 'header' }];
  if (hasCarry) head.push({ v: 'Earlier', s: 'headerRight' });
  counted.forEach((n) => head.push({ v: shortName(n.name), s: 'headerRight' }));
  ['Total points', 'Knockouts', 'Nights', 'Wins', 'Winnings'].forEach((h) => head.push({ v: h, s: 'headerRight' }));
  const rows = [
    [{ v: `${season.league} - ${season.seasonName}`, s: 'title' }],
    [{ v: `Season standings as of ${asOf}`, s: 'subtle' }],
    [],
    head,
  ];
  season.standings.forEach((p) => {
    const row = [p.rank, p.name];
    if (hasCarry) row.push(season.carry[p.playerId] || null);
    counted.forEach((n) => { const x = n.results.find((y) => y.playerId === p.playerId); row.push(x ? x.points : null); });
    row.push({ v: p.points, s: 'bold' }, p.kos, p.nights, p.wins, p.won ? { v: p.won, s: 'money' } : null);
    rows.push(row);
  });
  return { name: 'Standings', widths: [7, 22, ...(hasCarry ? [9] : []), ...counted.map(() => 8), 12, 11, 8, 7, 11], rows };
}

function nightSheet(n) {
  const toc = isToc(n);
  const rows = [
    [{ v: `${n.name} Results`, s: 'title' }],
    [{ v: 'Date', s: 'bold' }, dateLong(n)],
    [{ v: 'Players', s: 'bold' }, n.players],
    [{ v: 'Rebuys', s: 'bold' }, n.rebuys],
    [],
    toc
      ? [{ v: 'Place', s: 'header' }, { v: 'Name', s: 'header' }, { v: 'Knockouts', s: 'headerRight' }, { v: 'Winnings', s: 'headerRight' }]
      : [{ v: 'Place', s: 'header' }, { v: 'Name', s: 'header' }, { v: 'Finish points', s: 'headerRight' }, { v: 'Knockouts', s: 'headerRight' }, { v: 'Total points', s: 'headerRight' }, { v: 'Winnings', s: 'headerRight' }],
  ];
  n.results.forEach((x) => rows.push(toc
    ? [x.place, x.name, x.knockouts, x.paid ? { v: x.paid, s: 'money' } : null]
    : [x.place, x.name, x.finishPoints, x.knockouts, { v: x.points, s: 'bold' }, x.paid ? { v: x.paid, s: 'money' } : null]));
  // Money and high hand to the right of the results, as on the league's monthly tabs.
  const side = [
    [{ v: 'Money', s: 'header' }, { v: '', s: 'header' }],
    ['Total collected', { v: n.collected, s: 'money' }],
    ['Prize pool', { v: n.pool, s: 'money' }],
    ['Paid out', { v: n.paidOut, s: 'money' }],
  ];
  if (!toc) side.push(['To the TOC pot', { v: n.toToc, s: 'money' }]);
  if (n.highHandEnabled) {
    side.push([], [{ v: 'High hand', s: 'header' }, { v: '', s: 'header' }]);
    side.push(['Player', n.highHand && n.highHand.name ? n.highHand.name : 'Not recorded']);
    if (n.highHand && n.highHand.hand) side.push(['Hand', n.highHand.hand]);
    side.push(['Paid', { v: n.highHandPayout, s: 'money' }]);
  }
  if (!n.countsTowardSeason && !toc) side.push([], [{ v: 'Doesn’t count toward the season', s: 'subtle' }]);
  const col = toc ? 5 : 7;
  side.forEach((cells, i) => {
    const r = 5 + i;
    while (rows.length <= r) rows.push([]);
    const row = rows[r];
    while (row.length < col) row.push(null);
    row[col] = cells[0] === undefined ? null : cells[0];
    row[col + 1] = cells[1] === undefined ? null : cells[1];
  });
  const widths = toc ? [7, 22, 11, 11, 3, 17, 14] : [7, 22, 13, 11, 12, 11, 3, 17, 14];
  return { name: n.name, widths, rows };
}

function seasonSheets(season, asOf) {
  return [standingsSheet(season, asOf), ...season.nights.map(nightSheet)];
}

module.exports = { recapHtml, recapText, recapPage, seasonSheets, dateLong, money };
