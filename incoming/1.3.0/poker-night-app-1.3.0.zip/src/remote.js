'use strict';
/* Lets an iPad (or any other device on the same Wi-Fi) run Poker Night in its web browser.
   The app on the computer stays in charge: it keeps the records, runs the clock, and sends every
   change to each connected screen. Nothing here reaches the internet. */
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

const PORTS = [8787, 8788, 8789, 8790, 8791];
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.otf': 'font/otf', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.ico': 'image/x-icon', '.pdf': 'application/pdf',
};
const MAX_BODY = 256 * 1024;
const LOCK_AFTER = 5;
const LOCK_MS = 60 * 1000;

function newPin() { return String(crypto.randomInt(0, 10000)).padStart(4, '0'); }

/* Addresses another device can use to reach this computer. The name ending in .local keeps working
   when the router hands out a new number; the number is the fallback. */
function addresses(port) {
  const out = [];
  const host = os.hostname();
  if (/^[A-Za-z0-9-]+(\.local)?$/.test(host)) out.push(`http://${host.endsWith('.local') ? host : `${host}.local`}:${port}`);
  const ips = [];
  Object.values(os.networkInterfaces()).forEach((list) => (list || []).forEach((a) => {
    const v4 = a.family === 'IPv4' || a.family === 4;
    if (v4 && !a.internal && !a.address.startsWith('169.254.')) ips.push(a.address);
  }));
  const rank = (ip) => (ip.startsWith('192.168.') ? 0 : ip.startsWith('10.') ? 1 : /^172\.(1[6-9]|2\d|3[01])\./.test(ip) ? 2 : 3);
  ips.sort((a, b) => rank(a) - rank(b)).forEach((ip) => out.push(`http://${ip}:${port}`));
  return out;
}

function createRemote(opts) {
  const { uiDir, assetsDir, guideFile, configFile, defaultEnabled, getState, act, notice, csv, excel, backupFile, onClientsChanged } = opts;
  let config = { enabled: defaultEnabled, pin: newPin(), salt: crypto.randomBytes(16).toString('hex') };
  try { Object.assign(config, JSON.parse(fs.readFileSync(configFile, 'utf8'))); } catch (_) { /* first run */ }
  if (process.env.POKER_REMOTE) config.enabled = true;
  if (process.env.POKER_REMOTE_PIN) config.pin = process.env.POKER_REMOTE_PIN;
  saveConfig();

  let server = null;
  let port = null;
  let error = null;
  const clients = new Set(); // { res, tv }
  const failures = new Map(); // ip -> { count, until }

  function saveConfig() { try { fs.writeFileSync(configFile, JSON.stringify(config, null, 1)); } catch (_) { /* not fatal */ } }
  const token = () => crypto.createHmac('sha256', config.salt).update(config.pin).digest('hex');

  function authed(req) {
    const m = /(?:^|;\s*)pn=([a-f0-9]{64})/.exec(req.headers.cookie || '');
    if (!m) return false;
    const a = Buffer.from(m[1]);
    const b = Buffer.from(token());
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }

  function controlCount() { let n = 0; clients.forEach((c) => { if (!c.tv) n += 1; }); return n; }

  function status() {
    return {
      enabled: config.enabled,
      running: !!server,
      pin: config.pin,
      port,
      urls: server ? addresses(port) : [],
      clients: controlCount(),
      tvClients: clients.size - controlCount(),
      error,
    };
  }

  function forClient(state, tv) {
    const s = { ...state, serverNow: Date.now() };
    if (tv) { delete s.remote; delete s.dataDir; }
    return s;
  }

  function send(channel, payload) {
    clients.forEach((c) => {
      const data = channel === 'state' ? forClient(payload, c.tv) : payload;
      try { c.res.write(`event: ${channel}\ndata: ${JSON.stringify(data)}\n\n`); } catch (_) { /* closed */ }
    });
  }

  /* ---------- Pages ---------- */

  function page(name, tv) {
    let html = fs.readFileSync(path.join(uiDir, name), 'utf8');
    html = html.replace("default-src 'none';", "default-src 'none'; connect-src 'self';");
    html = html.replace('<meta charset="utf-8">', `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="${tv ? 'Poker TV' : 'Poker Night'}">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<link rel="apple-touch-icon" href="icon.png">`);
    html = html.replace('<script src="common.js"></script>', '<script src="remote.js"></script>\n<script src="common.js"></script>');
    html = html.replace('<body>', `<body class="remote${tv ? ' remote-tv' : ''}">`);
    return html;
  }

  function loginPage(message) {
    return `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="Poker Night">
<link rel="apple-touch-icon" href="icon.png">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src 'self'; form-action 'self'">
<title>Poker Night</title>
<style>
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0d3d2f;font-family:-apple-system,"Segoe UI",sans-serif;color:#17231e}
form{background:#fff;border-radius:16px;padding:32px 36px;width:min(360px,86vw);box-shadow:0 10px 40px #0005;text-align:center}
h1{font-size:28px;margin:0 0 6px;color:#0d3d2f}p{margin:0 0 18px;color:#52625b;font-size:16px;line-height:1.4}
input{font-size:34px;letter-spacing:12px;text-align:center;width:100%;box-sizing:border-box;padding:10px;border:2px solid #9fb0a8;border-radius:10px}
button{margin-top:16px;width:100%;font-size:19px;font-weight:600;padding:14px;border:0;border-radius:10px;background:#12513f;color:#fff}
.err{color:#a3271f;font-weight:600;margin:12px 0 0}
</style></head><body>
<form method="post" action="/login">
<h1>Poker Night</h1>
<p>Enter the PIN shown in Settings on the computer running Poker Night.</p>
<input name="pin" inputmode="numeric" pattern="[0-9]*" maxlength="8" autocomplete="off" autofocus aria-label="PIN">
<button type="submit">Open Poker Night</button>
${message ? `<p class="err">${message}</p>` : ''}
</form></body></html>`;
  }

  /* ---------- Requests ---------- */

  function reply(res, code, body, type, extra = {}) {
    res.writeHead(code, { 'Content-Type': type || 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...extra });
    res.end(body);
  }
  const json = (res, code, obj) => reply(res, code, JSON.stringify(obj), 'application/json; charset=utf-8');

  function readBody(req) {
    return new Promise((resolve, reject) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => { size += c.length; if (size > MAX_BODY) { reject(new Error('Too much data.')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  function serveFile(res, file) {
    const ext = path.extname(file).toLowerCase();
    if (!TYPES[ext]) return reply(res, 404, 'Not found');
    fs.readFile(file, (err, data) => {
      if (err) return reply(res, 404, 'Not found');
      reply(res, 200, data, TYPES[ext], { 'Cache-Control': ext === '.pdf' ? 'no-store' : 'no-cache' });
    });
  }

  function inside(dir, rel) {
    const full = path.normalize(path.join(dir, rel));
    return full.startsWith(path.normalize(dir + path.sep)) ? full : null;
  }

  async function handle(req, res) {
    const url = new URL(req.url, 'http://x');
    const p = decodeURIComponent(url.pathname);
    const ip = req.socket.remoteAddress || '';
    const ok = authed(req);
    const tvQuery = url.searchParams.get('tv') === '1';

    if (req.method === 'GET' && p === '/') return ok ? reply(res, 200, page('control.html', false), TYPES['.html']) : reply(res, 200, loginPage(url.searchParams.get('m') || ''), TYPES['.html']);
    if (req.method === 'GET' && (p === '/tv' || p === '/tv/')) return reply(res, 200, page('tv.html', true), TYPES['.html']);

    if (req.method === 'POST' && p === '/login') {
      const f = failures.get(ip);
      if (f && f.until > Date.now()) return reply(res, 303, '', null, { Location: '/?m=Too%20many%20tries.%20Wait%20a%20minute%2C%20then%20try%20again.' });
      let pin = '';
      try { pin = new URLSearchParams(await readBody(req)).get('pin') || ''; } catch (_) { /* empty */ }
      if (pin.trim() === config.pin) {
        failures.delete(ip);
        return reply(res, 303, '', null, { Location: '/', 'Set-Cookie': `pn=${token()}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Strict` });
      }
      const n = (f ? f.count : 0) + 1;
      failures.set(ip, { count: n >= LOCK_AFTER ? 0 : n, until: n >= LOCK_AFTER ? Date.now() + LOCK_MS : 0 });
      return reply(res, 303, '', null, { Location: '/?m=That%20PIN%20didn%E2%80%99t%20match.%20Check%20Settings%20on%20the%20computer.' });
    }

    if (p === '/api/state' && req.method === 'GET') {
      if (!tvQuery && !ok) return json(res, 401, { ok: false });
      return json(res, 200, forClient(getState(), tvQuery));
    }
    if (p === '/api/stream' && req.method === 'GET') {
      if (!tvQuery && !ok) return json(res, 401, { ok: false });
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      res.write('retry: 2000\n\n');
      const client = { res, tv: tvQuery };
      clients.add(client);
      res.write(`event: state\ndata: ${JSON.stringify(forClient(getState(), tvQuery))}\n\n`);
      req.on('close', () => { clients.delete(client); onClientsChanged(); });
      onClientsChanged();
      return undefined;
    }
    if (req.method === 'POST' && (p === '/api/act' || p === '/api/command')) {
      if (!ok) return json(res, 401, { ok: false, error: 'Enter the PIN again.' });
      if (req.headers['x-poker'] !== '1') return json(res, 403, { ok: false, error: 'Not allowed.' });
      let body;
      try { body = JSON.parse(await readBody(req)); } catch (_) { return json(res, 400, { ok: false, error: 'That request didn’t make sense.' }); }
      if (p === '/api/act') return json(res, 200, await act(String(body.type || ''), body.payload || {}));
      const name = String(body.name || '');
      if (name === 'exportCsv' || name === 'exportExcel') return json(res, 200, { ok: true, download: '/download/season.xlsx' });
      if (name === 'backupNow') return json(res, 200, { ok: true, download: '/download/poker-night-backup.json' });
      if (name === 'openGuide') return json(res, 200, { ok: true, open: '/guide.pdf' });
      if (name === 'dismissNotice') { notice(); return json(res, 200, { ok: true }); }
      return json(res, 200, { ok: false, error: 'Do this on the computer running Poker Night.' });
    }
    if (req.method === 'GET' && p.startsWith('/download/')) {
      if (!ok) return reply(res, 401, 'Enter the PIN first.');
      const day = new Date().toISOString().slice(0, 10);
      if (p === '/download/season.xlsx') return reply(res, 200, excel(), 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', { 'Content-Disposition': 'attachment; filename="Season.xlsx"' });
      if (p === '/download/season-standings.csv') return reply(res, 200, `﻿${csv()}`, 'text/csv; charset=utf-8', { 'Content-Disposition': 'attachment; filename="Season standings.csv"' });
      if (p === '/download/poker-night-backup.json') return reply(res, 200, backupFile(), 'application/json', { 'Content-Disposition': `attachment; filename="Poker Night backup ${day}.json"` });
      return reply(res, 404, 'Not found');
    }
    if (req.method === 'GET' && p === '/guide.pdf') return serveFile(res, guideFile);
    if (req.method === 'GET' && p === '/icon.png') return serveFile(res, path.join(assetsDir, 'icon.png'));
    if (req.method === 'GET') {
      const file = inside(uiDir, p.replace(/^\/+/, ''));
      if (file) return serveFile(res, file);
    }
    return reply(res, 404, 'Not found');
  }

  /* ---------- Starting and stopping ---------- */

  function listen(i, done) {
    if (i >= PORTS.length) { error = 'Poker Night couldn’t open a connection for other devices. Restart the computer and try again.'; done(); return; }
    const s = http.createServer((req, res) => { handle(req, res).catch(() => { try { reply(res, 500, 'Something went wrong.'); } catch (_) { /* gone */ } }); });
    s.keepAliveTimeout = 65000;
    s.once('error', () => { s.close(); listen(i + 1, done); });
    s.listen(PORTS[i], '0.0.0.0', () => { server = s; port = PORTS[i]; error = null; done(); });
  }

  const heartbeat = setInterval(() => clients.forEach((c) => { try { c.res.write(': still here\n\n'); } catch (_) { /* closed */ } }), 20000);

  function start(done = () => {}) {
    if (server || !config.enabled) { done(); return; }
    listen(0, done);
  }
  function stop() {
    clients.forEach((c) => { try { c.res.end(); } catch (_) { /* closed */ } });
    clients.clear();
    if (server) { server.close(); server = null; port = null; }
  }

  return {
    status,
    send,
    start,
    stop,
    shutdown() { clearInterval(heartbeat); stop(); },
    setEnabled(on, done) { config.enabled = !!on; saveConfig(); if (on) start(done); else { stop(); done(); } },
    newPin() { config.pin = newPin(); saveConfig(); clients.forEach((c) => { if (!c.tv) { try { c.res.end(); } catch (_) { /* closed */ } } }); },
    hasControlClients: () => controlCount() > 0,
    get enabled() { return config.enabled; },
  };
}

module.exports = { createRemote, addresses };
