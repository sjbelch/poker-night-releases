'use strict';
/*
 * Poker Night game logic. No Electron or screen code lives here, so every rule can be
 * tested on its own. `db` is the whole saved file; `dispatch` is the only way to change it.
 */

const League = require('./league.js');
const Season2026 = require('./season2026.js');
const Hands = require('../ui/hands.js');

const SCHEMA_VERSION = 1;
const MAX_UNDO = 40;
const LEAGUE_VERSION = 7;

function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
const clone = (v) => JSON.parse(JSON.stringify(v));

class GameError extends Error {}
function fail(msg) { throw new GameError(msg); }

/* ---------- Default values (all editable in the app) ---------- */

function defaultLevels() {
  const blinds = [[25, 50], [50, 100], [75, 150], [100, 200], [150, 300], [200, 400], [300, 600], [400, 800],
    [500, 1000], [700, 1400], [1000, 2000], [1500, 3000], [2000, 4000], [3000, 6000], [4000, 8000], [5000, 10000]];
  const levels = [];
  blinds.forEach(([sb, bb], i) => {
    levels.push({ kind: 'round', sb, bb, ante: 0, minutes: 15 });
    if ((i + 1) % 4 === 0 && i < blinds.length - 1) levels.push({ kind: 'break', minutes: 10 });
  });
  return levels;
}

function defaultConfig() {
  return {
    buyIn: 20,
    startingChips: 3000,
    levels: defaultLevels(),
    rebuy: { enabled: true, lastRound: 4, cost: 20, chips: 3000, maxPerPlayer: 0 },
    addon: { enabled: false, lastRound: 4, cost: 20, chips: 3000 },
    seatsPerTable: 10,
    startTwoAt: 10,
    startThreeAt: 20,
    breakToTwo: 16,
    breakToOne: 9,
    rakePercent: 20,
  };
}

function defaultRules() {
  return {
    pointsPerKnockout: 1,
    finishMode: 'chart', // 'chart' = league chart by player count; 'table' = a set number per place; 'field' = beat-a-player points
    pointChart: clone(League.POINT_CHART),
    finishTable: [50, 35, 25, 20, 15, 10, 8, 6, 4, 2],
    fieldMultiplier: 5,
    attendancePoints: 0,
    rebuyKnockoutsCount: true,
    dropWorst: 0,
    tieBreak: 'knockouts', // 'knockouts' | 'wins' | 'nights'
  };
}

function defaultSettings() {
  return {
    leagueName: League.LEAGUE_NAME,
    highHandPerPlayer: 5,
    highHandInToc: false,
    tables: { pauseOnRedraw: true, redrawAtOne: false },
    tv: { scene: 'auto', duringPlay: 'beside', alternateSeconds: 20, standingsRows: 10 },
    sounds: { roundEnd: false, oneMinute: false, voice: false, volume: 70 },
    payout: {
      roundTo: 5,
      basis: 'players', // which count picks the payout row: 'players' or 'buyins' (players + rebuys)
      brackets: [
        { minPlayers: 3, splits: [70, 30] },
        { minPlayers: 8, splits: [55, 30, 15] },
        { minPlayers: 14, splits: [50, 25, 15, 10] },
        { minPlayers: 20, splits: [45, 23, 15, 10, 7] },
      ],
    },
    toc: {
      toc8: [27, 20.5, 16, 13, 10, 7, 4, 2.5],
      toc6: [40, 25, 16.5, 10, 5, 3.5],
      toc6MaxPlayers: 16,
      minNights: 6,
      roundTo: 0.01,
      baseChips: 3000,
      chipsPerPoint: 20,
      fees: [{ minNights: 6, fee: 40 }, { minNights: 5, fee: 100 }, { minNights: 4, fee: 200 }],
      rebuyCost: 40,
      rebuyChips: 3000,
    },
  };
}

function leaguePlayer(name) {
  return { id: `p_${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`, name, active: true };
}

function newSeason(name, opts = {}) {
  return {
    id: uid('season'),
    name,
    startDate: opts.startDate || '',
    endDate: opts.endDate || '',
    rules: opts.rules ? clone(opts.rules) : defaultRules(),
    carry: {},
    potAdjust: 0,
    test: !!opts.test,
  };
}

/* Sample players and results for tests and screenshots, used in place of the empty starting data. */
function useSeed(seed) {
  if (seed.leagueName) League.LEAGUE_NAME = seed.leagueName;
  if (seed.players) League.PLAYERS = seed.players;
  if (seed.months) Season2026.MONTHS = seed.months;
  if (seed.potAdjust !== undefined) Season2026.POT_ADJUST = seed.potAdjust;
}

function emptyDb() {
  const season = newSeason(`${new Date().getFullYear()} season`);
  const players = League.PLAYERS.map(leaguePlayer).sort((a, b) => a.name.localeCompare(b.name));
  return {
    version: SCHEMA_VERSION,
    testData: false,
    leagueVersion: 1,
    settings: defaultSettings(),
    defaults: defaultConfig(),
    players,
    seasons: [season],
    activeSeasonId: season.id,
    tournaments: [],
    currentTournamentId: null,
    rev: 0,
  };
}

/* ---------- Tournament helpers ---------- */

function localDate(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function newEntry(playerId) {
  return { playerId, status: 'in', place: null, outSeq: null, rebuys: 0, addons: 0, koAdjust: 0, table: null, seat: null };
}

function newTournament(db, opts = {}) {
  const season = activeSeason(db);
  const kind = opts.kind === 'toc' ? 'toc' : 'regular';
  const config = clone(db.defaults);
  if (kind === 'toc') {
    const toc = db.settings.toc;
    config.buyIn = 0;
    config.rakePercent = 0;
    config.startingChips = toc.baseChips;
    config.rebuy = { ...config.rebuy, enabled: true, cost: toc.rebuyCost, chips: toc.rebuyChips };
  }
  return {
    id: uid('night'),
    kind,
    seasonId: season ? season.id : null,
    name: opts.name || (kind === 'toc' ? `${season ? season.name : ''} Tournament of Champions`.trim() : new Date().toLocaleDateString('en-US', { month: 'long' })),
    date: opts.date || localDate(),
    countsTowardSeason: kind !== 'toc',
    status: 'setup',
    config,
    entries: [],
    knockouts: [],
    seq: 0,
    undo: [],
    clock: { levelIndex: 0, remainingMs: 0, anchor: 0, running: false, pauseAfter: false, warned: false },
    restartedPaused: false,
  };
}

const activeSeason = (db) => db.seasons.find((s) => s.id === db.activeSeasonId) || db.seasons[0] || null;
const current = (db) => db.tournaments.find((t) => t.id === db.currentTournamentId) || null;
const playerName = (db, id) => (db.players.find((p) => p.id === id) || { name: 'Unknown' }).name;

function needCurrent(db) { return current(db) || fail('There is no tournament open.'); }
function needEntry(t, id) { return t.entries.find((e) => e.playerId === id) || fail('That player is not in this tournament.'); }

function ordinal(n) {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`;
}

function roundNumber(levels, index) {
  let n = 0;
  for (let i = 0; i <= index && i < levels.length; i++) if (levels[i].kind === 'round') n++;
  return Math.max(n, 1);
}

function rebuysOpen(t) {
  const r = t.config.rebuy;
  if (!r.enabled || t.status !== 'running') return false;
  return roundNumber(t.config.levels, t.clock.levelIndex) <= r.lastRound;
}
function addonsOpen(t) {
  const a = t.config.addon;
  if (!a.enabled || t.status !== 'running') return false;
  return roundNumber(t.config.levels, t.clock.levelIndex) <= a.lastRound;
}
function canRebuy(t, entry) {
  if (!rebuysOpen(t)) return false;
  const max = t.config.rebuy.maxPerPlayer;
  return !max || entry.rebuys < max;
}

/* A player's place is decided by the order they went out, so a rebuy or a late entry
   renumbers everyone correctly. Two players out on one hand: the first one entered places lower. */
function recomputePlaces(t, withWinner) {
  const n = t.entries.length;
  const out = t.entries.filter((e) => e.status === 'out').sort((a, b) => a.outSeq - b.outSeq);
  t.entries.forEach((e) => { e.place = null; });
  out.forEach((e, i) => { e.place = n - i; });
  const alive = t.entries.filter((e) => e.status === 'in');
  if (withWinner && alive.length === 1) alive[0].place = 1;
}

function pushUndo(t, label) {
  t.undo.push({
    label,
    entries: clone(t.entries),
    knockouts: clone(t.knockouts),
    status: t.status,
    seq: t.seq,
    redrawNotice: t.redrawNotice || null,
  });
  if (t.undo.length > MAX_UNDO) t.undo.shift();
}

/* ---------- Clock ---------- */

function levelMs(t, i) { return Math.max(0, (t.config.levels[i] ? t.config.levels[i].minutes : 0)) * 60000; }

function remainingMs(t, now) {
  const c = t.clock;
  return c.running ? c.remainingMs - (now - c.anchor) : c.remainingMs;
}

function freeze(t, now) {
  t.clock.remainingMs = remainingMs(t, now);
  t.clock.anchor = now;
}

function goToLevel(t, index, now) {
  t.clock.levelIndex = index;
  t.clock.remainingMs = levelMs(t, index);
  t.clock.anchor = now;
  t.clock.warned = false;
}

function levelAnnouncement(t) {
  const level = t.config.levels[t.clock.levelIndex];
  if (!level) return null;
  return {
    kind: level.kind,
    round: roundNumber(t.config.levels, t.clock.levelIndex),
    sb: level.sb, bb: level.bb, ante: level.ante, minutes: level.minutes,
  };
}

/* Advance the clock to `now`. Returns events for sounds and the TV. */
function tick(db, now) {
  const t = current(db);
  const events = [];
  if (!t || t.status !== 'running' || !t.clock.running) return events;
  const c = t.clock;
  let rem = remainingMs(t, now);
  const lvl = t.config.levels[c.levelIndex];
  if (!c.warned && lvl && lvl.minutes > 1 && rem > 0 && rem <= 60000) {
    c.warned = true;
    events.push({ type: 'oneMinute', kind: lvl.kind });
  }
  let guard = 0;
  while (rem <= 0 && guard++ < 500) {
    const isLast = c.levelIndex >= t.config.levels.length - 1;
    const wasOpen = rebuysOpen(t);
    if (isLast) {
      // No more levels were entered: hold the last blinds and run the round again.
      goToLevel(t, c.levelIndex, now);
      rem += levelMs(t, c.levelIndex) || 60000;
      events.push({ type: 'lastLevelRepeat' });
    } else {
      goToLevel(t, c.levelIndex + 1, now);
      rem += levelMs(t, c.levelIndex);
      events.push({ type: 'level', level: levelAnnouncement(t) });
    }
    if (wasOpen && !rebuysOpen(t)) events.push({ type: 'rebuysClosed' });
    if (c.pauseAfter) {
      c.pauseAfter = false;
      c.running = false;
      rem = levelMs(t, c.levelIndex);
      events.push({ type: 'pausedAfterRound' });
      break;
    }
  }
  if (events.some((e) => e.type === 'level' || e.type === 'lastLevelRepeat' || e.type === 'pausedAfterRound')) {
    c.remainingMs = rem;
    c.anchor = now;
    db.rev++;
  }
  return events;
}

/* ---------- Money ---------- */

function grossMoney(t) {
  const c = t.config;
  const rebuys = t.entries.reduce((n, e) => n + e.rebuys, 0);
  const addons = t.entries.reduce((n, e) => n + e.addons, 0);
  return c.buyIn * t.entries.length + (c.rebuy.enabled ? c.rebuy.cost * rebuys : 0) + (c.addon.enabled ? c.addon.cost * addons : 0);
}

/* The share of a regular night's money that goes to the Tournament of Champions pot. */
function potTotal(t) { if (t.fixedPot !== undefined) return t.fixedPot; return t.kind === 'toc' ? 0 : grossMoney(t) * ((t.config.rakePercent || 0) / 100); }

function seasonPot(db, season) {
  if (!season) return 0;
  return db.tournaments.filter((x) => x.seasonId === season.id && x.status !== 'setup').reduce((n, x) => n + potTotal(x), 0) + (Number(season.potAdjust) || 0);
}

/* The TOC entry fee depends on how many nights the player has played this season. */
function tocFee(db, nights) {
  const fees = db.settings.toc.fees.slice().sort((a, b) => b.minNights - a.minNights);
  const tier = fees.find((f) => nights >= f.minNights);
  return tier ? tier.fee : fees[fees.length - 1].fee;
}

function entryFee(db, t, e) {
  if (e.fee !== undefined && e.fee !== null) return e.fee;
  const season = db.seasons.find((x) => x.id === t.seasonId) || activeSeason(db);
  const row = calcStandings(db, season).find((r) => r.playerId === e.playerId);
  return tocFee(db, row ? row.nights : 0);
}

function prizePool(t, db) {
  if (t.fixedPool !== undefined) return t.fixedPool;
  if (t.kind === 'toc') {
    const season = db && (db.seasons.find((x) => x.id === t.seasonId) || activeSeason(db));
    const pot = t.potAtStart !== undefined ? t.potAtStart : (db ? seasonPot(db, season) : 0);
    const fees = db ? t.entries.reduce((n, e) => n + entryFee(db, t, e), 0) : 0;
    return Math.max(0, pot + fees + grossMoney(t));
  }
  return Math.max(0, Math.round((grossMoney(t) - potTotal(t)) * 100) / 100);
}

/* The payout row is chosen by players, or by players plus rebuys, as set in Settings. */
function payoutCount(payout, t) {
  const rebuys = t.entries.reduce((n, e) => n + e.rebuys, 0);
  return t.entries.length + (payout.basis === 'buyins' ? rebuys : 0);
}

function splitsFor(payout, playerCount) {
  const eligible = payout.brackets
    .filter((b) => playerCount >= b.minPlayers && b.splits.length)
    .sort((a, b) => b.minPlayers - a.minPlayers);
  return eligible.length ? eligible[0].splits : [100];
}

/* Each place rounds to the nearest step. If that would pay more than the pool, the places rounded
   up the most come down one step. Exact-cents payouts always add up to the pool. */
function splitAmounts(splits, pool, roundTo) {
  const total = splits.reduce((a, b) => a + b, 0) || 100;
  const step = roundTo > 0 ? roundTo : 1;
  const exact = splits.map((pct) => pool * (pct / total));
  const toCents = (n) => Math.round(n * 100) / 100;
  const amounts = exact.map((v) => toCents(Math.round(v / step + 1e-9) * step));
  let guard = 0;
  while (amounts.reduce((a, b) => a + b, 0) > pool + 1e-6 && guard++ < 200) {
    let pick = -1;
    let most = -Infinity;
    amounts.forEach((a, i) => { if (a >= step && a - exact[i] > most) { most = a - exact[i]; pick = i; } });
    if (pick < 0) break;
    amounts[pick] = toCents(amounts[pick] - step);
  }
  if (step < 1 && amounts.length) amounts[0] = toCents(amounts[0] + (pool - amounts.reduce((a, b) => a + b, 0)));
  return amounts.map((amount, i) => ({ place: i + 1, amount, percent: splits[i] }));
}

function payouts(payout, pool, playerCount) {
  return splitAmounts(splitsFor(payout, playerCount), pool, payout.roundTo);
}

/* TOC8 is the default. TOC6 applies only at the set player count (16) or below. */
function tocSplits(toc, playerCount) { return playerCount <= toc.toc6MaxPlayers ? toc.toc6 : toc.toc8; }

function paysFor(db, t) {
  if (t.fixedPays) return t.fixedPays;
  const pool = prizePool(t, db);
  if (t.kind === 'toc') return splitAmounts(tocSplits(db.settings.toc, t.entries.length), pool, db.settings.toc.roundTo);
  return payouts(db.settings.payout, pool, payoutCount(db.settings.payout, t));
}

/* ---------- Season points ---------- */

/* His chart covers 6 to 35 players. Smaller fields use the 6-player column. Above 35, each extra
   player adds a point to every place, which is how the chart itself grows. */
function chartPoints(chart, place, fieldSize) {
  const sizes = Object.keys(chart).map(Number).sort((a, b) => a - b);
  const min = sizes[0];
  const max = sizes[sizes.length - 1];
  if (fieldSize < min) return chart[min][place - 1] || 0;
  if (fieldSize <= max) return chart[fieldSize][place - 1] || 0;
  const base = chart[max][place - 1];
  return (base !== undefined ? base : max - place + 4) + (fieldSize - max);
}

function finishPoints(rules, place, fieldSize) {
  if (!place) return 0;
  if (rules.finishMode === 'chart') return chartPoints(rules.pointChart || League.POINT_CHART, place, fieldSize);
  if (rules.finishMode === 'field') return Math.max(0, fieldSize - place + 1) * (rules.fieldMultiplier || 0);
  return rules.finishTable[place - 1] || 0;
}

/* One knockout can credit several players when a split pot knocks someone out; each gets full credit. */
function koCredits(k) {
  if (k.byIds) return k.byIds;
  return k.byId ? [k.byId] : [];
}

function nameList(names) {
  if (names.length < 2) return names[0] || '';
  return `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`;
}

function knockoutCount(rules, t, playerId) {
  const entry = t.entries.find((e) => e.playerId === playerId);
  const counted = t.knockouts.filter((k) => koCredits(k).includes(playerId) && (rules.rebuyKnockoutsCount || !k.rebought)).length;
  return Math.max(0, counted + ((entry && entry.koAdjust) || 0));
}

function nightPoints(rules, t, entry) {
  const kos = knockoutCount(rules, t, entry.playerId);
  const finish = finishPoints(rules, entry.place, t.entries.length);
  return { kos, finish, koPoints: kos * rules.pointsPerKnockout, attendance: rules.attendancePoints || 0,
    total: kos * rules.pointsPerKnockout + finish + (rules.attendancePoints || 0) };
}

function calcStandings(db, season, opts = {}) {
  if (!season) return [];
  const rows = new Map();
  const row = (playerId) => {
    if (!rows.has(playerId)) {
      rows.set(playerId, { playerId, name: playerName(db, playerId), points: 0, kos: 0, nights: 0, wins: 0, best: null, won: 0, tonight: null, perNight: [] });
    }
    return rows.get(playerId);
  };
  Object.entries(season.carry || {}).forEach(([playerId, c]) => {
    if ((c.points || 0) || (c.knockouts || 0) || (c.nights || 0)) {
      const r = row(playerId);
      r.points += c.points || 0;
      r.kos += c.knockouts || 0;
      r.nights += c.nights || 0;
    }
  });
  const rules = season.rules;
  const curId = db.currentTournamentId;
  db.tournaments.forEach((t) => {
    if (t.seasonId !== season.id || !t.countsTowardSeason || t.status === 'setup') return;
    if (opts.excludeCurrent && t.id === curId) return;
    if (opts.upTo && String(t.date) > String(opts.upTo)) return; // standings as they stood after a given night
    const pays = paysFor(db, t);
    t.entries.forEach((e) => {
      const r = row(e.playerId);
      const pts = nightPoints(rules, t, e);
      r.nights += 1;
      r.kos += pts.kos;
      r.perNight.push(pts.total);
      if (e.place === 1) r.wins += 1;
      if (e.place && (r.best === null || e.place < r.best)) r.best = e.place;
      const paid = e.place && pays.find((p) => p.place === e.place);
      if (paid && t.status !== 'running') r.won += paid.amount;
      if (t.id === curId) r.tonight = { points: pts.total, kos: pts.kos, place: e.place, status: e.status };
    });
  });
  const list = [...rows.values()];
  list.forEach((r) => {
    const sorted = r.perNight.slice().sort((a, b) => a - b);
    const dropped = sorted.slice(0, Math.min(rules.dropWorst || 0, Math.max(0, sorted.length - 1)));
    r.dropped = dropped.reduce((a, b) => a + b, 0);
    r.points += sorted.reduce((a, b) => a + b, 0) - r.dropped;
    delete r.perNight;
  });
  const tie = { knockouts: ['kos', 'wins', 'nights'], wins: ['wins', 'kos', 'nights'], nights: ['nights', 'kos', 'wins'] }[rules.tieBreak] || ['kos', 'wins', 'nights'];
  const cmp = (a, b) => b.points - a.points || b[tie[0]] - a[tie[0]] || b[tie[1]] - a[tie[1]] || b[tie[2]] - a[tie[2]];
  list.sort((a, b) => cmp(a, b) || a.name.localeCompare(b.name));
  list.forEach((r, i) => { r.rank = i > 0 && cmp(list[i - 1], r) === 0 ? list[i - 1].rank : i + 1; });
  return list;
}

/* ---------- Tables and seats ---------- */

function tableGroups(t) {
  const groups = new Map();
  t.entries.filter((e) => e.status === 'in' && e.table).forEach((e) => {
    if (!groups.has(e.table)) groups.set(e.table, []);
    groups.get(e.table).push(e);
  });
  return groups;
}

function freeSeat(t, table) {
  const taken = new Set(t.entries.filter((e) => e.status === 'in' && e.table === table).map((e) => e.seat));
  let s = 1;
  while (taken.has(s)) s++;
  return s;
}

/* Tables at the start of a night: 1 table up to 9 players, 2 tables from 10, 3 tables from 20 (adjustable).
   The table size still applies, so no table is ever asked to hold more than its seats. */
function startTables(t, players) {
  const c = t.config;
  const two = c.startTwoAt === undefined ? 10 : c.startTwoAt;
  const three = c.startThreeAt === undefined ? 20 : c.startThreeAt;
  const byRule = players >= three ? 3 : players >= two ? 2 : 1;
  const seats = Math.max(2, c.seatsPerTable || 9);
  return Math.max(byRule, Math.ceil(players / seats));
}

/* The most tables a night should still be using: 2 tables at 16, 1 table at 9 (both adjustable).
   A night never adds tables as players leave, so one that started on 2 stays on 2 until it reaches 1. */
function targetTables(t, players) {
  const c = t.config;
  const toTwo = c.breakToTwo === undefined ? 16 : c.breakToTwo;
  const toOne = c.breakToOne === undefined ? 9 : c.breakToOne;
  const byRule = players <= toOne ? 1 : players <= toTwo ? 2 : 3;
  const seats = Math.max(2, c.seatsPerTable || 9);
  return Math.max(byRule, Math.ceil(players / seats));
}

function tableMoves(t) {
  const groups = tableGroups(t);
  if (groups.size < 2) return [];
  const alive = [...groups.values()].reduce((n, g) => n + g.length, 0);
  const counts = new Map([...groups].map(([k, g]) => [k, g.length]));
  const smallestFirst = () => [...counts.entries()].sort((a, b) => a[1] - b[1] || a[0] - b[0]);
  const target = targetTables(t, alive);
  const moves = [];
  if (groups.size > target) {
    const [breakTable] = smallestFirst()[0];
    counts.delete(breakTable);
    groups.get(breakTable).sort((a, b) => a.seat - b.seat).forEach((e) => {
      const [to] = smallestFirst()[0];
      counts.set(to, counts.get(to) + 1);
      moves.push({ playerId: e.playerId, from: breakTable, to, reason: `${alive} players left, so table ${breakTable} is breaking up` });
    });
    return moves;
  }
  const order = smallestFirst();
  const [minT, minN] = order[0];
  const [maxT, maxN] = order[order.length - 1];
  if (maxN - minN >= 2) {
    const mover = groups.get(maxT).sort((a, b) => b.seat - a.seat)[0];
    moves.push({ playerId: mover.playerId, from: maxT, to: minT, reason: `Table ${maxT} has ${maxN} players and table ${minT} has ${minN}` });
  }
  return moves;
}

function seatNewPlayer(t, entry) {
  const groups = tableGroups(t);
  if (!groups.size) return;
  const seats = t.config.seatsPerTable || 9;
  const sorted = [...groups.entries()].sort((a, b) => a[1].length - b[1].length || a[0] - b[0]);
  let table = sorted[0][0];
  if (sorted[0][1].length >= seats) table = Math.max(...groups.keys()) + 1;
  entry.table = table;
  entry.seat = freeSeat(t, table);
}

function assignTables(order, tables, tableFor) {
  const next = Array(tables).fill(0);
  order.forEach((e, i) => {
    const tb = tableFor(i);
    next[tb]++;
    e.table = tb + 1;
    e.seat = next[tb];
  });
}

/* Before anyone is seated, the starting limits decide. Once tables are open, a new draw keeps to
   them and only moves down when the night is ready to consolidate. */
function tablesForDraw(t, players) {
  const open = tableGroups(t).size;
  if (t.status === 'setup' || !open) return startTables(t, players);
  const seats = Math.max(2, t.config.seatsPerTable || 9);
  return Math.max(Math.min(open, targetTables(t, players)), Math.ceil(players / seats));
}

function drawSeats(t, random = Math.random) {
  const alive = t.entries.filter((e) => e.status === 'in');
  if (!alive.length) fail('Check in some players first.');
  const tables = tablesForDraw(t, alive.length);
  const shuffled = alive.slice();
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  assignTables(shuffled, tables, (i) => i % tables);
}

/* Snake order: tables 1, 2, 3, then 3, 2, 1, and so on down the standings. */
function snakeIndex(i, tables) {
  const pos = i % (2 * tables);
  return pos < tables ? pos : 2 * tables - 1 - pos;
}

function snakeSeats(db, t) {
  const alive = t.entries.filter((e) => e.status === 'in');
  if (!alive.length) fail('Check in some players first.');
  const season = db.seasons.find((x) => x.id === t.seasonId) || activeSeason(db);
  const standings = calcStandings(db, season);
  const pos = new Map(standings.map((r, i) => [r.playerId, i]));
  const order = alive.slice().sort((a, b) => {
    const pa = pos.has(a.playerId) ? pos.get(a.playerId) : Infinity;
    const pb = pos.has(b.playerId) ? pos.get(b.playerId) : Infinity;
    return pa - pb || playerName(db, a.playerId).localeCompare(playerName(db, b.playerId));
  });
  const tables = tablesForDraw(t, alive.length);
  assignTables(order, tables, (i) => snakeIndex(i, tables));
}

function assertTocQualified(db, t, playerId) {
  if (t.kind !== 'toc') return;
  const season = db.seasons.find((x) => x.id === t.seasonId) || activeSeason(db);
  const row = calcStandings(db, season).find((r) => r.playerId === playerId);
  const nights = row ? row.nights : 0;
  const need = db.settings.toc.minNights;
  if (nights < need) fail(`${playerName(db, playerId)} has played ${nights} ${nights === 1 ? 'night' : 'nights'}. The TOC requires ${need}.`);
}

/* ---------- Actions ---------- */

function setPath(obj, path, value) {
  const keys = path.split('.');
  if (keys.some((k) => ['__proto__', 'constructor', 'prototype'].includes(k))) fail('That setting is not available.');
  let o = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    if (typeof o[keys[i]] !== 'object' || o[keys[i]] === null) fail('That setting is not available.');
    o = o[keys[i]];
  }
  o[keys[keys.length - 1]] = value;
}

function num(v, { min = 0, fallback = 0 } = {}) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, n);
}

function assertLevelEditable(t, i) {
  if (t.status === 'running' && i <= t.clock.levelIndex) fail('That round has already started, so it can’t be changed or removed.');
}

const actions = {
  /* Settings and season rules */
  'settings.set': (db, { path, value }) => {
    setPath(db.settings, path, value);
    return [];
  },
  'payout.setBracket': (db, { index, minPlayers, splits }) => {
    const b = db.settings.payout.brackets[index] || fail('That payout row is gone.');
    if (minPlayers !== undefined) b.minPlayers = num(minPlayers, { min: 1, fallback: 1 });
    if (splits !== undefined) {
      const parsed = String(splits).split(/[^0-9.]+/).filter(Boolean).map(Number).filter((n) => n > 0);
      if (!parsed.length) fail('Enter at least one percent, such as 50, 30, 20.');
      b.splits = parsed;
    }
    return [];
  },
  'payout.addBracket': (db) => {
    const list = db.settings.payout.brackets;
    const last = list.reduce((m, b) => Math.max(m, b.minPlayers), 1);
    list.push({ minPlayers: last + 3, splits: [50, 30, 20] });
    return [];
  },
  'payout.removeBracket': (db, { index }) => {
    if (db.settings.payout.brackets.length <= 1) fail('Keep at least one payout row.');
    db.settings.payout.brackets.splice(index, 1);
    return [];
  },
  'season.set': (db, { path, value }) => {
    const s = activeSeason(db) || fail('Create a season first.');
    setPath(s, path, value);
    return [];
  },
  'season.setFinishTable': (db, { place, value }) => {
    const r = activeSeason(db).rules;
    r.finishTable[place - 1] = num(value);
    return [];
  },
  'season.setChartPoint': (db, { players, place, value }) => {
    const r = activeSeason(db).rules;
    r.pointChart = r.pointChart || clone(League.POINT_CHART);
    const col = r.pointChart[players] || fail('That player count is not on the chart.');
    if (place < 1 || place > col.length) fail('That place is not on the chart.');
    col[place - 1] = num(value);
    return [];
  },
  'toc.setSplits': (db, { which, value }) => {
    if (which !== 'toc8' && which !== 'toc6') fail('That payout is not available.');
    const parsed = String(value).split(/[^0-9.]+/).filter(Boolean).map(Number).filter((n) => n > 0);
    if (!parsed.length) fail('Enter at least one percent, such as 40, 25, 16.5.');
    db.settings.toc[which] = parsed;
    return [];
  },
  'toc.setFee': (db, { index, minNights, fee }) => {
    const row = db.settings.toc.fees[index] || fail('That fee row is gone.');
    if (minNights !== undefined) row.minNights = Math.round(num(minNights));
    if (fee !== undefined) row.fee = num(fee);
    return [];
  },
  'season.addFinishPlace': (db) => { activeSeason(db).rules.finishTable.push(0); return []; },
  'season.removeFinishPlace': (db) => {
    const list = activeSeason(db).rules.finishTable;
    if (list.length > 1) list.pop();
    return [];
  },
  'season.setCarry': (db, { playerId, points, knockouts, nights }) => {
    const s = activeSeason(db);
    s.carry = s.carry || {};
    const c = s.carry[playerId] || { points: 0, knockouts: 0, nights: 0 };
    if (nights !== undefined) c.nights = num(nights);
    if (points !== undefined) c.points = num(points);
    if (knockouts !== undefined) c.knockouts = num(knockouts);
    s.carry[playerId] = c;
    return [];
  },
  'season.new': (db, { name }) => {
    const clean = String(name || '').trim() || fail('Give the season a name.');
    const prev = activeSeason(db);
    const s = newSeason(clean, { rules: prev ? prev.rules : undefined });
    db.seasons.push(s);
    db.activeSeasonId = s.id;
    const t = current(db);
    if (t && t.status === 'setup') t.seasonId = s.id;
    return [];
  },
  'season.activate': (db, { id }) => {
    if (!db.seasons.find((s) => s.id === id)) fail('That season is gone.');
    db.activeSeasonId = id;
    const t = current(db);
    if (t && t.status === 'setup') t.seasonId = id;
    return [];
  },

  /* Players */
  'player.add': (db, { name, checkIn }) => {
    const clean = String(name || '').trim() || fail('Type the player’s name first.');
    const existing = db.players.find((p) => p.name.toLowerCase() === clean.toLowerCase());
    if (existing && existing.active) fail(`${existing.name} is already on the list.`);
    let id;
    if (existing) { existing.active = true; id = existing.id; } else {
      id = uid('p');
      db.players.push({ id, name: clean, active: true });
      db.players.sort((a, b) => a.name.localeCompare(b.name));
    }
    if (checkIn) {
      const t = current(db);
      if (t && t.status === 'setup' && !t.entries.find((e) => e.playerId === id)) t.entries.push(newEntry(id));
    }
    return [];
  },
  'player.rename': (db, { id, name }) => {
    const clean = String(name || '').trim() || fail('A player needs a name.');
    const p = db.players.find((x) => x.id === id) || fail('That player is gone.');
    if (db.players.find((x) => x.id !== id && x.name.toLowerCase() === clean.toLowerCase())) fail(`${clean} is already on the list.`);
    p.name = clean;
    return [];
  },
  'player.setActive': (db, { id, active }) => {
    const p = db.players.find((x) => x.id === id) || fail('That player is gone.');
    p.active = !!active;
    return [];
  },

  /* Setting up a night */
  't.new': (db, payload) => {
    const t = current(db);
    if (t && t.status !== 'closed') fail('Finish or cancel the current night first.');
    const fresh = newTournament(db, { kind: payload && payload.kind });
    db.tournaments.push(fresh);
    db.currentTournamentId = fresh.id;
    return [];
  },
  't.set': (db, { path, value }) => {
    const t = needCurrent(db);
    if (!['name', 'date', 'countsTowardSeason'].includes(path)) fail('That setting is not available.');
    t[path] = value;
    return [];
  },
  't.config': (db, { path, value }) => {
    const t = needCurrent(db);
    setPath(t.config, path, value);
    return [];
  },
  't.checkin': (db, { playerId, on }) => {
    const t = needCurrent(db);
    if (t.status !== 'setup') fail('Use “Add a late player” once the game has started.');
    if (on) assertTocQualified(db, t, playerId);
    const has = t.entries.find((e) => e.playerId === playerId);
    if (on && !has) t.entries.push(newEntry(playerId));
    if (!on && has) t.entries = t.entries.filter((e) => e.playerId !== playerId);
    if (t.entries.some((e) => e.table)) t.entries.forEach((e) => { e.table = null; e.seat = null; });
    return [];
  },
  't.checkAll': (db, { on, qualified }) => {
    const t = needCurrent(db);
    if (t.status !== 'setup') fail('The game has already started.');
    let list = on ? db.players.filter((p) => p.active) : [];
    if (qualified) {
      const season = activeSeason(db);
      const rows = new Map(calcStandings(db, season).map((r) => [r.playerId, r.nights]));
      list = list.filter((p) => (rows.get(p.id) || 0) >= db.settings.toc.minNights);
    }
    t.entries = list.map((p) => newEntry(p.id));
    return [];
  },
  'level.set': (db, { index, key, value }) => {
    const t = needCurrent(db);
    assertLevelEditable(t, index);
    if (!['sb', 'bb', 'ante', 'minutes'].includes(key)) fail('That setting is not available.');
    const l = t.config.levels[index] || fail('That round is gone.');
    l[key] = num(value, key === 'minutes' ? { min: 1, fallback: l.minutes } : {});
    return [];
  },
  'level.add': (db, { kind }) => {
    const t = needCurrent(db);
    const rounds = t.config.levels.filter((l) => l.kind === 'round');
    const last = rounds[rounds.length - 1];
    if (kind === 'break') t.config.levels.push({ kind: 'break', minutes: 10 });
    else t.config.levels.push({ kind: 'round', sb: last ? last.sb * 2 : 25, bb: last ? last.bb * 2 : 50, ante: last ? last.ante : 0, minutes: last ? last.minutes : 20 });
    return [];
  },
  'level.remove': (db, { index }) => {
    const t = needCurrent(db);
    assertLevelEditable(t, index);
    if (t.config.levels.filter((l) => l.kind === 'round').length <= 1 && t.config.levels[index].kind === 'round') fail('Keep at least one round.');
    t.config.levels.splice(index, 1);
    return [];
  },
  'level.move': (db, { index, delta }) => {
    const t = needCurrent(db);
    const to = index + delta;
    if (to < 0 || to >= t.config.levels.length) return [];
    assertLevelEditable(t, Math.min(index, to));
    const [l] = t.config.levels.splice(index, 1);
    t.config.levels.splice(to, 0, l);
    return [];
  },
  'level.setAllMinutes': (db, { minutes }) => {
    const t = needCurrent(db);
    const m = num(minutes, { min: 1, fallback: 20 });
    t.config.levels.forEach((l, i) => {
      if (l.kind === 'round' && !(t.status === 'running' && i <= t.clock.levelIndex)) l.minutes = m;
    });
    return [];
  },
  't.drawSeats': (db) => {
    const t = needCurrent(db);
    pushUndo(t, 'Seat draw');
    if (t.kind === 'toc') snakeSeats(db, t); else drawSeats(t);
    return [];
  },
  't.clearSeats': (db) => {
    const t = needCurrent(db);
    t.entries.forEach((e) => { e.table = null; e.seat = null; });
    return [];
  },
  't.applyMove': (db, { playerId, to }) => {
    const t = needCurrent(db);
    const e = needEntry(t, playerId);
    pushUndo(t, `${playerName(db, playerId)} moved to table ${to}`);
    e.table = to;
    e.seat = freeSeat(t, to);
    return [];
  },
  't.dismissRedraw': (db, _, now) => {
    const t = needCurrent(db);
    if (t.redrawNotice && t.redrawNotice.pausedClock && !t.clock.running) {
      t.clock.anchor = now;
      t.clock.running = true;
    }
    t.redrawNotice = null;
    return [];
  },
  't.applyAllMoves': (db) => {
    const t = needCurrent(db);
    if (!tableMoves(t).length) return [];
    pushUndo(t, 'Table moves');
    for (let i = 0; i < 60; i++) {
      const [m] = tableMoves(t);
      if (!m) break;
      const e = needEntry(t, m.playerId);
      e.table = m.to;
      e.seat = freeSeat(t, m.to);
    }
    return [];
  },
  't.start': (db, _, now) => {
    const t = needCurrent(db);
    if (t.status !== 'setup') fail('This game has already started.');
    if (t.entries.length < 2) fail('Check in at least two players to start.');
    if (!t.config.levels.some((l) => l.kind === 'round')) fail('Add at least one round of blinds.');
    t.status = 'running';
    t.undo = [];
    if (t.kind === 'toc') {
      t.entries.forEach((e) => { e.fee = entryFee(db, t, e); });
      t.potAtStart = seasonPot(db, db.seasons.find((x) => x.id === t.seasonId) || activeSeason(db));
      if (!t.entries.some((e) => e.table)) snakeSeats(db, t);
    } else {
      db.defaults = clone(t.config);
    }
    goToLevel(t, 0, now);
    t.clock.running = true;
    t.seasonId = t.seasonId || db.activeSeasonId;
    return [{ type: 'started', level: levelAnnouncement(t) }];
  },
  't.cancel': (db) => {
    const t = needCurrent(db);
    db.tournaments = db.tournaments.filter((x) => x.id !== t.id);
    db.currentTournamentId = null;
    return [];
  },
  't.close': (db) => {
    const t = needCurrent(db);
    if (t.status !== 'finished') fail('The night isn’t finished yet.');
    t.status = 'closed';
    t.undo = [];
    db.currentTournamentId = null;
    return [];
  },

  /* The clock */
  'clock.toggle': (db, _, now) => {
    const t = needCurrent(db);
    if (t.status !== 'running') fail('The game isn’t running.');
    freeze(t, now);
    t.clock.running = !t.clock.running;
    t.restartedPaused = false;
    return [];
  },
  'clock.next': (db, _, now) => {
    const t = needCurrent(db);
    if (t.clock.levelIndex >= t.config.levels.length - 1) fail('This is the last round. Add more rounds in Blinds to go further.');
    const wasOpen = rebuysOpen(t);
    goToLevel(t, t.clock.levelIndex + 1, now);
    const events = [{ type: 'level', level: levelAnnouncement(t) }];
    if (wasOpen && !rebuysOpen(t)) events.push({ type: 'rebuysClosed' });
    return events;
  },
  'clock.prev': (db, _, now) => {
    const t = needCurrent(db);
    if (t.clock.levelIndex <= 0) fail('This is the first round.');
    goToLevel(t, t.clock.levelIndex - 1, now);
    return [{ type: 'level', level: levelAnnouncement(t), silent: true }];
  },
  'clock.restartLevel': (db, _, now) => { const t = needCurrent(db); goToLevel(t, t.clock.levelIndex, now); return []; },
  'clock.addTime': (db, { seconds }, now) => {
    const t = needCurrent(db);
    freeze(t, now);
    t.clock.remainingMs = Math.max(1000, t.clock.remainingMs + seconds * 1000);
    if (t.clock.remainingMs > 60000) t.clock.warned = false;
    return [];
  },
  'clock.pauseAfter': (db, { on }) => { needCurrent(db).clock.pauseAfter = !!on; return []; },

  /* Knockouts, rebuys and add-ons */
  't.knockout': (db, { victimId, byId, byIds, rebuy }, now) => {
    const t = needCurrent(db);
    if (t.status !== 'running') fail('The game isn’t running.');
    const victim = needEntry(t, victimId);
    if (victim.status !== 'in') fail(`${playerName(db, victimId)} is already out.`);
    const credits = [...new Set(byIds || (byId ? [byId] : []))];
    credits.forEach((id) => {
      if (id === victimId) fail('A player can’t knock themselves out.');
      if (needEntry(t, id).status !== 'in') fail(`${playerName(db, id)} is already out.`);
    });
    const alive = t.entries.filter((e) => e.status === 'in').length;
    if (alive < 2) fail('There is only one player left.');
    if (rebuy && !canRebuy(t, victim)) fail('Rebuys are closed for this player.');
    const vName = playerName(db, victimId);
    pushUndo(t, `${vName}${rebuy ? ' knocked out and rebought' : ' knocked out'}`);
    const round = roundNumber(t.config.levels, t.clock.levelIndex);
    t.knockouts.push({ id: uid('ko'), victimId, byIds: credits, rebought: !!rebuy, round, at: now });
    const byNames = credits.map((id) => playerName(db, id));
    const byName = byNames.length ? nameList(byNames) : null;
    const events = [];
    if (rebuy) {
      victim.rebuys += 1;
      events.push({ type: 'knockout', victim: vName, by: byName, byNames, rebought: true });
      return events;
    }
    victim.status = 'out';
    victim.outSeq = ++t.seq;
    victim.table = null;
    victim.seat = null;
    recomputePlaces(t, false);
    events.push({ type: 'knockout', victim: vName, by: byName, byNames, place: victim.place, placeLabel: ordinal(victim.place) });
    const remaining = t.entries.filter((e) => e.status === 'in');
    const toTwo = t.config.breakToTwo === undefined ? 16 : t.config.breakToTwo;
    const toOne = t.config.breakToOne === undefined ? 9 : t.config.breakToOne;
    const tablePrefs = db.settings.tables || {};
    const openTables = tableGroups(t).size;
    const redrawTwo = remaining.length <= toTwo && openTables > 2;
    const redrawOne = !!tablePrefs.redrawAtOne && remaining.length <= toOne && openTables > 1;
    if (remaining.length > 1 && (redrawTwo || redrawOne)) {
      // Everyone is drawn again at random, and both screens show the new tables.
      drawSeats(t);
      t.redrawNotice = { players: remaining.length, tables: tableGroups(t).size, pausedClock: false };
      if (tablePrefs.pauseOnRedraw !== false && t.clock.running) {
        freeze(t, now);
        t.clock.running = false;
        t.redrawNotice.pausedClock = true;
      }
      events.push({ type: 'tablesRedrawn', players: remaining.length });
    }
    if (remaining.length === 1) {
      recomputePlaces(t, true);
      freeze(t, now);
      t.clock.running = false;
      t.status = 'finished';
      events.push({ type: 'winner', name: playerName(db, remaining[0].playerId) });
    }
    return events;
  },
  't.rebuy': (db, { playerId }) => {
    const t = needCurrent(db);
    const e = needEntry(t, playerId);
    if (!canRebuy(t, e)) fail('Rebuys are closed for this player.');
    const name = playerName(db, playerId);
    pushUndo(t, `${name} rebought`);
    e.rebuys += 1;
    if (e.status === 'out') {
      // Coming back in: the earlier knockout now counts as a knockout of someone who rebought.
      const last = t.knockouts.filter((k) => k.victimId === playerId && !k.rebought).pop();
      if (last) last.rebought = true;
      e.status = 'in';
      e.outSeq = null;
      seatNewPlayer(t, e);
      recomputePlaces(t, false);
    }
    return [{ type: 'rebuy', name }];
  },
  't.addon': (db, { playerId }) => {
    const t = needCurrent(db);
    const e = needEntry(t, playerId);
    if (!addonsOpen(t)) fail('Add-ons are closed.');
    if (e.status !== 'in') fail('Only players still in can take an add-on.');
    if (e.addons >= 1) fail('This player already has an add-on.');
    pushUndo(t, `${playerName(db, playerId)} add-on`);
    e.addons = 1;
    return [];
  },
  't.lateEntry': (db, { playerId }) => {
    const t = needCurrent(db);
    if (t.status !== 'running') fail('The game isn’t running.');
    if (t.entries.find((e) => e.playerId === playerId)) fail('That player is already in this tournament.');
    assertTocQualified(db, t, playerId);
    pushUndo(t, `${playerName(db, playerId)} late entry`);
    const e = newEntry(playerId);
    t.entries.push(e);
    if (t.kind === 'toc') e.fee = entryFee(db, t, e);
    seatNewPlayer(t, e);
    recomputePlaces(t, false);
    return [];
  },
  't.undo': (db, _, now) => {
    const t = needCurrent(db);
    const snap = t.undo.pop() || fail('There is nothing to undo.');
    if (t.redrawNotice && t.redrawNotice.pausedClock && !snap.redrawNotice && !t.clock.running) {
      t.clock.anchor = now;
      t.clock.running = true;
    }
    t.entries = snap.entries;
    t.knockouts = snap.knockouts;
    t.seq = snap.seq;
    t.status = snap.status;
    t.redrawNotice = snap.redrawNotice || null;
    return [{ type: 'undo', label: snap.label }];
  },

  /* High hand: for the night in play, or a past night when an id is given. */
  'highHand.set': (db, { id, playerId, hand, type, cards }) => {
    const t = id ? (db.tournaments.find((x) => x.id === id) || fail('That night is gone.')) : needCurrent(db);
    if (!highHandEnabled(db, t) && (playerId || hand || type)) fail('High hand is turned off for the TOC. Turn it on in Settings.');
    const was = t.highHand || {};
    const next = { ...was, playerId: was.playerId || '', hand: was.hand || '' };
    delete next.amount;
    if (playerId !== undefined) {
      if (playerId) needEntry(t, playerId);
      next.playerId = playerId;
    }
    if (hand !== undefined) next.hand = String(hand).trim().slice(0, 60);
    if (type) {
      const problem = Hands.validate(type, cards);
      if (problem) fail(problem);
      next.type = type;
      next.cards = { ...(cards || {}) };
      next.hand = Hands.describe(type, cards);
    } else if (hand !== undefined) {
      delete next.type;
      delete next.cards;
    }
    if (!next.playerId && !next.hand) { delete t.highHand; return []; }
    t.highHand = next;
    const changed = next.playerId !== was.playerId || next.hand !== was.hand;
    if (t.status === 'running' && changed && next.playerId && next.hand) return [{ type: 'highHand', name: playerName(db, next.playerId), hand: next.hand }];
    return [];
  },

  /* Past nights */
  'past.setEntry': (db, { id, playerId, place, knockouts }) => {
    const t = db.tournaments.find((x) => x.id === id) || fail('That night is gone.');
    const e = needEntry(t, playerId);
    const season = db.seasons.find((s) => s.id === t.seasonId) || activeSeason(db);
    if (place !== undefined) {
      const p = Math.round(num(place, { min: 1, fallback: e.place || 1 }));
      if (p > t.entries.length) fail(`There were only ${t.entries.length} players that night.`);
      e.place = p;
    }
    if (knockouts !== undefined) {
      const want = Math.round(num(knockouts));
      const counted = t.knockouts.filter((k) => koCredits(k).includes(playerId) && (season.rules.rebuyKnockoutsCount || !k.rebought)).length;
      e.koAdjust = want - counted;
    }
    return [];
  },
  'past.setCounts': (db, { id, on }) => {
    const t = db.tournaments.find((x) => x.id === id) || fail('That night is gone.');
    t.countsTowardSeason = !!on;
    return [];
  },
  'past.delete': (db, { id }) => {
    db.tournaments = db.tournaments.filter((t) => t.id !== id);
    if (db.currentTournamentId === id) db.currentTournamentId = null;
    return [];
  },

};

function dispatch(db, type, payload = {}, now = Date.now()) {
  const fn = actions[type];
  if (!fn) fail(`Unknown action: ${type}`);
  const events = fn(db, payload, now) || [];
  db.rev = (db.rev || 0) + 1;
  return events;
}

/* A saved file is checked before use, so a damaged backup can't take over the app. */
function isValidDb(db) {
  return !!db && typeof db === 'object' && Array.isArray(db.players) && Array.isArray(db.seasons)
    && db.seasons.length > 0 && Array.isArray(db.tournaments) && !!db.settings && !!db.defaults;
}

/* Loads his January to October results as finished nights, keeping what was actually paid. */
function importSeason2026(db) {
  const season = activeSeason(db);
  const idFor = (name) => {
    let p = db.players.find((x) => x.name.toLowerCase() === name.toLowerCase());
    if (!p) { p = leaguePlayer(name); db.players.push(p); db.players.sort((a, b) => a.name.localeCompare(b.name)); }
    return p.id;
  };
  Season2026.MONTHS.forEach((m) => {
    const id = `sopl2026_${m.month.toLowerCase()}`;
    const handFrom = () => (m.highHand ? { playerId: idFor(m.highHand[0]), hand: m.highHand[1], amount: 0 } : undefined);
    const loaded = db.tournaments.find((x) => x.id === id);
    if (loaded) {
      if (!loaded.highHand && handFrom()) loaded.highHand = handFrom();
      return;
    }
    const t = newTournament(db, { name: m.month, date: `2026-${String(m.num).padStart(2, '0')}-01` });
    t.id = id;
    t.seasonId = season.id;
    t.monthOnly = true;
    t.status = 'closed';
    t.importedRebuys = m.rebuys;
    const gross = (m.players + m.rebuys) * 20;
    t.fixedPool = gross * 0.8;
    t.fixedPot = gross * 0.2;
    t.fixedPays = m.rows.filter((r) => r[3] > 0).map((r) => ({ place: r[1], amount: r[3], percent: null }));
    m.rows.forEach(([name, place, ko]) => {
      const e = newEntry(idFor(name));
      e.place = place;
      e.koAdjust = ko;
      e.status = place === 1 ? 'in' : 'out';
      e.outSeq = place === 1 ? null : m.rows.length - place + 1;
      t.entries.push(e);
    });
    t.seq = m.rows.length - 1;
    if (handFrom()) t.highHand = handFrom();
    db.tournaments.push(t);
  });
  if (!season.potAdjust) season.potAdjust = Season2026.POT_ADJUST;
}

/* Brings an older save up to the league's rules. Test data from earlier builds is removed;
   the app saves a backup first. Nights and players already in real data are kept. */
function applyLeague(db) {
  if ((db.leagueVersion || 0) >= LEAGUE_VERSION) return false;
  if ((db.leagueVersion || 0) >= 1) {
    if (db.leagueVersion < 4) importSeason2026(db);
    const fresh = defaultSettings();
    if (db.settings.highHandPerPlayer === undefined) db.settings.highHandPerPlayer = fresh.highHandPerPlayer;
    if (db.settings.highHandInToc === undefined) db.settings.highHandInToc = fresh.highHandInToc;
    db.settings.tables = { ...fresh.tables, ...(db.settings.tables || {}) };
    delete db.settings.highHandPayout;
    db.settings.toc.minNights = db.settings.toc.minNights || 6;
    // New starting-table limits. Two tables now hold up to 19 players, which takes tables of 10.
    const setupNight = (db.tournaments || []).find((x) => x.id === db.currentTournamentId && x.status === 'setup');
    [db.defaults, setupNight && setupNight.config].filter(Boolean).forEach((c) => {
      if (c.startTwoAt === undefined) c.startTwoAt = 10;
      if (c.startThreeAt === undefined) c.startThreeAt = 20;
      if (c.seatsPerTable === 9) c.seatsPerTable = 10;
    });
    db.leagueVersion = LEAGUE_VERSION;
    return true;
  }
  const fresh = emptyDb();
  if (db.testData) {
    db.testData = false;
    db.players = db.players.filter((p) => !String(p.id).startsWith('test_'));
    db.tournaments = [];
    db.currentTournamentId = null;
    db.seasons = fresh.seasons;
    db.activeSeasonId = fresh.activeSeasonId;
  } else {
    db.seasons.forEach((x) => { x.rules = defaultRules(); });
  }
  fresh.players.forEach((p) => {
    if (!db.players.find((x) => x.name.toLowerCase() === p.name.toLowerCase())) db.players.push(p);
  });
  db.players.sort((a, b) => a.name.localeCompare(b.name));
  const tv = db.settings.tv;
  const sounds = db.settings.sounds;
  db.settings = { ...defaultSettings(), tv, sounds };
  db.defaults = defaultConfig();
  importSeason2026(db);
  db.leagueVersion = LEAGUE_VERSION;
  delete db.sampleVersion;
  return true;
}

/* After a crash or restart the clock is safely paused at its last saved time. */
function normalizeAfterLoad(db, now = Date.now()) {
  applyLeague(db);
  const t = current(db);
  if (t && t.status === 'running' && t.clock.running) {
    t.clock.running = false;
    t.restartedPaused = true;
    t.clock.anchor = now;
  }
  return db;
}

function prepareForSave(db, now = Date.now()) {
  const t = current(db);
  if (!t || !t.clock.running) return db;
  const copy = { ...db, tournaments: db.tournaments.map((x) => (x.id === t.id ? { ...x, clock: { ...x.clock, remainingMs: remainingMs(t, now), anchor: now } } : x)) };
  return copy;
}

/* ---------- Everything the screens need, worked out from the saved data ---------- */

/* Regular nights always have a high hand. The TOC has one only if that setting is on. */
function highHandEnabled(db, t) {
  return t.kind !== 'toc' || !!db.settings.highHandInToc;
}

/* The high hand pays a set amount per player in the night ($5 each to start). */
function highHandPayout(db, t) {
  const per = db.settings.highHandPerPlayer === undefined ? 5 : db.settings.highHandPerPlayer;
  return per * t.entries.length;
}

function highHandView(db, t) {
  if (!t.highHand) return null;
  return { ...t.highHand, amount: highHandPayout(db, t), name: t.highHand.playerId ? playerName(db, t.highHand.playerId) : '' };
}

function liveView(db, t) {
  const levels = t.config.levels;
  const i = Math.min(t.clock.levelIndex, levels.length - 1);
  let msAfterCurrentToBreak = null;
  let acc = 0;
  for (let j = i + 1; j < levels.length; j++) {
    if (levels[j].kind === 'break') { msAfterCurrentToBreak = acc; break; }
    acc += levels[j].minutes * 60000;
  }
  let nextRoundLevel = null;
  for (let j = i + 1; j < levels.length; j++) if (levels[j].kind === 'round') { nextRoundLevel = levels[j]; break; }
  const season = db.seasons.find((x) => x.id === t.seasonId) || activeSeason(db);
  const standingRows = t.kind === 'toc' ? new Map(calcStandings(db, season).map((r) => [r.playerId, r])) : null;
  const entries = t.entries.map((e) => ({
    ...e,
    ...(t.kind === 'toc' ? {
      fee: entryFee(db, t, e),
      startChips: db.settings.toc.baseChips + db.settings.toc.chipsPerPoint * ((standingRows.get(e.playerId) || {}).points || 0),
    } : {}),
    name: playerName(db, e.playerId),
    knockouts: t.knockouts.filter((k) => koCredits(k).includes(e.playerId)).length + (e.koAdjust || 0),
    canRebuy: canRebuy(t, e),
    knockedOutBy: (() => {
      const k = t.knockouts.filter((x) => x.victimId === e.playerId && !x.rebought).pop();
      return k && koCredits(k).length ? nameList(koCredits(k).map((id) => playerName(db, id))) : null;
    })(),
  }));
  const alive = entries.filter((e) => e.status === 'in');
  const rebuys = entries.reduce((n, e) => n + e.rebuys, 0);
  const addons = entries.reduce((n, e) => n + e.addons, 0);
  const pool = prizePool(t, db);
  const pays = paysFor(db, t).map((p) => {
    const e = entries.find((x) => x.place === p.place);
    return { ...p, name: e ? e.name : null };
  });
  return {
    id: t.id,
    kind: t.kind || 'regular',
    name: t.name,
    date: t.date,
    status: t.status,
    countsTowardSeason: t.countsTowardSeason,
    config: t.config,
    clock: t.clock,
    level: levels[i],
    levelIndex: i,
    levelCount: levels.length,
    round: roundNumber(levels, i),
    nextRoundLevel,
    nextLevel: levels[i + 1] || null,
    nextRound: nextRoundLevel ? roundNumber(levels, i + 1) : null,
    msAfterCurrentToBreak,
    entries,
    aliveCount: alive.length,
    entryCount: entries.length,
    rebuys,
    addons,
    pool,
    potTotal: potTotal(t),
    tocPot: t.kind === 'toc' ? (t.potAtStart !== undefined ? t.potAtStart : seasonPot(db, season)) : 0,
    tocFees: t.kind === 'toc' ? t.entries.reduce((n, e) => n + entryFee(db, t, e), 0) : 0,
    payouts: pays,
    rebuysOpen: rebuysOpen(t),
    addonsOpen: addonsOpen(t),
    moves: t.status === 'running' ? tableMoves(t).map((m) => ({ ...m, name: playerName(db, m.playerId) })) : [],
    seated: entries.some((e) => e.table),
    undoLabel: t.undo.length ? t.undo[t.undo.length - 1].label : null,
    restartedPaused: !!t.restartedPaused,
    redrawNotice: t.redrawNotice || null,
    highHandEnabled: highHandEnabled(db, t),
    highHand: highHandEnabled(db, t) ? highHandView(db, t) : null,
    highHandPayout: highHandPayout(db, t),
    lastKnockout: (() => {
      const k = t.knockouts[t.knockouts.length - 1];
      if (!k) return null;
      return { victim: playerName(db, k.victimId), by: koCredits(k).length ? nameList(koCredits(k).map((id) => playerName(db, id))) : null, rebought: k.rebought };
    })(),
  };
}

function derive(db) {
  const season = activeSeason(db);
  const t = current(db);
  const standings = calcStandings(db, season);
  const before = t && t.status !== 'setup' ? calcStandings(db, season, { excludeCurrent: true }) : null;
  if (before) {
    const prev = new Map(before.map((r) => [r.playerId, r.rank]));
    standings.forEach((r) => { r.movement = prev.has(r.playerId) ? prev.get(r.playerId) - r.rank : null; });
  }
  return {
    season,
    standings,
    tournament: t ? liveView(db, t) : null,
    nightsPlayed: db.tournaments.filter((x) => season && x.seasonId === season.id && x.countsTowardSeason && (x.status === 'closed' || x.status === 'finished')).length,
    tocFeeRows: db.settings.toc.fees,
    seasonPot: seasonPot(db, season),
    past: db.tournaments
      .filter((x) => x.status === 'closed' || x.status === 'finished')
      .slice()
      .sort((a, b) => String(b.date).localeCompare(String(a.date)))
      .map((x) => {
        const s = db.seasons.find((y) => y.id === x.seasonId) || season;
        const pays = paysFor(db, x);
        return {
          id: x.id,
          name: x.name,
          date: x.date,
          status: x.status,
          seasonName: s ? s.name : '',
          countsTowardSeason: x.countsTowardSeason,
          pool: prizePool(x, db),
          kind: x.kind || 'regular',
          monthOnly: !!x.monthOnly,
          highHandEnabled: highHandEnabled(db, x),
          highHand: highHandEnabled(db, x) ? highHandView(db, x) : null,
          highHandPayout: highHandPayout(db, x),
          importedRebuys: x.importedRebuys,
          winner: (() => { const w = x.entries.find((e) => e.place === 1); return w ? playerName(db, w.playerId) : null; })(),
          results: x.entries.slice().sort((a, b) => (a.place || 99) - (b.place || 99)).map((e) => {
            const pts = nightPoints(s.rules, x, e);
            const pay = pays.find((p) => p.place === e.place);
            return { playerId: e.playerId, name: playerName(db, e.playerId), place: e.place, knockouts: pts.kos, rebuys: x.importedRebuys !== undefined ? null : e.rebuys, points: pts.total, paid: pay ? pay.amount : 0 };
          }),
        };
      }),
  };
}

function standingsCsv(db) {
  const season = activeSeason(db);
  const rows = [['Rank', 'Player', 'Points', 'Knockouts', 'Nights', 'Wins', 'Best finish', 'Winnings']];
  calcStandings(db, season).forEach((r) => rows.push([r.rank, r.name, r.points, r.kos, r.nights, r.wins, r.best || '', r.won]));
  return rows.map((row) => row.map((c) => {
    let s = String(c);
    if (/^[=+\-@]/.test(s)) s = `'${s}`;
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(',')).join('\r\n');
}

/* ---------- Results to share: one night, or the whole season ---------- */

function nightReport(db, id) {
  const t = db.tournaments.find((x) => x.id === id);
  if (!t) fail('That night wasn’t found.');
  if (t.status !== 'closed' && t.status !== 'finished') fail('That night isn’t finished yet.');
  const season = db.seasons.find((x) => x.id === t.seasonId) || activeSeason(db);
  const rules = season.rules;
  const pays = paysFor(db, t);
  const imported = t.importedRebuys !== undefined;
  const rebuys = imported ? t.importedRebuys : t.entries.reduce((n, e) => n + e.rebuys, 0);
  const pool = prizePool(t, db);
  const toToc = t.kind === 'toc' ? 0 : potTotal(t);
  const results = t.entries.slice().sort((a, b) => (a.place || 99) - (b.place || 99)).map((e) => {
    const pts = nightPoints(rules, t, e);
    const pay = pays.find((x) => x.place === e.place);
    return {
      playerId: e.playerId, name: playerName(db, e.playerId), place: e.place || null, knockouts: pts.kos,
      finishPoints: pts.total - pts.koPoints, points: pts.total, rebuys: imported ? null : e.rebuys, paid: pay ? pay.amount : 0,
    };
  });
  const hhOn = highHandEnabled(db, t);
  return {
    id: t.id,
    league: db.settings.leagueName || 'Poker League',
    seasonName: season ? season.name : '',
    name: t.name,
    date: t.date,
    monthOnly: !!t.monthOnly,
    kind: t.kind || 'regular',
    countsTowardSeason: !!t.countsTowardSeason,
    players: t.entries.length,
    rebuys,
    pool,
    toToc,
    collected: Math.round((pool + toToc) * 100) / 100,
    paidOut: pays.reduce((n, x) => n + (x.amount || 0), 0),
    highHandEnabled: hhOn,
    highHand: hhOn ? highHandView(db, t) : null,
    highHandPayout: hhOn ? highHandPayout(db, t) : 0,
    winner: (results.find((r) => r.place === 1) || {}).name || null,
    results,
    standings: calcStandings(db, season, { upTo: t.date }).map((r) => ({ rank: r.rank, playerId: r.playerId, name: r.name, points: r.points, kos: r.kos, nights: r.nights, wins: r.wins, won: r.won })),
  };
}

function seasonReport(db) {
  const season = activeSeason(db);
  if (!season) fail('There’s no season yet.');
  const nights = db.tournaments
    .filter((t) => t.seasonId === season.id && (t.status === 'closed' || t.status === 'finished'))
    .slice()
    .sort((a, b) => String(a.date).localeCompare(String(b.date)) || (a.kind === 'toc') - (b.kind === 'toc'))
    .map((t) => nightReport(db, t.id));
  const carry = season.carry || {};
  return {
    league: db.settings.leagueName || 'Poker League',
    seasonName: season.name,
    nights,
    carry: Object.fromEntries(Object.entries(carry).filter(([, c]) => c && c.points).map(([id, c]) => [id, c.points])),
    standings: calcStandings(db, season).map((r) => ({ rank: r.rank, playerId: r.playerId, name: r.name, points: r.points, kos: r.kos, nights: r.nights, wins: r.wins, best: r.best, won: r.won })),
  };
}

module.exports = {
  useSeed,
  nightReport, seasonReport,
  SCHEMA_VERSION, LEAGUE_VERSION, GameError, emptyDb, applyLeague, chartPoints, snakeIndex, snakeSeats, tocFee, seasonPot, paysFor, splitAmounts, tocSplits, dispatch, tick, derive, isValidDb, normalizeAfterLoad, prepareForSave,
  calcStandings, payouts, payoutCount, prizePool, nightPoints, finishPoints, tableMoves, remainingMs, roundNumber, standingsCsv, ordinal, drawSeats,
  defaultRules, current, activeSeason, targetTables, startTables, koCredits,
};
