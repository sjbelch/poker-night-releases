'use strict';
/* Starts the newest copy of Poker Night on this computer: the one the installer put here, or a newer
   one that came in through an update. Updates go in their own folder, so nothing the running app uses
   is ever overwritten. This file stays small and rarely changes, because only the installer replaces it. */
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const parts = (v) => String(v || '0').split('.').map((n) => parseInt(n, 10) || 0);
function compare(a, b) {
  const x = parts(a);
  const y = parts(b);
  for (let i = 0; i < 3; i += 1) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0);
  return 0;
}
function readPkg(dir) { try { return JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8')); } catch (_) { return null; } }

const bundled = { dir: __dirname, version: (readPkg(__dirname) || {}).version };
const updatesDir = process.env.POKER_UPDATES_DIR || path.join(app.getPath('userData'), 'Updates');
let chosen = bundled;
const skipped = [];

try {
  fs.readdirSync(updatesDir, { withFileTypes: true }).forEach((d) => {
    if (!d.isDirectory() || d.name.endsWith('.tmp')) return;
    const dir = path.join(updatesDir, d.name);
    const pkg = readPkg(dir);
    if (!pkg || !fs.existsSync(path.join(dir, 'main.js')) || !fs.existsSync(path.join(dir, '.complete'))) return;
    if (fs.existsSync(path.join(dir, '.failed'))) { skipped.push(pkg.version); return; }
    // A version that didn't finish starting last time is set aside, and the one before it runs instead.
    if (fs.existsSync(path.join(dir, '.starting'))) {
      try { fs.renameSync(path.join(dir, '.starting'), path.join(dir, '.failed')); } catch (_) { /* read-only */ }
      skipped.push(pkg.version);
      return;
    }
    const needs = pkg.pokerNight && pkg.pokerNight.minElectron;
    if (needs && compare(process.versions.electron, needs) < 0) return;
    if (compare(pkg.version, chosen.version) > 0) chosen = { dir, version: pkg.version };
  });
} catch (_) { /* no updates yet */ }

if (chosen !== bundled) { try { fs.writeFileSync(path.join(chosen.dir, '.starting'), String(Date.now())); } catch (_) { /* read-only */ } }

global.pokerBoot = { bundledDir: bundled.dir, bundledVersion: bundled.version, updatesDir, dir: chosen.dir, version: chosen.version, skipped };
require(path.join(chosen.dir, 'main.js'));
