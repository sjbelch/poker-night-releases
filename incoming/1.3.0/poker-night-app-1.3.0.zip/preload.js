'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('poker', {
  getState: () => ipcRenderer.invoke('state:get'),
  act: (type, payload) => ipcRenderer.invoke('act', type, payload),
  command: (name, arg) => ipcRenderer.invoke('command', name, arg),
  onState: (fn) => ipcRenderer.on('state', (_e, s) => fn(s)),
  onEvents: (fn) => ipcRenderer.on('events', (_e, ev) => fn(ev)),
});
